# RTNN / DE0-CV：既存方式の実機実験・論文データ取得版

基準日：2026-10-31。**実験仕様・ホスト集計を整理した版であり、書込み済みFPGAや完成bitstreamではありません。**

## この版で固定したもの

対象は、同じseed-63 Q15モデルについて、開始前の計算予算・実行クラス上限と、各Exitのentropy早期停止を使う方式です。ブロック間の残り時間入力、新しい学習済み停止ヘッド、GPU実験は本線に含めません。別のtime-feedback ZIPは削除せず、別研究の履歴として保存してください。

GitHub mainは変更していません。既存のオフライン版を独立して展開し、実験ツール・解析・文書を更新しました。今後この版の`paper/PROTOCOL_JA.md`を実機測定仕様の正本とします。

## 現在できたこと／まだできていないこと

| 区分 | 状態 | 読み違えてはいけないこと |
|---|---|---|
| ホスト試験 | 新規を含め77件PASS | FPGA回路の試験ではない |
| 既存preflight | 30件PASS、全試験の一部 | 77+30を独立107件と数えない |
| 本物の凍結Q15演算＋新firmware | 固定2,520件・適応7,560件で機能一致 | 時計コールバックは人工値。速度実測ではない |
| 論文用収集・解析系 | 人工データの総合試験済み | 人工cycleから性能主張しない |
| 新SoCのRTL全体実行、sv2v回帰 | 未実施 | 旧Simple System成功と別物 |
| Quartus Fitter/STA、実機SOF、実機測定 | 未実施 | データ収集の前に必要 |
| FPGA固有のdeadline保証 | 未成立 | このBビルドはdeadline実験を拒否する |

検証ログは`evidence/release_2026-10-31/`。生のFPGA測定レコードは**0件**です。

## 論文の最小到達点

「DE0-CV上で、同じ重みの可変深度実装が、物理的な実行量と観測cycleをどう変えたか」を対象限定のcase studyとして報告します。固定2だけでなく固定0〜6の全点と、早期停止なしのbudget-cap方式も比較します。

速くなることは測定結果であり、完成条件ではありません。遅くなる・精度非劣性が不確定、という結果もそのまま報告します。採択・新規性は保証しません。hard-WCET論文にするには、これとは別の時間上界の根拠と新しいdeadlineビルドが必要です。

## いま再実行できるコマンド

このREADMEのある`fpga/de0_cv/`で実行します。

```bash
bash tools/offline_reproduce.sh
python3 -m pytest -q
```

`requirements-host-observed.txt`は今回の観測環境です。GPIO/UARTを使う測定PCには別途pyserialが必要です。導入した版を実験記録に残します。

## 測定前に一度だけ固定する実験キャンペーン

事前生成した雛形は`paper/campaign/`です。実測ファイルと混ぜないため、作業用コピーを作ります。

```bash
mkdir -p runs
cp -a paper/campaign runs/campaign01
```

新しい雛形を同じ規則で作り直す場合：

```bash
python3 tools/paper_campaign.py --out runs/campaign02
```

既存ディレクトリは上書きしません。予定は13セッション、**24,840要求**。内訳は`paper/PROTOCOL_JA.md`を参照。現在のcampaignには測定値はありません。

## 実測開始をブロックする前提

`hardware_review.json`のfalse/nullを、単にtrueや架空の値に書き換えてはいけません。以下の実物ファイルとレビューを揃えてから記入します。

1. pinned Ibexの合成用ソースグラフ、変換前後の回帰ログ、新SoC全体の42ケースログ。
2. Bの実際のRV32 ELF/BINとモデル機能一致の検証。
3. Quartus生成SOF、RAM初期化、Fitter、STA、制約・メモリ応答のレビュー。
4. 実ボード識別、実際の書込み/verifyログ、UART電圧/配線確認。

**このうち新SoC全体シミュレーション環境と依存グラフの確定には、まだ追加実装・実行が必要です。** 現在の`tools/make_quartus_flat.sh`は、レビュー済みの順序付きソース一覧を要求する変換入口であり、一覧を自動解決して等価性まで証明する完成ツールではありません。

部品試験用の入口は`bash tools/run_rtl_unit_tests.sh`です。EDA環境の有無は`bash tools/toolchain_gate.sh`で確認できます。有効なB用ソース/コンパイラが揃った後のビルド入口は`bash tools/build_b_firmware.sh upstream/source_repo`、B用Quartus作業領域の分離は`tools/prepare_b_quartus.py`です。ツールがない現環境ではこれらの成功を記録していません。

## 実機での測定

`hardware_review.json`と、各` sessions/<session_id>.json`を実際の証跡で埋めます。詳細は`paper/BOARD_EXECUTION_JA.md`。

```bash
python3 tools/paper_results.py --campaign runs/campaign01 --check-only
python3 tools/paper_collect.py --campaign runs/campaign01 \
  --session primary_01 --port /dev/ttyUSB0
```

ポート名は実際の接続に合わせます。`--check-only`は「指定証跡ファイルとoperator reviewが揃った」判定で、内容の自動STA証明・物理attestationではありません。

10回のprimaryはそれぞれ別cold boot。診断3種も別セッションで取得します。欠損、UART障害、異常応答を自動retryして隠しません。失敗時はraw journalとINCOMPLETE captureが残ります。

## 全測定後に論文用の表・図を作る

```bash
python3 tools/paper_results.py --campaign runs/campaign01 --out paper_results/campaign01
python3 tools/paper_plots.py --report paper_results/campaign01/results.json \
  --out paper_results/campaign01_figures
```

出力は`per_request.csv`、`paired_by_input_session.csv`、`fixed_and_budget_frontiers.csv`、`results.json`、`RESULTS.md`、4図のPNG/SVGです。未測定・synthetic・不完全な入力からは生成しません。表と図の元データhashも結びます。

**追加実装なしでこの収集・集計入口を使えるのは、B実装と実機ゲートを通した後です。現状を「実機に書くだけ」とは呼びません。**

## 論文執筆ファイル

- `paper/PROTOCOL_JA.md`：測定前の固定仕様、判定、独立性、失敗時処理。
- `paper/MANUSCRIPT_SKELETON_JA.md`：目的・方法・結果欄・限界の原稿骨子。
- `paper/CLAIM_EVIDENCE_MAP.json`：何をどの証拠で主張できるか。
- `paper/BOARD_EXECUTION_JA.md`：接続後の作業順と保存物。
- `docs/RELEASE_LEDGER_2026-10-31.md`：今回の変更・検証・判断。

古い日付の文書は履歴です。試験数や現在状態はこの版の検証記録を優先してください。
