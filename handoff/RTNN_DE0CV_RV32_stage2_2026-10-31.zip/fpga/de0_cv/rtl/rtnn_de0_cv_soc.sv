// New physical target: pinned Ibex, exact frozen RTNN ELF/BIN, M10K candidate RAM.
// NOT cycle-equivalent by assumption to the older Verilator Simple System.
// This module has NO executable simulator_ctrl/DPI $finish calls.
module rtnn_de0_cv_soc (
  input  logic clk_i,
  input  logic rst_ni,
  output logic uart_tx_o,
  input  logic uart_rx_i,
  output logic uart_idle_o,
  output logic halted_o,
  output logic bus_fault_o
);
  logic instr_req, instr_gnt, instr_rvalid, instr_hit;
  logic [31:0] instr_addr, instr_rdata;
  logic [6:0] instr_rdata_intg;
  logic instr_err_q;

  logic data_req, data_gnt, data_rvalid;
  logic data_we;
  logic [3:0] data_be;
  logic [31:0] data_addr, data_wdata, data_rdata;
  logic [6:0] data_rdata_intg;
  logic data_err_q;

  logic ram_data_hit, ram_data_rvalid, ram_instr_rvalid;
  logic data_access_err;
  logic [31:0] ram_data_rdata;
  logic uart_ready;
  logic uart_rx_valid, uart_rx_framing, rx_pending_q, rx_overflow_q;
  logic [7:0] uart_rx_byte, rx_data_q;
  logic rx_data_read, rx_status_clear;
  logic mmio_hit, mmio_write_char, accepted;
  logic [31:0] mmio_read_data_q;
  logic response_ram_q, response_valid_q;
  logic ram_dreq;

  assign instr_gnt = instr_req;  // no outstanding fetch arbitration
  assign mmio_hit = ((data_addr & 32'hfffffc00) == 32'h00020000);
  assign mmio_write_char = mmio_hit && data_we && data_addr[9:0] == 10'h000
                            && data_be[0];
  // Stall a SIM_OUT write until there is UART bandwidth. The existing binary
  // does not poll UART status. This backpressure prevents silent loss.
  assign data_gnt = !data_req || !mmio_write_char || uart_ready;
  assign accepted = data_req && data_gnt;
  assign data_access_err = !(ram_data_hit || (mmio_hit &&
                 (data_addr[9:0] == 10'h000 || data_addr[9:0] == 10'h004 ||
                  data_addr[9:0] == 10'h008 || data_addr[9:0] == 10'h00c ||
                  data_addr[9:0] == 10'h010 || data_addr[9:0] == 10'h014)));
  assign ram_dreq = accepted && ram_data_hit;
  assign uart_idle_o = uart_ready;
  assign rx_data_read = accepted && mmio_hit && !data_we && data_addr[9:0]==10'h014;
  assign rx_status_clear = accepted && mmio_hit && data_we &&
                           data_addr[9:0]==10'h010 && data_wdata[1];

  rtnn_de0_cv_ram #(.INIT_HEX("rtnn_ram_words.hex")) u_ram (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .data_req_i(ram_dreq), .data_we_i(data_we),
    .data_be_i(data_be), .data_addr_i(data_addr),
    .data_wdata_i(data_wdata), .data_hit_o(ram_data_hit),
    .data_rvalid_o(ram_data_rvalid), .data_rdata_o(ram_data_rdata),
    .instr_req_i(instr_req), .instr_addr_i(instr_addr),
    .instr_hit_o(instr_hit), .instr_rvalid_o(ram_instr_rvalid),
    .instr_rdata_o(instr_rdata)
  );
  assign instr_rvalid = ram_instr_rvalid;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) instr_err_q <= 1'b0;
    else instr_err_q <= instr_req && !instr_hit;
  end

  rtnn_uart_tx #(.CLOCK_HZ(50_000_000), .BAUD(115_200)) u_uart (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .start_i(accepted && mmio_write_char),
    .data_i(data_wdata[7:0]),
    .tx_o(uart_tx_o), .ready_o(uart_ready)
  );

  rtnn_uart_rx #(.CLOCK_HZ(50_000_000), .BAUD(115_200)) u_uart_rx (
    .clk_i(clk_i), .rst_ni(rst_ni), .rx_i(uart_rx_i),
    .byte_o(uart_rx_byte), .valid_o(uart_rx_valid),
    .framing_error_o(uart_rx_framing)
  );
  // CPU polls status (bit0 available, bit1 sticky error), then reads data.
  // A read and new byte on the same edge keeps the new byte. If a new byte
  // arrives while an unconsumed byte is pending, report overflow explicitly.
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rx_pending_q <= 1'b0;
      rx_overflow_q <= 1'b0;
      rx_data_q <= 8'b0;
    end else begin
      if (rx_data_read) rx_pending_q <= 1'b0;
      if (rx_status_clear) rx_overflow_q <= 1'b0;
      if (uart_rx_framing) rx_overflow_q <= 1'b1;
      if (uart_rx_valid) begin
        if (rx_pending_q && !rx_data_read)
          rx_overflow_q <= 1'b1;
        else begin
          rx_data_q <= uart_rx_byte;
          rx_pending_q <= 1'b1;
        end
      end
    end
  end

  // One-cycle responses for both RAM and MMIO. Capture select on grant, not
  // merely request: a stalled UART write MUST NOT complete early.
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      response_ram_q <= 1'b0;
      response_valid_q <= 1'b0;
      data_err_q <= 1'b0;
      mmio_read_data_q <= '0;
      halted_o <= 1'b0;
      bus_fault_o <= 1'b0;
    end else begin
      response_valid_q <= accepted;
      if (accepted) begin
        response_ram_q <= ram_data_hit;
        data_err_q <= data_access_err;
        if (data_access_err) bus_fault_o <= 1'b1;
        unique case (data_addr[9:0])
          10'h004: mmio_read_data_q <= {31'b0,uart_ready};
          10'h008: mmio_read_data_q <= {31'b0,halted_o};
          10'h00c: mmio_read_data_q <= 32'h52544e4e; // RTNN magic (not a build hash)
          10'h010: mmio_read_data_q <= {30'b0, rx_overflow_q, rx_pending_q};
          10'h014: mmio_read_data_q <= {24'b0, rx_data_q};
          default: mmio_read_data_q <= 32'b0;
        endcase
        if (mmio_hit && data_we && data_addr[9:0] == 10'h008 && data_wdata[0])
          halted_o <= 1'b1;
      end
      if (instr_req && !instr_hit) bus_fault_o <= 1'b1;
    end
  end
  assign data_rvalid = response_valid_q;
  assign data_rdata = response_ram_q ? ram_data_rdata : mmio_read_data_q;

  // SECDED bits match the pinned Simple System's SecureIbex read-data path.
  logic [31:0] unused_data_ecc, unused_instr_ecc;
  prim_secded_inv_39_32_enc u_data_secded (
    .data_i(data_rdata), .data_o({data_rdata_intg,unused_data_ecc})
  );
  prim_secded_inv_39_32_enc u_instr_secded (
    .data_i(instr_rdata), .data_o({instr_rdata_intg,unused_instr_ecc})
  );

  // Pinned upstream lowRISC/ibex commit 7b5df75a041affe56e8c235260f98a09b3319008.
  // Deliberately maintain Simple-System processor parameters; the surrounding
  // bus/RAM is NEW, so cycle counts must be re-measured and structurally checked.
  ibex_top #(
    .SecureIbex(1'b1),
    .RV32M(ibex_pkg::RV32MSingleCycle),
    .RV32B(ibex_pkg::RV32BNone),
    .RegFile(ibex_pkg::RegFileFF),
    .BranchTargetALU(1'b0), .WritebackStage(1'b0),
    .ICache(1'b0), .ICacheECC(1'b0), .BranchPredictor(1'b0),
    .PMPEnable(1'b0), .DbgTriggerEn(1'b0),
    .DmBaseAddr(32'h00100000), .DmAddrMask(32'h00000003),
    .DmHaltAddr(32'h00100000), .DmExceptionAddr(32'h00100000)
  ) u_ibex (
    .clk_i(clk_i), .rst_ni(rst_ni), .test_en_i(1'b0), .scan_rst_ni(1'b1),
    .ram_cfg_icache_tag_i('{default: prim_ram_1p_pkg::RAM_1P_CFG_REQ_DEFAULT}),
    .ram_cfg_icache_tag_o(),
    .ram_cfg_icache_data_i('{default: prim_ram_1p_pkg::RAM_1P_CFG_REQ_DEFAULT}),
    .ram_cfg_icache_data_o(),
    .hart_id_i(32'b0), .boot_addr_i(32'h00100000), .trvk_heap_base_addr_i(32'b0),
    .instr_req_o(instr_req), .instr_gnt_i(instr_gnt), .instr_rvalid_i(instr_rvalid),
    .instr_addr_o(instr_addr), .instr_rdata_i(instr_rdata),
    .instr_rdata_intg_i(instr_rdata_intg), .instr_err_i(instr_err_q),
    .data_req_o(data_req), .data_gnt_i(data_gnt), .data_rvalid_i(data_rvalid),
    .data_we_o(data_we), .data_be_o(data_be), .data_addr_o(data_addr),
    .data_wdata_o(data_wdata), .data_wdata_intg_o(), .data_tag_o(),
    .data_rdata_i(data_rdata), .data_rdata_intg_i(data_rdata_intg),
    .data_tag_i(1'b0), .data_err_i(data_err_q),
    .trvk_revbm_req_o(), .trvk_revbm_gnt_i(1'b0),
    .trvk_revbm_rvalid_i(1'b0), .trvk_revbm_addr_o(),
    .trvk_revbm_rdata_i('0), .trvk_revbm_rdata_intg_i('0), .trvk_revbm_err_i(1'b0),
    .irq_software_i(1'b0), .irq_timer_i(1'b0), .irq_external_i(1'b0),
    .irq_fast_i(15'b0), .irq_nm_i(1'b0),
    .scramble_key_valid_i('0), .scramble_key_i('0), .scramble_nonce_i('0),
    .scramble_req_o(), .debug_req_i(1'b0), .crash_dump_o(),
    .double_fault_seen_o(),
    .fetch_enable_i(ibex_pkg::IbexMuBiOn),
    .mcounteren_writable_i(ibex_pkg::IbexMuBiOn),
    .alert_minor_o(), .alert_major_internal_o(),
    .alert_major_bus_o(), .core_sleep_o(),
    .lockstep_cmp_en_o(),
    .data_req_shadow_o(), .data_we_shadow_o(), .data_be_shadow_o(),
    .data_addr_shadow_o(), .data_wdata_shadow_o(), .data_wdata_intg_shadow_o(),
    .instr_req_shadow_o(), .instr_addr_shadow_o()
  );
endmodule
