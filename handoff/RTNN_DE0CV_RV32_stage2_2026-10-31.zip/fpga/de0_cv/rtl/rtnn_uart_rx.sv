// UART 8N1 receiver. Each byte is a 1-cycle pulse on valid_o.
// Two-flop RX synchronizer. Single-byte mailbox and overrun detection live
// in the SoC (one command at a time, host waits for response).
module rtnn_uart_rx #(
  parameter integer CLOCK_HZ=50_000_000,
  parameter integer BAUD=115_200,
  parameter integer DIVISOR=(CLOCK_HZ + BAUD/2)/BAUD,
  parameter integer COUNT_BITS=$clog2(DIVISOR+1)
)(
  input logic clk_i,
  input logic rst_ni,
  input logic rx_i,
  output logic [7:0] byte_o,
  output logic valid_o,
  output logic framing_error_o
);
  typedef enum logic [1:0] {IDLE,START,DATA,STOP} state_t;
  state_t state_q;
  logic rx_meta_q,rx_sync_q;
  logic [COUNT_BITS-1:0] ticks_q;
  logic [2:0] index_q;
  logic [7:0] shift_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if(!rst_ni) begin
      rx_meta_q<=1'b1;rx_sync_q<=1'b1;
      state_q<=IDLE;ticks_q<='0;index_q<='0;shift_q<='0;
      byte_o<='0;valid_o<=1'b0;framing_error_o<=1'b0;
    end else begin
      rx_meta_q<=rx_i;
      rx_sync_q<=rx_meta_q;
      valid_o<=1'b0;
      framing_error_o<=1'b0;
      case(state_q)
        IDLE: if(!rx_sync_q) begin
          ticks_q<=COUNT_BITS'((DIVISOR/2)-1);
          state_q<=START;
        end
        START: if(ticks_q!=0) ticks_q<=ticks_q-1'b1;
               else if(rx_sync_q) state_q<=IDLE;
               else begin
                 ticks_q<=COUNT_BITS'(DIVISOR-1);
                 index_q<=0;
                 state_q<=DATA;
               end
        DATA: if(ticks_q!=0) ticks_q<=ticks_q-1'b1;
              else begin
                shift_q[index_q]<=rx_sync_q;
                ticks_q<=COUNT_BITS'(DIVISOR-1);
                if(index_q==3'd7) state_q<=STOP;
                else index_q<=index_q+1'b1;
              end
        STOP: if(ticks_q!=0) ticks_q<=ticks_q-1'b1;
              else begin
                if(rx_sync_q)begin byte_o<=shift_q;valid_o<=1'b1;end
                else framing_error_o<=1'b1;
                state_q<=IDLE;
              end
        default:state_q<=IDLE;
      endcase
    end
  end
endmodule
