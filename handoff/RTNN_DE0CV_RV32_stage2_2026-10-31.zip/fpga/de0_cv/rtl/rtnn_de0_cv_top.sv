// DE0-CV top level: 50-MHz oscillator, active-low KEY[0] reset,
// four diagnostic LEDs, and 3.3-V UART TX over GPIO_0_D0 (PIN_N16).
module rtnn_de0_cv_top (
  input  logic CLOCK_50,
  input  logic [0:0] KEY,
  output logic [3:0] LEDR,
  output logic GPIO_0_D0,
  input  logic GPIO_0_D1
);
  // Synchronous reset deassertion; asynchronous assertion from KEY0.
  logic [2:0] rst_pipe_q;
  always_ff @(posedge CLOCK_50 or negedge KEY[0]) begin
    if (!KEY[0]) rst_pipe_q <= 3'b0;
    else rst_pipe_q <= {rst_pipe_q[1:0],1'b1};
  end
  wire sys_rst_n = rst_pipe_q[2];
  logic uart_idle, halted, bus_fault;
  logic [25:0] heartbeat_q;
  always_ff @(posedge CLOCK_50 or negedge sys_rst_n) begin
    if (!sys_rst_n) heartbeat_q <= '0;
    else heartbeat_q <= heartbeat_q + 26'd1;
  end
  rtnn_de0_cv_soc u_soc (
    .clk_i(CLOCK_50), .rst_ni(sys_rst_n), .uart_tx_o(GPIO_0_D0),
    .uart_rx_i(GPIO_0_D1),
    .uart_idle_o(uart_idle), .halted_o(halted), .bus_fault_o(bus_fault)
  );
  assign LEDR = {bus_fault, halted, !uart_idle, heartbeat_q[25]};
endmodule
