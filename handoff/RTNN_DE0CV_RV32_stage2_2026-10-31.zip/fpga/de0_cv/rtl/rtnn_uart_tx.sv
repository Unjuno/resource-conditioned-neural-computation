// 8N1 UART, 3.3-V CMOS output; no FIFOs or DMA.
// A start is accepted only when ready_o is high. The data bus stalls until
// ready_o, so the existing SIM_OUT writes are lossless despite their speed.
module rtnn_uart_tx #(
  parameter integer CLOCK_HZ = 50_000_000,
  parameter integer BAUD = 115_200,
  parameter integer DIVISOR = (CLOCK_HZ + BAUD/2) / BAUD,
  parameter integer COUNT_BITS = $clog2(DIVISOR+1)
) (
  input  logic       clk_i,
  input  logic       rst_ni,
  input  logic       start_i,
  input  logic [7:0] data_i,
  output logic       tx_o,
  output logic       ready_o
);
  logic [COUNT_BITS-1:0] ticks_q;
  logic [9:0] bits_q;
  logic [3:0] remaining_q;
  logic busy_q;
  assign ready_o = !busy_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ticks_q <= '0;
      bits_q <= 10'h3ff;
      remaining_q <= 4'd0;
      tx_o <= 1'b1;
      busy_q <= 1'b0;
    end else if (!busy_q) begin
      tx_o <= 1'b1;
      if (start_i) begin
        // Bitstream from LSB: start(0), data[0..7], stop(1).
        bits_q <= {1'b1, data_i, 1'b0};
        remaining_q <= 4'd10;
        ticks_q <= DIVISOR - 1;
        tx_o <= 1'b0;
        busy_q <= 1'b1;
      end
    end else if (ticks_q != 0) begin
      ticks_q <= ticks_q - 1'b1;
    end else begin
      ticks_q <= DIVISOR - 1;
      bits_q <= {1'b1,bits_q[9:1]};
      remaining_q <= remaining_q - 1'b1;
      tx_o <= bits_q[1];
      if (remaining_q == 4'd1) begin
        busy_q <= 1'b0;
        tx_o <= 1'b1;
      end
    end
  end
endmodule
