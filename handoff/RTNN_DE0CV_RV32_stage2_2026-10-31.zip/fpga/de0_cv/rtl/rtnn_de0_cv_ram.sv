// RTNN candidate FPGA memory: 256 KiB physical RAM, byte write enable,
// two independent synchronous 32-bit read ports (one read/write, one read).
// IMPORTANT: Inference to M10K/one-cycle latency MUST be checked in Quartus
// post-synthesis reports and the fitted design. Not a memory timing proof.
module rtnn_de0_cv_ram #(
  parameter INIT_HEX = "rtnn_ram_words.hex"
) (
  input  logic        clk_i,
  input  logic        rst_ni,
  input  logic        data_req_i,
  input  logic        data_we_i,
  input  logic [3:0]  data_be_i,
  input  logic [31:0] data_addr_i,
  input  logic [31:0] data_wdata_i,
  output logic        data_hit_o,
  output logic        data_rvalid_o,
  output logic [31:0] data_rdata_o,
  input  logic        instr_req_i,
  input  logic [31:0] instr_addr_i,
  output logic        instr_hit_o,
  output logic        instr_rvalid_o,
  output logic [31:0] instr_rdata_o
);
  // 0x00100000..0x0013ffff is directly mapped.
  // 0x001f8000..0x001fffff aliases physical 0x00138000..0x0013ffff.
  // This preserves the EXACT frozen ELF's stack pointer 0x001ffff0.
  function automatic logic is_direct(input logic [31:0] a);
    is_direct = ((a & 32'hfffc0000) == 32'h00100000);
  endfunction
  function automatic logic is_stack_alias(input logic [31:0] a);
    is_stack_alias = ((a & 32'hffff8000) == 32'h001f8000);
  endfunction
  function automatic logic [15:0] word_index(input logic [31:0] a);
    if (is_stack_alias(a)) word_index = {3'b111, a[14:2]};
    else word_index = a[17:2];
  endfunction

  assign data_hit_o  = is_direct(data_addr_i) || is_stack_alias(data_addr_i);
  assign instr_hit_o = is_direct(instr_addr_i);

  // Make read/write traffic explicit. This array is the ONLY on-chip
  // inference memory. Fit/resource/port counts must be checked, not assumed.
  (* ramstyle = "M10K" *) logic [31:0] mem [0:65535];
  initial begin
    $readmemh(INIT_HEX, mem);
  end
  wire [15:0] data_idx = word_index(data_addr_i);
  wire [15:0] instr_idx = word_index(instr_addr_i);

  // Data port: one-cycle synchronous read/byte-masked write.
  always_ff @(posedge clk_i) begin
    if (data_req_i && data_hit_o) begin
      data_rdata_o <= mem[data_idx];
      if (data_we_i) begin
        for (integer k = 0; k < 4; k = k + 1)
          if (data_be_i[k]) mem[data_idx][k*8 +: 8] <= data_wdata_i[k*8 +: 8];
      end
    end else if (data_req_i) begin
      data_rdata_o <= 32'b0;
    end
  end
  // Instruction port: one-cycle synchronous read only.
  always_ff @(posedge clk_i) begin
    if (instr_req_i && instr_hit_o) instr_rdata_o <= mem[instr_idx];
    else if (instr_req_i) instr_rdata_o <= 32'b0;
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      data_rvalid_o <= 1'b0;
      instr_rvalid_o <= 1'b0;
    end else begin
      data_rvalid_o <= data_req_i;
      instr_rvalid_o <= instr_req_i;
    end
  end
endmodule
