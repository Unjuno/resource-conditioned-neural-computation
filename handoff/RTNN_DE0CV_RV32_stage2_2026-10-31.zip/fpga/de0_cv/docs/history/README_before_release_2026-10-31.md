> **2026-10-29 construction update:** PC-side v2 experiment driver, 360-input dataset, binary protocol, new B firmware scaffold, UART RX candidate, separate B build image, and primary E4 paired analysis added. Host GCC/Python tests pass, but **Ibex-on-new-SoC RTL simulation, sv2v conversion, Quartus/STA, full 360 Q15 oracle, and board operation have NOT passed**. See [`docs/IMPLEMENTATION_PROGRESS_2026-10-29.md`](docs/IMPLEMENTATION_PROGRESS_2026-10-29.md) for exact commands, claims, and blockers. This archive is **not ready-to-flash**.

# RTNN DE0-CV rebuild — exact-binary FPGA feasibility candidate

> **OFFLINE AUDIT UPDATE (2026-10-30):** This candidate now has a pinned complete 360-input native-Q15 oracle, a 10,080-case actual-model native firmware control gate, a 720-frame synthetic-Q15 wire regression, repaired data-audit semantics, and a hardware runbook. **No new FPGA RTL simulation, Quartus Fitter/STA, or physical measurement was performed.** See [docs/OFFLINE_VERIFICATION_STATUS.md](docs/OFFLINE_VERIFICATION_STATUS.md), [docs/BOARD_DAY0_TO_PAPER_RUNBOOK.md](docs/BOARD_DAY0_TO_PAPER_RUNBOOK.md), and [docs/CHANGELOG_FROM_STAGE1.md](docs/CHANGELOG_FROM_STAGE1.md).


**State: host tooling verified; RTL conversion, RTL simulation, Quartus synthesis, fitting, and board validation NOT YET EXECUTED.** This is **not** a certified hard-real-time target or a ready-to-flash bitstream.

## Architecture

Reuse the **exact** immutable `rtnn_ibex_rtl.elf` and `rtnn_ibex_rtl.bin` from the main RTNN repository's pinned Simple-System simulation. **Do not retrain the seed-63 model.** The original certified software binary uses a 1-MiB virtual on-chip-RAM interval, but its actual load segment occupies only 122,312 bytes (including BSS). To implement on the DE0-CV A4 device, a *new* 256-KiB M10K candidate RAM is used:

| Virtual access | Physical 256-KiB RAM offset | Role |
|---|---|---|
| `0x00100000..0x0013ffff` | `0x00000..0x3ffff` | direct RAM window |
| `0x001f8000..0x001fffff` | `0x38000..0x3ffff` | stack alias; original SP=`0x001ffff0` |
| `0x00020000` | UART TX (stalls while busy) | original `SIM_OUT` replacement |
| `0x00020008` | halt LED latch | original `SIM_HALT` replacement |
| `0x00020004` | UART ready (optional) | reserved new status |
| `0x0002000c` | `RTNN` marker (NOT build identity) | reserved new read-only marker |

The physical stack page intentionally does **not** overlap the ELF's `.text`, `.rodata`, `.data` or `.bss`. The alias is a **new hardware assumption**. The original linker defines the stack at `0x001ffff0`; a naive 256-KiB truncation would not work. The host generator parses ELF program/section/symbol tables and refuses unexpected binaries/layouts.

The processor configuration reproduces the pinned CPU parameters (`SecureIbex=1`, single-cycle multiplier, no I-cache/branch prediction), but the **SoC, RAM, bus timing, and UART are different**. No Simple-System cycle numbers are imported as FPGA bounds.

## What is included

- `artifacts/rtnn_ibex_rtl_exact.zip`: repository-frozen verified ZIP (re-downloaded from successful GitHub Actions).
- `tools/frozen_image.py`: verifies three SHA-256 hashes, PT_LOAD vs `.bin`, 1-MiB stack symbol, and memory-fit invariants. Emits 65,536 32-bit little-endian ROM words (`quartus/rtnn_ram_words.hex`), MIF, preflight JSON, and artifact manifest.
- `rtl/rtnn_de0_cv_soc.sv`: **candidate** direct Ibex integration, 256-KiB two-port RAM, UART backpressure, 1-cycle accepted response mux, instruction/data SECDED, unmapped-address error signal.
- `rtl/rtnn_de0_cv_ram.sv`: **candidate** Cyclone V M10K-inferred RAM. Post-fit RAM mapping and one-cycle response must be inspected; no inference-only claim accepted.
- `rtl/rtnn_uart_tx.sv`: bare-metal 8N1 TX. `SIM_OUT` can work unmodified because bus grant blocks while transmitter is occupied.
- `quartus/rtnn_de0_cv.qsf`, `.qpf`, `.sdc`: Cyclone V device, documented DE0-CV clock/KEY/LED/GPIO pin assignments, 50-MHz clock constraint. GPIO UART is 3.3-V TTL, **not** +/- RS-232.
- `tools/capture_audit.py`: strict original `OVERHEAD/CERT/E2E/DONE` record validator using three frozen vectors and seven classes; no missing/duplicate/tampered records pass.
- `tools/empirical_report.py`: calls strict validator; emits **observations only**, never WCET/bounds.
- `tools/check_quartus_evidence.py`: hash reports, bitstream and capture; NEVER asserts STA/memory correctness from filenames.
- `tests/fixtures/known_good_sim_uart.log`: **real original Ibex simulation log** from the pinned zip (42 verified inference records).
- `tools/serial_capture.py`: optional pyserial capture from a physically wired board.

## Run host preflight (executed in our development container)

```sh
python3 -m pip install pytest
./tools/preflight.sh
```

Expected status: `HOST_PREFLIGHT=PASS`. This certifies **only** image preparation, host-side invariants, and UART log validators.

## FPGA toolchain blockers before a working `.sof`

Ibex **cannot be synthesized directly with Quartus Prime Lite/Standard** per upstream Ibex's documented SystemVerilog limitations. The candidates here therefore require a pinned Ibex source checkout, an **ordered, reviewed synthesis-only** FuseSoC/EDAM dependency list (exclude simulation-only DPI sources), `sv2v` conversion of Ibex *and the RTNN SoC wrapper*, **independent pre/post-conversion RTL simulation**, and Quartus synthesis/Fitter/STA.

```sh
./tools/toolchain_gate.sh  # nonzero means synthesis/sim cannot run here
# Supply pinned checkout and a source list from a reviewed FuseSoC/EDAM graph:
IBEX_ROOT=/path/to/ibex \
IBEX_SOURCE_LIST=/path/to/ordered_sources.txt \
  ./tools/make_quartus_flat.sh
# This creates quartus/ibex_flat.v; it does NOT assert functional/cycle equivalence.
cd quartus
quartus_sh --flow compile rtnn_de0_cv
```

**Do not fabricate `ibex_flat.v` or claim a successful compile without this gate.** `quartus/ibex_flat.v` is deliberately **absent** until the pinned conversion succeeds. Before programming, inspect timing, .fit memory block count and RAM init data, memory-port semantics, and any critical warnings. A passing Fitter alone does not establish input-independent cycles.

## Onboard capture (only after full RTL/conversion/synthesis gates)

Connect GPIO_0_D0 (PIN_N16) to the **RX pin of an external 3.3-V TTL UART adapter**, with a shared GND; never apply 5-V UART or RS-232 voltages. Hold KEY[0] reset while starting capture, release it, then:

```sh
python3 -m pip install pyserial
python3 tools/serial_capture.py --port /dev/ttyUSB0 --baud 115200 \
  --out captures/board_uart.log --expected-sof quartus/output_files/rtnn_de0_cv.sof
python3 tools/capture_audit.py --reference quartus/preflight_reference.json \
  --uart-log captures/board_uart.log --out captures/capture_audit.json
python3 tools/empirical_report.py --reference quartus/preflight_reference.json \
  --uart-log captures/board_uart.log --clock-hz 50000000 \
  --origin fpga_unverified --out captures/observed_timing.json
```

`capture_audit=PASS_REFERENCE_CONSISTENT` only means captured text matches reference; it does NOT prove build identity, timing completeness, or WCET. The exact frozen firmware's `E2E` path **still contains the old Simple-System `RTL_TOTAL`**, so its *admission decisions are NOT valid FPGA certification*. A *second* FPGA-specific admission firmware binary and a new proof/binding are required before any deadline guarantee.

## Acceptance gates

| Gate | Required evidence | Present? |
|---|---|---|
| H0 exact frozen machine image + reference | ZIP/ELF/BIN SHA, ELF symbol layout, real simulation regression | **YES** |
| H1 freeze upstream conversion | pinned Ibex source list, `sv2v`, equivalence results | **NO** |
| H2 RTL unit tests | Verilator RAM alias/UART test and whole-SoC run | **NOT RUN** (tools absent) |
| H3 Quartus compilation | Fitter RAM mapping, STA setup/hold, actual `.sof` | **NO** |
| H4 DE0-CV execution | captured exact 21 CERT + 21 E2E cases | **NO** |
| H5 defensible FPGA timing/admission | new target-specific bound argument, separate software identity | **NO** |

Do not call this board-ready until H1–H3 close. No core/FPGA equivalence or timing guarantee is currently asserted.

## Provenance

Current RTNN repository: `Unjuno/resource-conditioned-neural-computation`, `main` HEAD `ea903d3b76c4cb50732c3f9c72c8ed2084c2cb23`. Pinned Ibex upstream: `7b5df75a041affe56e8c235260f98a09b3319008`. Frozen ZIP SHA: `9150b0763e5d7b7c305441befdb4161ccf95612edd924b525f8388e06d9a86b0`.

References: [RTNN preregistered DE0-CV experiment](https://github.com/Unjuno/resource-conditioned-neural-computation/blob/main/notes/realtime_nn_de0_cv_next_stage.md), [Ibex upstream tool requirements](https://ibex-core.readthedocs.io/en/latest/02_user/system_requirements.html), [Terasic official DE0-CV documents](https://www.terasic.com.tw/cgi-bin/page/archive.pl?CategoryNo=13&Language=English&No=921&PartNo=4), [Cyclone V embedded-memory specifications](https://docs.altera.com/r/docs/683375/current/cyclone-v-device-handbook-volume-1-device-interfaces-and-integration/embedded-memory-capacity-in-cyclone-v-devices).
