# Execution ledger — existing-method paper preparation, 2026-10-31

Scope: original start-of-inference admission / hard cap / entropy stopping only.
Base: RTNN_DE0CV_offline_ready_2026-10-30.zip, isolated extracted copy.
GitHub read: Q15 core blob still 3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a.
No remote writes, commits, branches, or modifications of prior archives.

## Tasks
1. Baseline re-run and correctness fixes in existing experiment tools.
2. Frozen, reproducible same-model campaign with complete comparisons.
3. Board evidence gate + multi-session paper analysis + non-fabricated outputs.
4. Documentation/claim partition + clean-package reproduction.

## Preflight
- Existing tests: 63/63 PASS (fresh run; evidence/release_2026-10-31/baseline_pytest.log).
- Current available tools: gcc, clang, Python. Verilator/sv2v/Quartus/RISC-V GCC absent.
- Attempt to reach Debian package host failed DNS. No installation or EDA result claimed.
- Ruling: no git worktree for this archive-only input; isolated extracted copy provides isolation.
- Ruling: do not import the time-feedback package; preserve it separately and freeze v1 method.
- Ruling: use one fixed seed-63 artifact; this is a same-model hardware case study, not new multi-seed ML generalization.
- Task interface: firmware CAPPED executes raw budget up to exit 6; auditor incorrectly applies adaptive max 5. Add regression before fix.
- Task interface: failed UART replies currently disappear from accepted-only trace. Preserve raw transactions separately before semantic validation.

## Implemented and verified
- Task 1: complete locally. Regression tests demonstrated capped-no-stop exit6 rejection and loss of failed/partial UART replies before fixes. Both fixed; existing core/weights unchanged.
- Task 2: complete locally. Frozen 13-session campaign (24,840 requests), adjacent same-input pairs and balanced AB/BA, ten cold boots for primary comparison.
- Task 3: complete at software/test level. Physical evidence and external file hashes are required; synthetic/RTL data blocked. Multi-session paired statistics use 360 unique inputs, not 3,600 accuracy samples. Negative speed results remain reportable.
- Task 4: docs/claim map/manuscript skeleton added; no physical numbers filled in.
- Full native gate: 2,520 fixed + 7,560 adaptive actual-Q15 cases match; fake cycle callback is explicitly not timing evidence.

## Final review
Final review: self-review (no subagent/reviewer tool available).
Important finding 1: plots could silently use changed derived CSV. Regression failed first; fixed by hashing derived CSVs into results.json and checking them before plotting.
Important finding 2: valid IDs with reordered acquisition could defeat the planned AB/BA order. Regression failed first; fixed by requiring actual sequence order to match the frozen schedule.
Both fixes verified with full suite: 77/77 PASS, with actual-model native gate also rerun.

## Rulings and remaining costs
- Ruling: work in an isolated archive copy, no commit/push — preserves remote main and original archives; changes are tracked by release inventory rather than git commits.
- Ruling: exclude time-feedback/GPU additions — requested scope; this release cannot answer the value of those extensions.
- Ruling: freeze one existing model/known test split — prevents further tuning; limits conclusions to a hardware replication case study.
- Ruling: primary physical campaign is B without deadline binding — allows honest cycle/accuracy comparison; hard-RT and physical admission remain unestablished until a separate C build.
- Ruling: no synthetic EDA or board success — tools absent and package-network DNS unavailable; still requires full RTL/conversion/Quartus/board gates.
- Deferred minor: automated exact-version parsing of Quartus report semantics. Operator review and hashed reports are required; current gate validates presence/integrity, not the truth of all report judgments.
- Deferred minor: automatic manuscript prose/novelty judgment. Tables/figures are generated, but the author must interpret results and review prior work.
- Open major dependency, NOT a passed gate: dependency graph resolution, new whole-SoC RTL execution, sv2v equivalence, final RV32 B equivalence, Quartus Fitter/STA, physical acquisition.
