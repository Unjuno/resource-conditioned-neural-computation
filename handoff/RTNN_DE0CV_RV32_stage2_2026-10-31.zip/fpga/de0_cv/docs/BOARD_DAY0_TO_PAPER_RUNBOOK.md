# RTNN DE0-CV: 実機が使える日の実行手順 v1

状態: **事前登録した手順。未実施。** 2026-10-30。実機とEDAツールが未接続の環境では FPGA/RTL/STA の PASS を記録してはならない。

## 0. 役割と主張を混ぜない

- **A (legacy frozen ELF)**: 旧Ibex Simple Systemで通った3入力×7固定・3入力×7adaptiveの42ケースを、新FPGA SoCで実行する *移植検証*。ハードウェアcycle値は**新規**で、旧値は流用しない。旧ELFにはSimple Systemのdeadline表がある。Aのdeadline決定はFPGAの時間保証ではない。
- **B (new experiment ELF)**: 同じseed-63 Q15固定重み・Cコアの新しい実験用firmware。固定7深さ、21予算、360固定評価入力、paired fixed2/adaptiveを測定。現状のB firmwareは `has_fpga_cycle_binding=0` でdeadline実行を拒否する。
- **C (new admission build)**: Bと独立したbuild identity。FPGA固有の時間上界をレビューした後に作る。Cの結果をBのELFやAの上界と混ぜない。

## 1. セットアップと真正性 (G0: first day, before power-on)

1. ボードの型番、PCB revision、搭載FPGAの刻印、ケーブル、電源、USB-Blasterを写真と紙面記録。DE0-CV/5CEBA4F23C7Nと一致するか確認。
2. GPIO UART接続は3.3-V TTL（共通GND）。RS-232電圧、5-Vを接続しない。PIN_N16 TX / PIN_B16 RXは候補QSFと公式資料で再照合。
3. Quartus Prime Lite (Cyclone V対応版 + device support)、USB-Blaster driver、Verilator、sv2v、RISC-V GCC、FuseSoC/Edalizeを準備。バージョンとSHAを保存。
4. `bash tools/toolchain_gate.sh`、`bash tools/preflight.sh`、`python3 -m pytest -q tests` を実行してログ保存。
5. GitHub `main`とIbex commit、ZIP/ELF/BIN/Q15 weights SHAに差分があれば停止。新しいbuildは必ず別のIDを付与。

**G0 PASS**: toolchain全項目が存在し、凍結アーティファクトSHAが一致、host回帰がグリーン。欠けていればFPGA FLASHに進まない。

## 2. ソフトウェアだけで行う回路確認 (G1–G3)

1. `bash tools/run_rtl_unit_tests.sh` で RAM alias・byte-enable・read-during-write規則、UART TX/RXをテスト。RAM衝突時の値は指定した構造に即して証明し、不定値を成功扱いしない。
2. Ibex `7b5df75a041affe56e8c235260f98a09b3319008`の**正確な**FuseSoC依存グラフから、シミュレーション専用DPIを除いたordered RTL listを生成・記録。
3. 同じ新SoCの SystemVerilog と `sv2v` 変換後Verilogを、**同じfrozen program / memory init / reset**でシミュレーションする。旧Simple-Systemと異なるcycle値をただちにFAILとしないが、同じ新SoCの変換前後ではcycle/実行経路が一致するか検査。
4. 全Aの42件を予測・実行exit・トラップ・UARTフレームの一致で監査。`mcycle`計測境界、cache/interrupt設定、初期状態を凍結。

**G1–G3 PASS**: 単体テスト合格、変換前後の全機能一致、変換が変更していないことの実測ログ、42/42 functional。**現行環境では未実行**。

## 3. Quartus synthesis/Fitter/STA (G4)

```sh
# 外部の正確なIbex toolchain/source listが必要
IBEX_ROOT=/abs/verified/pinned/ibex IBEX_SOURCE_LIST=/abs/verified/fusesoc.edam.sources \
  bash tools/make_quartus_flat.sh
cd quartus
quartus_sh --flow compile rtnn_de0_cv
```

必ず保存する: `.qsf/.sdc`、Quartusの版とデバイス、source list、変換済みVerilog SHA、RAM `.hex/.mif` SHA、FitterのM10K/ALM/DSP使用量、メモリ推論と初期化レポート、setup/holdなどのSTA結果、critical warnings、`.sof` SHA。

- 256 KiB true-dual-port RAMが必要なポート意味論のまま合成されていることを**Fitterで確認**。容量の概算はPASS証拠にならない。
- 50 MHzは目標値。STA failureならクロックを下げる/回路を直し、新しいconfiguration identityとする。
- PLL、reset同期、クロックドメイン、input/output constraints、RAM read-during-write動作に未解析経路があればSTOP。

**G4 PASS**: 完成したSOF、正しいRAM init、物理実装構造、STA closureを明示した証拠が存在する。**現行環境では未実行**。

## 4. 基板のbring-up (G5a)

1. 最小回路でLED/reset/JTAG/デバッグ出力を検査し、最初からNNを動かさない。**最小回路のSOFは論文計測SOFとは別**。
2. AのSOFを書き込み、成功ログと実際のケーブルID、program時刻、SOF SHA、board revisionを保存。
3. `python3 tools/serial_capture.py --port <実際のUARTデバイス> --baud 115200 --out captures/A_uart.log --expected-sof quartus/output_files/rtnn_de0_cv.sof`。
4. `python3 tools/capture_audit.py --reference quartus/preflight_reference.json --uart-log captures/A_uart.log --out captures/A_audit.json`。
5. 10 cold boot + 10 resetでAの42件を検査。CPU例外、受信ビット抜け、CRC異常、trapはFAIL。旧cycle値を期待値として使わない。

**G5a PASS**: 42/42機能一致、観測したreset再現性、SOF書き込み証跡。旧Ibexのdeadline上界を引き継がない。

## 5. Bの論文用計測 (G5b, primary experiment)

```sh
# 新しいBは現在のAの凍結ELFとは別物。RV32コンパイラ必須。
bash tools/build_b_firmware.sh upstream/source_repo
# 凍結Q15参照との比較は事前に再実行
bash tools/build_q15_oracle.sh upstream/source_repo
python3 tools/offline_q15_firmware_gate.py --root . --out build/native_q15_fw
```

1. B固有ELF/BIN・RAMイメージで再度G1-G4を通す。既存AのSOFをB用として使うことは禁止。
2. 実基板に**外部から入力番号・方式・予算を指示**し、CPU側で開始/停止cycleを読む。計測区間にはNN演算とentropy判定を含めるがUARTログ送信は含めない（含める場合は別のエンドツーエンド実験）。
3. 以下の順に実施する。各runに`run_id`、`boot_id`、`repetition_id`、`build_id`を保存し、乱数seedと実際の送信順を必ず保存する。
   - `matrix_fixed.json`: 360入力 × 7固定出口 = **2,520**。
   - `matrix_adaptive.json`: 360 × 21 budgets = **7,560**。
   - `matrix_paired.json`: 360 × fixed2/adaptive = **720**。最低3独立boot、各入力・方式10測定を初期計画値とする。run/bootと入力単位を混同しない。
4. ホスト・基板の両方でraw request/response bytesを残し、`CAPTURE_COMPLETE_UNAUDITED`以外はPASSを出さない。
5. 全件を **実際の凍結Q15予測 SHA `03eb958c...`** と照合する。`experiment_audit.py --q15-oracle generated/frozen_q15_oracle.json --expected-q15-predictions-sha256 03eb958cfa8b4fd2f71a95fb47dbca512820c237c281473817bba685b92c743e` を使用。`--expected-sof-sha256`、`--expected-build-id`、`--expected-binding-id 0`も固定。
6. `experiment_report.py`で入力別のpaired cycle、正誤、差、boot別分散とCIを集計。**同じ入力で同じ結果でも、方式の実行条件が違えば比較をやり直す**。

**G5b FUNCTION PASS**: Q15/physical exit一致、budget超過0、予測相違0、trap/bus/UART fault0。**SPEEDUP PASS**は別で、同等精度固定2に対し平均総cycle削減とpaired CIの下限が正で、精度非劣性が登録閾値を満たす場合のみ。

## 6. Deadline pilotと認証の境界 (G6)

- **今のB firmwareではdeadlineはdisabled**。`has_fpga_cycle_binding=0`であるため、実機で今すぐdeadline testを走らせてはいけない。
- 実機で新たに得た**観測値**を使った探索的pilotは`EMPIRICAL_EXPLORATORY_ONLY`として隔離。`bind_deadlines()`は7上限とSHAを新規に結び、`experiment_driver`は`--allow-exploratory-deadline`がない場合reject。pilotをWCET保証と呼ばない。
- 実機構成・コード・RAM応答・外乱・STAに対する**防御可能な上界議論**が成立した後、別のC firmware/binding identityでdeadline admissionを実装・再検証。時間表やUARTロギングによるELF差分があればすべて再監査。
- 新Cのdeadline各境界の `N_j-1`, `N_j`, `N_j+1`、0、無効／部分表、別manifest、別build、別bitstream、再起動直後、最大負荷経路を含む。
- 認証が未成立なら `HARD_RT = UNCERTAIN` に固定し、主張を増やさない。

## 7. 実機で必ず保存する証拠

- `RUN_ID/meta.json`: board/PCB、SOF/ELF/BIN/Q15/sourceのSHA、Quartus/verilator/sv2v/RISC-V GCC版、clock constraint、Fitter/STA情報、RAM配置、割込み/DMA/他masterの有無、UART配線・baud、コールド/ウォーム状態、測定開始停止点、温度/電圧(取得可能なら)。
- `RUN_ID/programming.log`: USB-Blaster/Quartus書込操作と結果、デバイスIDの照合。
- `RUN_ID/raw.bin` と `RUN_ID/trace.json`: 元のUART全バイトとparse後レコード、欠損/拒否/タイムアウトのフラグ。生ログは改ざんせずSHAを付ける。
- `RUN_ID/inputs.json`, `RUN_ID/matrix.json`, `RUN_ID/q15_oracle.json`: すべてのSHAを明示し、元の360件と固定したスケジュールを外から照合できるようにする。
- `RUN_ID/audit.json` と `RUN_ID/analysis.json`: 失敗も保存し、都合の良いrunだけを残さない。
- `RUN_ID/binary_proof/`: 新C ELFについてCBMC/binary control-flowとメモリパス再監査を行う場合、その対象ファイルのhash・解析ツール版・生ログを保存。

## 8. H/T/D/C/U と測定変数表

H: 同じ凍結Q15モデルで、適応的RTNNは固定2ブロックと同等精度で平均全実行cycle数を減らせる（第一の性能仮説）。また許可外の物理ブロックが実行されない（安全仮説）。

T: 最低360入力固定、21予算点、3 boot以上×各条件10反復(初期案)、paired順序をrunごとに交差。1件でも構造違反なら測定バッチを止めて原因調査。スピード仮説が不成立でも生ログは保持。

D: functional mismatch / cap violation は0がPASS。平均cycles削減のpaired 95%区間下限が正で、分類精度差のpaired 95%区間下限が**事前合意した非劣性幅**を満たすことを性能PASS条件とする。非劣性幅は測定前に決めること。観測最大のみのdeadline表はEMPIRICAL_ONLY。

C: entropy停止判定の固定反復除算が削減したブロック時間を相殺する、固定2が品質・時間の両面で優る、memory stall/非決定的副作用がある、run順・熱/クロック揺らぎが見かけの差を作る。

U: 時間境界・clock誤差・boot/run差・RAM衝突・入力有限性・Q15 quantization。合成標準不確かさ `u_c` と包含係数 `k` は実機測定・誤差モデルに基づいて後で記録し、数値を仮定で埋めない。

| 記号 | 意味（日本語） | SI単位 | 定義 | 定義域/前提 | 型 |
|---|---|---|---|---|---|
| `i` | 評価入力の識別子 | 1 | frozen test row | 0–359 | 整数スカラー |
| `r` | 反復の識別子 | 1 | boot/session内のrepetition | 1以上 | 整数スカラー |
| `C_fix(i,r)` | 固定2の実行cycle数 | 1（cycle計数） | `mcycle_end - mcycle_start` | 1以上、同じ計測区間 | 整数スカラー |
| `C_ad(i,r)` | adaptiveの実行cycle数 | 1（cycle計数） | 同上 | 1以上 | 整数スカラー |
| `S` | 平均cycle削減量 | 1（cycle計数） | mean(`C_fix-C_ad`) | 同一入力paired | 実数スカラー |
| `A` | 分類正答率 | 1 | 正答数 / 評価件数 | [0,1] | 実数スカラー |
| `f_clk` | 実機クロック周波数 | Hz = s^-1 | STA/物理クロック拘束 | 正 | 実数スカラー |
| `T` | NN計測区間の実時間 | s | `C / f_clk` | 同期単一クロックで追加待機がない | 実数スカラー |
| `D` | 実行期限 | s | admission入力 | 0以上 | 実数スカラー |
| `N_j` | class jの対象固有cycle上限 | 1（cycle計数） | 構造上界または不十分なら観測最大と明記 | 0以上 | 整数スカラー |
| `u_c` | 合成標準不確かさ | 測定量と同単位 | 誤差源の統合 | 未測定 | 実数スカラー |
| `k` | 包含係数 | 1 | 拡張不確かさ `k*u_c` | 明示する包含モデル | 実数スカラー |

次元チェック: `T = C / f_clk` では cycleを計数（無次元）として扱い、1/(s^-1)=s。`S`はcyclesの差、`A`は無次元。**cycles削減をクロック実測なしでmsと呼ばない**。

## 9. 保留事項（実機が届く前に埋めない）

- 完全な`sv2v`/FuseSoC合成可能ソースグラフ・変換前後の形式/シミュレーション等価性。
- Quartus FitterのM10K/ALM消費、RAM初期化と衝突規則、STA closure、最終SOF。
- 実ボードのID、適合する実機クロック値、安定したUART/起動、42/42移植PASS。
- Bの実機cycle、同等精度固定2へのcycle優位性、非劣性の信頼区間。
- CのFPGA専用時間上界・admission証明・実機deadline受理試験。

**進行原則: 実機試験の前段でどれかFAILなら後段へ進まず、失敗を隠さず保存する。**
