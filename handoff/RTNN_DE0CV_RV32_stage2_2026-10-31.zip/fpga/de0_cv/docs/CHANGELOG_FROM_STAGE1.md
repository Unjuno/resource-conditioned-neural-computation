# 2026-10-30 offline improvement (not an FPGA build)

**Scope:** isolated copy of `RTNN_DE0CV_stage1_2026-10-29.zip`; GitHub main unchanged.

## P0 integrity corrections

1. `tools/experiment_matrix.py` recomputes `schedule_sha256` after changing symbolic deadlines, and binds the 7 experimental bounds and binding ID. Explicitly tagged **UNVERIFIED_EXPLORATORY_ONLY**.
2. `tools/experiment_audit.py` rejects incomplete captures, inconsistent admitted budget, wrong stop cause, elapsed-cycle deadline overruns and deadline admissions inconsistent with the declared table. A self-labelled Q15 oracle JSON no longer earns a PASS without the externally pinned canonical predictions hash and its 360-input aggregate checks. This is file integrity, not device attestation.
3. `tools/experiment_driver.py` requires an explicit `--allow-exploratory-deadline` for unverified deadline pilot and captures legitimate REJECTED requests instead of treating them as a serial fault. The real B firmware still disables deadlines.
4. `tools/experiment_report.py` forwards independent Q15 SHA checks and explicitly labels non-physical observations.

## Real-model offline verification

5. Exact original source C/H from GitHub `main` was independently checked with `git hash-object`; generated weights extracted from the SHA-pinned ZIP. `tools/build_q15_oracle.sh` produced 360×7 native Q15 class predictions and 360 preferred exits. `generated/frozen_q15_oracle.json` and `build/q15/full_q15_reference.csv` now exist.
6. `tools/offline_q15_firmware_gate.py` compiled **real Q15** `rtnn_experiment_runner.c` under GCC and checked 2,520 fixed + 7,560 adaptive cases, not stubs. It discovered 7 mislabeled stop reasons at the policy's max-depth ceiling.
7. `firmware/rtnn_experiment_runner.c` now distinguishes entropy early-stop from reaching the validated policy's max useful class 5 even when budget grants class 6. A rejected request no longer reports a label.
8. `tools/offline_q15_protocol_fixture.py` generated and checked 720 paired binary requests/responses using genuine Q15 predictions. All timestamps/cycles in that trace are synthetic and **forbidden** in performance figures.
9. `tools/offline_reproduce.sh`, `tools/offline_manifest.py`, and `docs/BOARD_DAY0_TO_PAPER_RUNBOOK.md` provide reproducible offline gates, measured artifact hashes and concrete hardware/claim gates.

## Important NONCLAIMS

- `61+` passing host tests do NOT mean Quartus/Verilator/FPGA PASS.
- 339/360 correct for both fixed2 and adaptive is a **held-out native Q15** result, not a board result. There are **3 opposite-direction disagreements each** in paired correctness.
- A cycle callback in the native test fixture is deliberately fake. Do not use its numeric value in timing tables.
- Device/bitstream proof needs programming logs and hardware observations. 32-bit build IDs and user-supplied SOF SHA are not cryptographic device attestations.
- A B vs A binary mismatch is expected after this firmware edit. The RTL and certification evidence must be tied to exact new B/C artifacts.

Run: `bash tools/offline_reproduce.sh` from `fpga/de0_cv/`.
