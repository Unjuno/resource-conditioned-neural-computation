# DE0-CV RTNN — No-board verification summary (2026-10-30)

## Proof partition

- **VERIFIED_OFFLINE**: real frozen ZIP SHA; exact upstream C/H Git blobs; generated Q15 header SHA; generated 360-input/7-exit native integer-C oracle; native experimental firmware 2,520 fixed + 7,560 adaptive cases; 720 byte-encoded synthetic wire Q15 reference; patched semantic data auditor and regression tests.
- **NOT_VERIFIED**: new SystemVerilog SoC synthesis/elaboration; sv2v pre/post equivalence; Quartus Fitter; RAM physical placement/read-during-write; STA; SOF; physical board; target-specific FPGA cycle upper bounds; hard-real-time deadline certification; speedup over fixed2.

## Exact provenance

Repo GitHub main: `ea903d3b76c4cb50732c3f9c72c8ed2084c2cb23`.
Original C source git blob: `3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a`.
Original C header git blob: `ac185458e21b956db01cb18504bdb507c0c69618`.
Frozen artifact ZIP SHA256: `9150b0763e5d7b7c305441befdb4161ccf95612edd924b525f8388e06d9a86b0`.
Frozen weights SHA256: `961a76b7e220bf2f665e7c04ab62063600aa2e7eccf3403d80ea730bc993ad9f`.
Full 360-input canonical predictions SHA256: `03eb958cfa8b4fd2f71a95fb47dbca512820c237c281473817bba685b92c743e`.
Full real-native Q15 oracle CSV SHA256: `f6205c8a0be62745a99ce054eaa0af7f6689c8770bc5ef5e97b90d6a96847401`.

## Verified computation, strictly not physical latency

- 360 inputs; fixed exit accuracies: `[171,328,339,338,336,336,333]` correct (each denominator 360).
- Seed63 preferred histogram `[0,263,81,7,2,7,0]`, mean preferred blocks `489/360 = 1.358333`.
- Fixed2 correct 339/360; adaptive correct 339/360; **3 adaptive-only correct and 3 fixed2-only correct**: equal aggregate accuracy does not mean identical predictions.
- Native firmware 2,520 fixed and 7,560 adaptive cases; zero mismatches vs frozen Q15 predictions/preferred-depth semantics after correcting **7 incorrect stop_reason records** when budget granted 6 blocks but deployed policy cap is 5.
- Deliberately synthetic binary UART roundtrip 720 frames with **actual Q15 predictions**; 720/720 oracle-checked. Synthetic clock values are NOT performance results.
- The main experiment auditor now rejects inconsistent budget-admission, invalid stop reason, incomplete capture, deadline overrun, and self-declared forged Q15 oracle without externally pinned SHA. `bind_deadlines()` now recomputes schedule digest. Driver requires explicit exploratory-deadline opt-in and captures legitimate REJECTED cases.

## Known limitations still requiring work

- External claimed SOF SHA, 32-bit build ID and status fields alone do **not** authenticate the FPGA. Programming log, device readback/verification where available, ELF/bitstream provenance must be inspected independently.
- A native GCC test does not check Q15 machine behavior under the eventual RV32 compiler/SoC; new B ELF needs new functional + binary-flow + target memory proof.
- The experimental deadline binder is **exploratory only**. Actual B firmware has `has_fpga_cycle_binding=0`: it still rejects deadline. No paper should label deadline PASS on that build.
- The experiment runner may require additional state-transition diagnostics on reset, RAM collisions, UART busy/overrun, and run-ID binding once hardware tools become available.
- The A legacy build's old Simple-System time table is **not** valid on the DE0-CV.

## Reproduce

```sh
cd fpga/de0_cv
bash tools/offline_reproduce.sh
```

Use `docs/BOARD_DAY0_TO_PAPER_RUNBOOK.md` when the board and toolchain become available. GitHub main was not changed by this offline pass.
