# Offline execution ledger — 2026-10-30
Baseline: 51 host tests PASS in original audit snapshot.
Decision: no GitHub writes; all work on isolated filesystem copy.
Task: native Q15 360x7 oracle from exact Git blob C/H and frozen weights produced; pinned canonical SHA 03eb958cfa8b4fd2f71a95fb47dbca512820c237c281473817bba685b92c743e.
Task: native 2520+7560 Q15 firmware functional gate 0 mismatches after fixing 7 mislabeled stop reasons.
Task: paper data auditor rejects incorrect admitted budget/deadline, stops, incomplete capture, and arbitrary claimed Q15 output.
Task: synthetic 720 real-model predictions exchanged over binary wire with no timing claim.
Ruling: B deadline experimentation remains a separate exploratory opt-in and cannot be considered hard-RT; the current firmware binding remains disabled.
Ruling: old A exact-binary program remains immutable, all new B files are a separate identity and require new RTL/Q15/binary evidence.
Open: no local Verilator/sv2v/Quartus/RV32 GCC; board verification 0; SOF/Fitter/STA 0; hardware cycle binding 0.
