# RTNN / DE0-CV redesign — evidence ledger

Prepared 2026-10-20. This is a **candidate physical-integration design**, not a completed FPGA design.

## Inputs actually inspected and verified

- `Unjuno/resource-conditioned-neural-computation` `main` commit `ea903d3b76c4cb50732c3f9c72c8ed2084c2cb23`.
- Frozen original Ibex Simple-System GitHub Actions archive (run `32214991830`, artifact `9352155229`), ZIP SHA-256 `9150b0763e5d7b7c305441befdb4161ccf95612edd924b525f8388e06d9a86b0`.
- Exact `.elf` SHA-256 `234a7f46cf227a11f5d97f3c778cbb0c4ed4f7067f8994bcca86c4b08ff4e742`, exact `.bin` SHA-256 `266ecb70c723b2164f6fe9039f27d4cb49c4d7271d4aca0cf69f2692cdfdf7a1`.
- Binary file 117,658 bytes, PT_LOAD memsz 122,312 bytes, entry `0x00100080`, linker `__stack_top=0x001ffff0`.
- Original Ibex RTL test log 21 `CERT`, 21 `E2E`, 2 `OVERHEAD`, `DONE`; fixed-class predictions are exact against the frozen reference.
- Verified upstream pinned `ibex_top.sv`/`ibex_simple_system.sv` interface and ECC read-data pattern; no upstream RTL sources are modified in this package.

## Executed here

```text
python -m pytest -q tests/test_rebuild.py
30 passed
```

Tests covered ZIP/ELF/BIN digests, byte-exact PT_LOAD segment verification, stack-address ELF symbol checking, 256-KiB RAM word image and MIF/HEX alignment, pointer alias arithmetic, exact reference vectors, the genuine archived UART transcript, and malicious/incomplete UART transcript rejection. Wrong predictions/exit labels, malformed cycles, duplicated/missing rows, injected lines, mismatched source hashes and altered archive contents were rejected. `empirical_report.py` refuses to output a certificate or reuse old bounds.

`tools/toolchain_gate.sh` returned BLOCKED because `sv2v`, Verilator, `quartus_sh`, `quartus_sta`, and `quartus_cpf` are not available in this container. The candidate SystemVerilog source files have **not** been parsed by an HDL compiler or simulated. The two RTL testbenches are supplied but remain **not executed**.

## Unclosed hardware obligations

1. Generate a correct **synthesis-only ordered source list** for pinned Ibex (including lowRISC primitives). Exclude simulation-only DPI code. Run sv2v on both Ibex and the new SoC in one dependency-correct conversion.
2. Run Verilator on the converted design against the **frozen 42-case transcript** and check expected predictions, physical class, UART data and RAM timing. A wrapper-port typo or an ECC initialization problem would be caught here.
3. Run Quartus Analysis & Synthesis, Fitter, and STA. Confirm 256-KiB on-chip RAM maps to M10K with one-cycle read response, no external SDRAM/cache/DMA, no port replication beyond available RAM, 50-MHz timing closure, and all I/O pins legal for the board.
4. Prove or bound stack depth within the 32-KiB alias. Out-of-map accesses latch a bus fault but that is an *observation*, not a proof the stack always fits.
5. Verify UART backpressure semantics with a whole-SoC simulation: the old software issues write-only `SIM_OUT` stores with **no ready polling**. The new bus intentionally withholds a grant when UART is busy.
6. Add on-device exact-build identification/attestation before treating host metadata or `.sof` hashes as proof that the correct bitstream ran. The old ELF does **not** transmit a bitstream hash.
7. Rebuild separate admission firmware for FPGA-specific cycle bounds. The frozen ELF's `RTL_TOTAL` still refers to the old Simple System, so `E2E` rows are diagnostic only on FPGA.
8. Physical FPGA measurement must be accompanied by **target-specific bound arguments**, not merely sample maxima.

## Status

- `FROZEN_IMAGE_PREP`: PASS
- `HOST_LOGIC_AND_UART_REFERENCE`: PASS, 30 host tests
- `RTL_UNIT_SIM`: BLOCKED/not run
- `PINNED_RTL_CONVERSION`: BLOCKED/not run
- `QUARTUS_SYNTH_FIT_STA`: BLOCKED/not run
- `FPGA_BOARD_RUN`: NOT RUN
- `DEADLINE_WCET_CERTIFICATION`: NOT ESTABLISHED

**The package is a conservative implementation candidate. It must not be described as successfully synthesized, bitstream-ready, physically measured, or WCET certified.**
