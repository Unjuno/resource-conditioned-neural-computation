# RTNN DE0-CV — implementation progress (2026-10-29)

This is an **implementation candidate** and pre-board experiment infrastructure.
**It is not a flashed bitstream, a new RTL simulation success, or a WCET claim.**

## Pinned inputs

- Public RTNN repo: `Unjuno/resource-conditioned-neural-computation` `main` `ea903d3b76c4cb50732c3f9c72c8ed2084c2cb23`.
- Pinned Ibex upstream: `7b5df75a041affe56e8c235260f98a09b3319008`.
- Frozen previous RTL simulation artifact ZIP SHA256: `9150b0763e5d7b7c305441befdb4161ccf95612edd924b525f8388e06d9a86b0`.
- Frozen Q15 weights header SHA256: `961a76b7e220bf2f665e7c04ab62063600aa2e7eccf3403d80ea730bc993ad9f`.
- Reused same-model core C Git blob SHA: `3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a`.
- Held-out digits test set generated from original stratified split (123/456), 360 records, with pinned input indices 0/24/57 checked against prior validated RTL vectors.

## What has been implemented

| Area | Files | Current verification |
|---|---|---|
| Initial image / old A baseline | `tools/frozen_image.py`, `tests/test_rebuild.py`, existing frozen ZIP | 30 host regression tests PASS; **old** Simple-System regression only |
| Held-out dataset | `tools/experiment_dataset.py`, generated 360-case JSON + C header | 3 pinned test vectors match, host test |
| Binary protocol | `tools/experiment_wire.py`, `firmware/rtnn_experiment_wire.[ch]`, JSON schema | Python/C same 32-byte request and 48-byte reply with CRC; GCC tests |
| FPGA RX path | `rtl/rtnn_uart_rx.sv`, `rtl/rtnn_de0_cv_soc.sv`, `rtl/rtnn_de0_cv_top.sv`, GPIO_0_D1 PIN_B16 | Source wiring and static tests only; RTL simulation **NOT RUN** |
| Runner | `firmware/rtnn_experiment_runner.[ch]`, `firmware/rtnn_board_main.c` | GCC host dispatcher with **stub neural core**; real Q15 RV32 run **NOT RUN** |
| New B linker/image | `firmware/rtnn_experiment.ld`, `tools/build_b_image.py`, `tools/build_b_firmware.sh` | Host validation refuses old A stack; RISC-V compiler absent |
| Q15 oracle | `firmware/rtnn_host_model_reference.c`, `tools/build_q15_oracle.sh`, `tools/verify_q15_oracle.py` | Parser tests; **full native Q15 predictions NOT GENERATED in this environment** |
| Case schedule | `tools/experiment_matrix.py` | 2520 fixed / 7560 adaptive / 720 paired / 52920 symbolic deadline rows generated |
| Experiment transport | `tools/experiment_driver.py`, `tools/experiment_audit.py` | Test stop-and-wait, CRC, missing/duplicated responses, build/SOF metadata checks |
| Paired performance analysis | `tools/experiment_report.py`, `tools/experiment_analysis.py` | Host tests; paired cycle bootstrap estimates; no physical measurements |
| Full synthetic smoke | `tools/selftest_experiment_pipeline.py` | 720 synthetic request/response frames pass; prominently tagged `SYNTHETIC_NOT_BOARD` |
| Two-build separation | `tools/prepare_b_quartus.py` | Refuses frozen A RAM image in B workspace, without claiming Quartus success |

## Tests and blockers

- `python3 -m pytest -q tests` — **51/51 host tests PASS** (record output from this exact run in `docs/host_test_run_2026-10-29.txt`).
- `bash tools/preflight.sh` — 30 baseline host tests PASS.
- `bash -n tools/build_q15_oracle.sh tools/build_b_firmware.sh tools/make_quartus_flat.sh` — PASS (shell syntax only).
- `verilator` — **NOT INSTALLED**; RAM/UART/new Ibex SoC RTL simulation NOT RUN.
- `sv2v` — **NOT INSTALLED**; Ibex conversion and pre/post-conversion equivalence NOT RUN.
- `quartus_sh` — **NOT INSTALLED**; synthesis/Fitter/STA `.sof` NOT BUILT.
- RV32 GCC — **NOT INSTALLED**; B firmware cross-build NOT RUN.
- Connected DE0-CV — **NOT PRESENT**; all board tests NOT RUN.

A host pass must never be promoted to an FPGA pass. The original `A` image has the old Simple System admission table and cannot certify FPGA deadlines. The new B prototype deliberately has **no approved FPGA cycle binding**, and fails closed on deadline-adaptive requests.

## Build / test commands after overlay into the source repo

Run from `fpga/de0_cv/`:

```sh
# 1: Host preflight; requires pytest and scikit-learn for new tests
bash tools/preflight.sh
python3 -m pytest -q tests

# 2: Create exact held-out input data, not yet its Q15 predictions
python3 tools/experiment_dataset.py \
 --preflight quartus/preflight_reference.json \
 --out generated/heldout360.json --c-header generated/heldout360.h

# 3: Make real same-model full Q15 prediction oracle from pinned C sources
bash tools/build_q15_oracle.sh ../..
# This must produce generated/frozen_q15_oracle.json with
# Q15_REFERENCE_NATIVE_C_MATCHES_PINNED_CHECKS; do not use the mock model.

# 4: Prepare E2, E3, E4 schedules
python3 tools/experiment_matrix.py --which fixed --out generated/matrix_fixed.json
python3 tools/experiment_matrix.py --which adaptive --out generated/matrix_adaptive.json
python3 tools/experiment_matrix.py --which paired --out generated/matrix_paired.json

# 5: Rebuild new RV32 B firmware; RISC-V GCC required
bash tools/build_b_firmware.sh ../..

# 6: RTL unit tests need Verilator; conversion needs audited Ibex source list
bash tools/run_rtl_unit_tests.sh
# tools/make_quartus_flat.sh -- needs reviewed IBEX_SOURCE_LIST/IBEX_ROOT

# 7: Create a separate B Quartus workspace (once B image and Ibex flat exist)
python3 tools/prepare_b_quartus.py --root . \
 --b-build build/fpga_b --flat quartus/ibex_flat.v \
 --out-dir build/quartus_b
# Quartus compile only after source graph and pre/post-conversion RTL pass.

# 8: Communications/analysis synthetic smoke ONLY, never FPGA results
python3 tools/selftest_experiment_pipeline.py
```

## Remaining hard gates

1. Resolve pinned Ibex/FuseSoC synthesis dependencies and `sv2v` conversion; review generated `ibex_flat.v` and CPU compile warnings.
2. Simulate RAM alias, UART TX/RX, MMIO handshake, reset and full SoC. Compare the original 42-case A results on the **new SoC** (new cycle values allowed).
3. Run actual native Q15 360-vector oracle and compile B firmware with the source repository. Strictly pin generated outputs.
4. Fit 256 KiB true dual-port RAM on Cyclone V (M10K capacity, read/write collisions, init) and close STA on exact FPGA build.
5. Capture physical UART with command-response protocol, prove Q15 decisions and measure exact same-input fixed2 vs adaptive cycles.
6. Obtain **new** FPGA target cycle-bound evidence; only then enable B's deadline mode, with a distinct build and renewed proof/measurements.
7. Keep unsupported claims (`WCET`, `physical speedup`, `hard deadline guarantee`) **PENDING** until test evidence exists.

### Known experiment boundary

Same-network variable work is established in the old Ibex Simple System. The new stage tests whether that mechanism is preserved on a physical DE0-CV implementation. RTNN cannot claim a *latency speedup over fixed2* based solely on a lower average block count: it pays entropy-check overhead. The primary E4 outcome must compare measured **total cycles at the same model, input, and clock**.
