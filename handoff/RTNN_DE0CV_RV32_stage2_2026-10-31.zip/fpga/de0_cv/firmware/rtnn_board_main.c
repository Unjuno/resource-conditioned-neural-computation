/* DE0-CV UART experiment loop. A NEW firmware build; not frozen Simple System.
 * This is pre-board bring-up code. It must be compiled for RV32 and verified
 * against the real Q15 core before being flashed. Deadline bindings disabled
 * until a new FPGA target-specific table has been reviewed.
 */
#include "rtnn_experiment_runner.h"
#include "rtnn_experiment_wire.h"
#include <stdint.h>

#define RTNN_MMIO_TX_ADDR      UINT32_C(0x00020000)
#define RTNN_MMIO_HALT_ADDR    UINT32_C(0x00020008)
#define RTNN_MMIO_RX_STATUS    UINT32_C(0x00020010)
#define RTNN_MMIO_RX_DATA      UINT32_C(0x00020014)
#define RTNN_FW_MODEL_ID       UINT32_C(0x52544e4e)
// PROTOTYPE BUILD ID, not a cryptographic artifact identity.
#define RTNN_FW_PROTOTYPE_ID   UINT32_C(0x44563032)
#define RTNN_RX_TIMEOUT_CYCLES UINT32_C(50000000)

static volatile uint32_t* addr(uint32_t a){return (volatile uint32_t*)(uintptr_t)a;}
static void uart_put(uint8_t b){*addr(RTNN_MMIO_TX_ADDR)=(uint32_t)b;}
#if defined(HOST_SYNTAX_ONLY)
static uint64_t machine_cycles(void*unused){(void)unused;static uint64_t x=0;return x+=100u;}
#else
static uint64_t machine_cycles(void*unused){
  (void)unused;
  uint32_t upper_a,low,upper_b;
  do {
    __asm__ volatile("csrr %0, mcycleh" : "=r"(upper_a) :: "memory");
    __asm__ volatile("csrr %0, mcycle" : "=r"(low) :: "memory");
    __asm__ volatile("csrr %0, mcycleh" : "=r"(upper_b) :: "memory");
  }while(upper_a!=upper_b);
  return ((uint64_t)upper_b<<32)|low;
}
#endif
static int read_one(uint8_t*byte){
  uint64_t begin=machine_cycles(0);
  for(;;){
    uint32_t status=*addr(RTNN_MMIO_RX_STATUS);
    if(status & 2u){
      *addr(RTNN_MMIO_RX_STATUS)=2u; // clear sticky RX overflow/framing fault
      return -1;
    }
    if(status & 1u){*byte=(uint8_t)*addr(RTNN_MMIO_RX_DATA);return 0;}
    if(machine_cycles(0)-begin>RTNN_RX_TIMEOUT_CYCLES)return -2;
  }
}
static void uart_reply(const rtnn_exp_response_t *r){
  uint8_t frame[RTNN_RSP_LEN];
  rtnn_wire_encode_response(r,frame);
  for(unsigned i=0;i<RTNN_RSP_LEN;++i)uart_put(frame[i]);
}
static void bad_frame_reply(void){
  rtnn_exp_response_t e={0};
  e.status=RTNN_STATUS_BAD_FRAME;e.mode=RTNN_MODE_STATUS;
  e.admitted_exit=-1;e.executed_exit=-1;e.prediction=-1;e.label=-1;
  e.model_id=RTNN_FW_MODEL_ID;e.build_id=RTNN_FW_PROTOTYPE_ID;
  uart_reply(&e);
}
int main(void){
  static const rtnn_fw_config_t cfg={
    .model_id=RTNN_FW_MODEL_ID,.build_id=RTNN_FW_PROTOTYPE_ID,
    .binding_id=0,.has_fpga_cycle_binding=0,
    .upper_total_cycles={0,0,0,0,0,0,0},
    .cycle_now=machine_cycles,.cycle_ctx=0
  };
  for(;;){
    uint8_t frame[RTNN_REQ_LEN];
    if(read_one(&frame[0])!=0)continue; // idle noise before a frame
    int failed=0;
    for(unsigned i=1;i<RTNN_REQ_LEN;++i){
      if(read_one(&frame[i])!=0){failed=1;break;}
    }
    rtnn_exp_request_t request;
    if(failed||rtnn_wire_decode_request(frame,&request)!=0){
      bad_frame_reply();continue;
    }
    rtnn_exp_response_t result;
    if(rtnn_fw_execute(&request,&result,&cfg)!=0){bad_frame_reply();continue;}
    uart_reply(&result);
  }
}
