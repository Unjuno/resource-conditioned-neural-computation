/* Native-only Q15 full held-out oracle builder. Requires original main repo
 * experiments/realtime_nn_real_sequence_fixed_core.c and same frozen weights.
 * Run this BEFORE calling E2/E3 an exact Q15 prediction audit.
 */
#include "realtime_nn_real_sequence_fixed_core.h"
#include "heldout360.h"
#include <stdio.h>
#include <stdint.h>
static RTNNFixedWorkspace workspace;
static int32_t logits[10];
static int pred(void){
  int b=0;
  for(int i=1;i<10;++i)if(logits[i]>logits[b])b=i;
  return b;
}
int main(void){
  puts("input_id,label,preferred_exit,exit0,exit1,exit2,exit3,exit4,exit5,exit6");
  for(unsigned i=0;i<RTNN_TEST_COUNT;++i){
    const uint8_t*p=rtnn_test_pixels[i];
    uint8_t preferred=rtnn_fixed_preferred_exit(&workspace,p);
    printf("%u,%u,%u",i,(unsigned)rtnn_test_labels[i],(unsigned)preferred);
    for(uint8_t k=0;k<7u;++k){
      rtnn_fixed_infer_exit(&workspace,p,k,logits);
      printf(",%d",pred());
    }
    putchar('\n');
  }
  return 0;
}
