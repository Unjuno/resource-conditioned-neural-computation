# RTNN DE0-CV — Existing-method experimental release

**Start here: [日本語の実行案内](START_HERE_JA.md).**

Scope: frozen seed-63 Q15 model; pre-inference budget/admission plus entropy early stopping.
No inter-block time-feedback policy, no new training, no GPU work.

Status: host/control/collection-analysis tests verified; FPGA RTL integration,
sv2v regression, Quartus/Fitter/STA and physical-board execution still UNVERIFIED.
No bitstream is supplied. No physical cycle data or WCET certificate is claimed.

Run `bash tools/offline_reproduce.sh` for the native Q15 and host regression gates.
The newly frozen campaign is in `paper/campaign/`; it contains schedules, not results.
Use `tools/paper_collect.py`, `tools/paper_results.py`, and `tools/paper_plots.py`
only after the documented physical evidence gates.

An unfavorable speed comparison remains valid data. A repeated input is not a new
accuracy sample. See `paper/PROTOCOL_JA.md` for all decision rules and limitations.

GitHub main has not been modified. Earlier README is retained under `docs/history/`.
