"""Actual frozen Q15 labels/exits through synthetic wire frames: no timing claims."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))


def test_720_paired_q15_protocol_cases_match_real_native_oracle(tmp_path):
    from offline_q15_protocol_fixture import run_fixture
    result=run_fixture(ROOT,tmp_path)
    assert result['q15_checked']==720
    assert result['fixed2_correct']==339
    assert result['adaptive_correct']==339
    assert result['fixed2_only_correct']==3
    assert result['adaptive_only_correct']==3
    assert result['mean_adaptive_blocks']==489/360
    assert result['physical_timing_usable'] is False
