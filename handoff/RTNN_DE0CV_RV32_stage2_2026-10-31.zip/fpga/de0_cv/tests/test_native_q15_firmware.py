"""End-to-end native Q15 firmware versus independently frozen model oracle."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))

def test_native_q15_firmware_full_360_and_all_21_budgets(tmp_path):
    from offline_q15_firmware_gate import run_gate
    verdict=run_gate(ROOT,tmp_path)
    assert verdict['status']=='NATIVE_Q15_FIRMWARE_MATCHES_PINNED_MODEL'
    assert verdict['fixed_cases']==360*7
    assert verdict['adaptive_cases']==360*21
    assert verdict['prediction_mismatches']==0
    assert verdict['executed_exit_mismatches']==0
    assert verdict['stop_reason_mismatches']==0
    assert verdict['budget_cap_violations']==0
    assert verdict['real_fpga_claimed'] is False
