"""Independent offline, self-contained RV32 gate entrypoint."""
from pathlib import Path
import json,shutil,subprocess
import pytest
ROOT=Path(__file__).resolve().parents[1]

def test_one_command_rebuilds_and_validates_rv32_q15(tmp_path):
    for name in ('clang','ld.lld','llvm-objcopy','readelf','g++'):
        if not shutil.which(name):pytest.skip(name+' missing')
    out=tmp_path/'result'
    proc=subprocess.run(['bash',str(ROOT/'tools/run_rv32_gate.sh'),str(out)],
                        cwd=tmp_path,capture_output=True,text=True,timeout=100)
    assert proc.returncode==0,proc.stdout+proc.stderr
    j=json.loads((out/'isa_720/isa_gate.json').read_text())
    assert j['decision']=='PASS_ISA_LEVEL_ONLY'
    assert j['requests_checked']==720
    assert (out/'fpga_b/rtnn_experiment.elf').is_file()
    assert (out/'fpga_b/rtnn_ram_words.hex').is_file()
    assert (out/'simulator').is_file()
    assert 'NO_IBEX_CYCLES_NO_FPGA_PROOF' in (out/'README.status').read_text()
