#ifndef RTNN_REAL_SEQUENCE_FIXED_CORE_H
#define RTNN_REAL_SEQUENCE_FIXED_CORE_H
#include <stdint.h>
typedef struct { int32_t scratch; } RTNNFixedWorkspace;
uint8_t rtnn_fixed_budget_ceiling_q16(uint16_t b);
void rtnn_fixed_infer_exit(RTNNFixedWorkspace*w,const uint8_t p[64],uint8_t e,int32_t z[10]);
void rtnn_fixed_infer_budget(RTNNFixedWorkspace*w,const uint8_t p[64],uint16_t budget,
                             uint8_t deadline,int32_t z[10],uint8_t* executed);
#endif
