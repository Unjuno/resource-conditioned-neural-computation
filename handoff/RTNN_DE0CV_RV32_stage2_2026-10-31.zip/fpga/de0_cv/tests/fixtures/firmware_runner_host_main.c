#include "rtnn_experiment_runner.h"
#include "rtnn_experiment_wire.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>
static uint64_t tick(void*ctx){uint64_t *p=(uint64_t*)ctx;*p+=1234;return *p;}
int main(void){
  char line[100];uint8_t req[32],res[48];
  if(!fgets(line,sizeof(line),stdin)||strlen(line)<64)return 1;
  for(unsigned i=0;i<32;i++){
    unsigned value;if(sscanf(line+2*i,"%2x",&value)!=1)return 2;
    req[i]=(uint8_t)value;
  }
  rtnn_exp_request_t q;
  if(rtnn_wire_decode_request(req,&q)!=0)return 3;
  static uint64_t clock=0;
  rtnn_fw_config_t cfg={.model_id=0x52544e4eu,.build_id=0x44563032u,.binding_id=0u,
                         .has_fpga_cycle_binding=0,.cycle_now=tick,.cycle_ctx=&clock};
  rtnn_exp_response_t r;
  if(rtnn_fw_execute(&q,&r,&cfg)!=0)return 4;
  rtnn_wire_encode_response(&r,res);
  for(unsigned i=0;i<48;i++)printf("%02x",res[i]);
  putchar('\n');return 0;
}
