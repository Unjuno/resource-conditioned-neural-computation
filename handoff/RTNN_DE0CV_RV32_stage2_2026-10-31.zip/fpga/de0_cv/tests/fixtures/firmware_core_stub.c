#include "realtime_nn_real_sequence_fixed_core.h"
// Stub-only: provides synthetic logits for dispatcher tests, never RTNN evidence.
uint8_t rtnn_fixed_budget_ceiling_q16(uint16_t b){return (uint8_t)(((uint32_t)b*6)/65535u);}
void rtnn_fixed_infer_exit(RTNNFixedWorkspace*w,const uint8_t p[64],uint8_t e,int32_t z[10]){
  (void)w;(void)p;for(int i=0;i<10;i++)z[i]=0;z[e%10]=1;
}
void rtnn_fixed_infer_budget(RTNNFixedWorkspace*w,const uint8_t p[64],uint16_t b,
                             uint8_t d,int32_t z[10],uint8_t*e){
  uint8_t cap=rtnn_fixed_budget_ceiling_q16(b);
  if(d<cap)cap=d;
  if(cap>5)cap=5;
  if(cap>1)cap=1;
  *e=cap;rtnn_fixed_infer_exit(w,p,cap,z);
}
