#include "rtnn_experiment_wire.h"
#include <stdio.h>
#include <string.h>

static void hexdump(const unsigned char *buf, unsigned n) {
  for (unsigned i=0;i<n;++i)printf("%02x",buf[i]);
  putchar('\n');
}
int main(void){
  rtnn_exp_request_t q = {
    .seq=1021u,.input_id=57u,.mode=RTNN_MODE_ADAPTIVE,.fixed_exit=0u,
    .budget_q16=32768u,.deadline_cycles=0u,.model_id=0x52544e4eu,.build_id=0x51515151u
  };
  unsigned char a[32];
  rtnn_wire_encode_request(&q,a);
  rtnn_exp_request_t decoded;
  if (rtnn_wire_decode_request(a,&decoded)!=0 || decoded.seq!=1021u || decoded.input_id!=57u) return 1;
  hexdump(a,32);
  rtnn_exp_response_t r={
    .seq=1021u,.input_id=57u,.mode=RTNN_MODE_ADAPTIVE,.status=RTNN_STATUS_OK,
    .stop_reason=1u,.budget_q16=32768u,.deadline_cycles=0u,
    .admitted_exit=3,.executed_exit=2,.prediction=8,.label=2,.cycles=456789u,
    .model_id=0x52544e4eu,.build_id=0x51515151u,.binding_id=0u,.flags=0u
  };
  unsigned char b[48];
  rtnn_wire_encode_response(&r,b);
  hexdump(b,48);
  b[20] ^= 1;
  if (rtnn_wire_decode_response(b,&r)==0) return 2;
  puts("C_CODEC_PASS");
  return 0;
}
