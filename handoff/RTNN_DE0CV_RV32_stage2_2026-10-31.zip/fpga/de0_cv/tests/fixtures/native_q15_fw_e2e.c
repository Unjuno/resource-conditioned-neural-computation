/* Native-host control test with exact frozen Q15 model.
 * Clock callback is a test stub: printed integers are NOT timing evidence.
 */
#include "rtnn_experiment_runner.h"
#include "heldout360.h"
#include <stdint.h>
#include <stdio.h>
#define MODEL_ID UINT32_C(0x52544e4e)
#define BUILD_ID UINT32_C(0x44563032)

static uint64_t fake_clock(void *opaque) {
  uint64_t *clock_value = (uint64_t *)opaque;
  *clock_value += 100u;
  return *clock_value;
}
static uint16_t budget_index(unsigned index) {
  /* Python round(i*65535/20) uses ties-to-even; exact division has .25/.5/.75.
   * Explicit ties-to-even preserves the frozen Python schedule. */
  unsigned n=index*65535u;
  unsigned q=n/20u;
  unsigned rem=n%20u;
  if (rem>10 || (rem==10 && (q&1u))) ++q;
  return (uint16_t)q;
}
static void output(unsigned input, unsigned mode, unsigned param,
                   const rtnn_exp_response_t *rsp) {
  printf("%u,%u,%u,%d,%d,%d,%u,%u,%u\n",
         input,mode,param,rsp->admitted_exit,rsp->executed_exit,
         rsp->prediction,(unsigned)rsp->stop_reason,
         (unsigned)rsp->status,(unsigned)rsp->flags);
}
int main(void) {
  static uint64_t ticks=0;
  const rtnn_fw_config_t cfg={
    .model_id=MODEL_ID,.build_id=BUILD_ID,.binding_id=0,
    .has_fpga_cycle_binding=0,.upper_total_cycles={0,0,0,0,0,0,0},
    .cycle_now=fake_clock,.cycle_ctx=&ticks
  };
  puts("input_id,mode,param,admitted_exit,executed_exit,prediction,stop_reason,status,flags");
  for (unsigned input=0;input<RTNN_TEST_COUNT;++input) {
    for (unsigned k=0;k<7;++k) {
      rtnn_exp_request_t req={.seq=1,.input_id=(uint16_t)input,
          .mode=RTNN_MODE_FIXED,.fixed_exit=(uint8_t)k,
          .budget_q16=65535,.deadline_cycles=0,
          .model_id=MODEL_ID,.build_id=BUILD_ID};
      rtnn_exp_response_t response;
      if (rtnn_fw_execute(&req,&response,&cfg)!=0)return 10;
      output(input,req.mode,k,&response);
    }
    for (unsigned j=0;j<21;++j) {
      rtnn_exp_request_t req={.seq=1,.input_id=(uint16_t)input,
          .mode=RTNN_MODE_ADAPTIVE,.fixed_exit=0,
          .budget_q16=budget_index(j),.deadline_cycles=0,
          .model_id=MODEL_ID,.build_id=BUILD_ID};
      rtnn_exp_response_t response;
      if (rtnn_fw_execute(&req,&response,&cfg)!=0)return 11;
      output(input,req.mode,j,&response);
    }
  }
  return 0;
}
