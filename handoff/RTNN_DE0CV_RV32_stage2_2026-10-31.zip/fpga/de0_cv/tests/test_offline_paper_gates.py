"""Paper-grade semantic gates: tests intentionally precede implementation."""
import copy
import hashlib
import json
import sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from experiment_matrix import make_matrix, bind_deadlines
from experiment_dataset import generate_heldout
from experiment_wire import Request, Response, Mode, Status, encode_request, encode_response, decode_response
from experiment_audit import audit_trace, AuditError

DATASET=generate_heldout(json.loads((ROOT/'quartus/preflight_reference.json').read_text()))
MODEL_ID=0x52544e4e
BUILD_ID=0x44563032
BOUNDS=[1000,2000,3000,4000,5000,6000,7000]


def mk_trace(matrix, *, case=None):
    rows=[]
    for r in matrix['rows']:
        req=Request(seq=r['seq'],input_id=r['input_id'],mode=Mode(r['mode']),
                    fixed_exit=r['fixed_exit'],budget_q16=r['budget_q16'],
                    deadline_cycles=r['deadline_cycles'],model_id=MODEL_ID,build_id=BUILD_ID)
        cap=(req.budget_q16*6)//65535
        if req.mode==Mode.FIXED:
            admitted=req.fixed_exit; executed=admitted; reason=0
        elif req.mode==Mode.CAPPED_NO_STOP:
            admitted=cap;executed=cap;reason=0
        elif req.mode==Mode.DEADLINE_ADAPTIVE:
            admitted=max((i for i,b in enumerate(BOUNDS) if b<=req.deadline_cycles),default=-1)
            if admitted<0:
                res=Response(req.seq,req.input_id,req.mode,Status.REJECTED,0,
                    req.budget_q16,req.deadline_cycles,-1,-1,-1,-1,0,MODEL_ID,BUILD_ID,99,0)
                rows.append({'request_hex':encode_request(req).hex(),'response_hex':encode_response(res).hex()});continue
            allowed=min(cap,admitted,5)
            executed=min(1,allowed)
            reason=1 if executed<allowed else (3 if admitted<cap and executed==allowed else 2)
        else:
            admitted=cap;allowed=min(cap,5);executed=min(1,allowed)
            reason=1 if executed<allowed else 2
        res=Response(req.seq,req.input_id,req.mode,Status.OK,reason,
                     req.budget_q16,req.deadline_cycles,admitted,executed,
                     DATASET['records'][req.input_id]['label'],
                     DATASET['records'][req.input_id]['label'],100,
                     MODEL_ID,BUILD_ID,99 if req.mode==Mode.DEADLINE_ADAPTIVE else 0,0)
        if case is not None and r['seq']==case[0]:res=Response(**{**res.__dict__, **case[1]})
        rows.append({'request_hex':encode_request(req).hex(),'response_hex':encode_response(res).hex()})
    return {'schema':'rtnn-de0cv-experiment-trace-v1','origin':'synthetic_fixture',
            'status':'SYNTHETIC_NOT_BOARD','rows':rows}


def mutate(trace, index=0, **fields):
    trace=copy.deepcopy(trace)
    r=decode_response(bytes.fromhex(trace['rows'][index]['response_hex']))
    trace['rows'][index]['response_hex']=encode_response(Response(**{**r.__dict__,**fields})).hex()
    return trace


def test_deadline_matrix_digest_is_regenerated_and_binding_pinned():
    m=bind_deadlines(make_matrix(42,1,'deadline'),total_bounds=BOUNDS,binding_id=99)
    digest=hashlib.sha256(json.dumps(m['rows'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
    assert m['schedule_sha256']==digest
    assert m['binding_id']==99
    assert m['total_bounds']==BOUNDS
    assert audit_trace(mk_trace(m),m,DATASET)['accepted']==147


def test_incomplete_trace_is_rejected():
    m=make_matrix(42,1,'paired')
    trace=mk_trace(m)
    assert audit_trace(trace,m,DATASET)['accepted']==2
    with pytest.raises(AuditError,match='status|incomplete'):
        audit_trace({**trace,'status':'INCOMPLETE'},m,DATASET)


def test_admitted_class_cannot_exceed_budget_even_if_no_blocks_run():
    m=make_matrix(42,1,'adaptive');t=mk_trace(m)
    idx=next(i for i,r in enumerate(m['rows']) if r['budget_q16']==0)
    with pytest.raises(AuditError,match='admitted|budget'):
        audit_trace(mutate(t,idx,admitted_exit=6,executed_exit=0,stop_reason=1),m,DATASET)


def test_wrong_stop_reason_on_nondeadline_is_rejected():
    m=make_matrix(42,1,'paired');t=mk_trace(m)
    idx=next(i for i,r in enumerate(m['rows']) if r['mode']==Mode.ADAPTIVE)
    with pytest.raises(AuditError,match='reason|stop'):
        audit_trace(mutate(t,idx,stop_reason=3),m,DATASET)


def test_deadline_overrun_is_rejected_not_reported_as_safe():
    m=bind_deadlines(make_matrix(42,1,'deadline'),total_bounds=BOUNDS,binding_id=99)
    t=mk_trace(m)
    with pytest.raises(AuditError,match='deadline|cycles'):
        audit_trace(mutate(t,0,cycles=100000),m,DATASET)


def test_admitted_class_must_match_deadline_table():
    m=bind_deadlines(make_matrix(42,1,'deadline'),total_bounds=BOUNDS,binding_id=99)
    t=mk_trace(m)
    idx=next(i for i,r in enumerate(m['rows']) if r['deadline_cycles']>=2000)
    rsp=decode_response(bytes.fromhex(t['rows'][idx]['response_hex']))
    if rsp.admitted_exit>0:
        with pytest.raises(AuditError,match='admitted|deadline'):
            audit_trace(mutate(t,idx,admitted_exit=rsp.admitted_exit-1,executed_exit=0,stop_reason=3),m,DATASET)


def test_unverified_claimed_q15_predictions_not_trusted():
    m=make_matrix(42,1,'paired');t=mk_trace(m)
    forged={'schema':'rtnn-de0cv-frozen-q15-reference-v1',
            'status':'Q15_REFERENCE_NATIVE_C_MATCHES_PINNED_CHECKS',
            'dataset_sha256':DATASET['dataset_sha256'],
            'predictions':{str(i):{'predictions':[r['label']]*7,'preferred_exit':1}
                            for i,r in enumerate(DATASET['records'])}}
    with pytest.raises(AuditError,match='Q15|oracle|provenance'):
        audit_trace(t,m,DATASET,q15_oracle=forged)


def test_rejected_deadline_only_when_no_class_fits():
    m=bind_deadlines(make_matrix(42,1,'deadline'),total_bounds=BOUNDS,binding_id=99)
    r=m['rows'][0];r['deadline_cycles']=0
    m['schedule_sha256']=hashlib.sha256(json.dumps(m['rows'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
    t=mk_trace(m)
    result=audit_trace(t,m,DATASET)
    assert result['rejected']==1
    t2=mutate(t,0,admitted_exit=0,executed_exit=0,prediction=3,label=3,cycles=100,status=Status.OK)
    with pytest.raises(AuditError): audit_trace(t2,m,DATASET)


def test_deadline_matrix_requires_explicit_run_gate():
    from experiment_driver import validate_run_plan,DriverError
    m=bind_deadlines(make_matrix(42,1,'deadline'),total_bounds=BOUNDS,binding_id=99)
    with pytest.raises(DriverError):validate_run_plan(m, allow_exploratory_deadline=False)
    assert validate_run_plan(m, allow_exploratory_deadline=True)['claim_scope']=='EMPIRICAL_EXPLORATORY_ONLY'
