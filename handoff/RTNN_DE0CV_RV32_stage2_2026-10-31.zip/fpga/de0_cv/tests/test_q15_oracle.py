import io
import json
import sys
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from experiment_dataset import generate_heldout
from verify_q15_oracle import verify_csv, OracleError


def fixture_data():
    return generate_heldout(json.loads((ROOT/'quartus/preflight_reference.json').read_text()))


def test_oracle_requires_all_rows_and_frozen_predictions():
    dataset=fixture_data()
    preflight=json.loads((ROOT/'quartus/preflight_reference.json').read_text())
    lines=['input_id,label,preferred_exit,exit0,exit1,exit2,exit3,exit4,exit5,exit6']
    for r in dataset['records']:
        i=r['input_id']; pref=1
        ps=[0]*7
        for v in preflight['vectors']:
            if v['test_index']==i:ps=list(v['expected_fixed_class_prediction']);pref=v['preferred_exit']
        lines.append(','.join(str(x) for x in (i,r['label'],pref,*ps)))
    text='\n'.join(lines)+'\n'
    result=verify_csv(text,dataset,preflight,check_known_aggregate=False)
    assert result['record_count']==360
    assert result['predictions']['24']['predictions']==[6,6,4,4,4,4,4]
    with pytest.raises(OracleError):verify_csv('\n'.join(lines[:-1])+'\n',dataset,preflight,check_known_aggregate=False)
    modified=text.replace('24,4,3,6,6,4','24,4,3,5,6,4')
    assert modified!=text
    with pytest.raises(OracleError):verify_csv(modified,dataset,preflight,check_known_aggregate=False)
