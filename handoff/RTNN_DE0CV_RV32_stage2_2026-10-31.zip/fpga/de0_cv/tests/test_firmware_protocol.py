"""C wire compatibility with Python must be byte exact, including CRC."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from experiment_wire import Request,Response,Mode,Status,encode_request,encode_response


def test_native_c_wire_codec_matches_python(tmp_path):
    binary=tmp_path/'codec_test'
    cc=subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror',
        '-Ifirmware','firmware/rtnn_experiment_wire.c',
        'tests/fixtures/firmware_wire_roundtrip.c','-o',str(binary)],
        cwd=ROOT,capture_output=True,text=True)
    assert cc.returncode==0,cc.stderr
    r=subprocess.run([str(binary)],capture_output=True,text=True)
    assert r.returncode==0,r.stderr
    lines=r.stdout.splitlines()
    req=Request(1021,57,Mode.ADAPTIVE,0,32768,0,0x52544e4e,0x51515151)
    rsp=Response(seq=1021,input_id=57,mode=Mode.ADAPTIVE,status=Status.OK,
                 stop_reason=1,budget_q16=32768,deadline_cycles=0,admitted_exit=3,
                 executed_exit=2,prediction=8,label=2,cycles=456789,
                 model_id=0x52544e4e,build_id=0x51515151,binding_id=0,flags=0)
    assert lines==[encode_request(req).hex(),encode_response(rsp).hex(),'C_CODEC_PASS']


def test_rx_top_and_mmio_defined():
    soc=(ROOT/'rtl/rtnn_de0_cv_soc.sv').read_text()
    top=(ROOT/'rtl/rtnn_de0_cv_top.sv').read_text()
    qsf=(ROOT/'quartus/rtnn_de0_cv.qsf').read_text()
    assert 'module rtnn_uart_rx' in (ROOT/'rtl/rtnn_uart_rx.sv').read_text()
    assert 'uart_rx_i' in soc and 'GPIO_0_D1' in top
    assert "10'h014" in soc and "10'h010" in soc
    assert 'PIN_B16 -to GPIO_0_D1' in qsf
