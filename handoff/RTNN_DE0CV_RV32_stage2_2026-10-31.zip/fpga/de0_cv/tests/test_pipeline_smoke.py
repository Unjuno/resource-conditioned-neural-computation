"""720-request binary PC control pipeline, explicitly synthetic."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))

def test_full_paired_pipeline_synthetic_is_never_hardware_pass(tmp_path):
    from selftest_experiment_pipeline import selftest
    r=selftest(ROOT,tmp_path)
    assert r['trace_status']=='SYNTHETIC_NOT_BOARD'
    assert r['record_count']==720
    assert r['report']['origin']=='synthetic_fixture'
    assert r['report']['status']=='OBSERVATIONAL_PAIRS_Q15_PENDING'
    assert r['report']['observed']['n']==360
    assert (tmp_path/'synthetic_trace.json').is_file()
