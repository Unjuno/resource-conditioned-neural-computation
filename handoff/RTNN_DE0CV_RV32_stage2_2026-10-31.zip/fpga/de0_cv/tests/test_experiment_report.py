import json
import sys
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from experiment_dataset import generate_heldout
from experiment_matrix import make_matrix
from experiment_wire import Request,Response,Mode,Status,encode_request,encode_response


def test_paired_report_rejects_missing_rows_and_labels_unverified():
    from experiment_report import paired_report
    from experiment_audit import AuditError
    ds=generate_heldout(json.loads((ROOT/'quartus/preflight_reference.json').read_text()))
    m=make_matrix(seed=4,count=3,which='paired')
    trace={'schema':'rtnn-de0cv-experiment-trace-v1','origin':'synthetic_fixture',
           'status':'SYNTHETIC_NOT_BOARD','rows':[]}
    for x in m['rows']:
        mode=Mode(x['mode'])
        q=Request(seq=x['seq'],input_id=x['input_id'],mode=mode,fixed_exit=x['fixed_exit'],
                  budget_q16=x['budget_q16'],deadline_cycles=x['deadline_cycles'],
                  model_id=0x52544e4e,build_id=1)
        label=ds['records'][q.input_id]['label']
        r=Response(seq=q.seq,input_id=q.input_id,mode=mode,status=Status.OK,
                   stop_reason=1 if mode==Mode.ADAPTIVE else 0,
                   budget_q16=q.budget_q16,deadline_cycles=q.deadline_cycles,
                   admitted_exit=2 if mode==Mode.FIXED else 6,
                   executed_exit=2 if mode==Mode.FIXED else 1,
                   prediction=label,label=label,
                   cycles=1200 if mode==Mode.FIXED else 800,
                   model_id=q.model_id,build_id=q.build_id,binding_id=0,flags=0)
        trace['rows'].append({'request_hex':encode_request(q).hex(),
                              'response_hex':encode_response(r).hex()})
    report=paired_report(trace,m,ds)
    assert report['status']=='OBSERVATIONAL_PAIRS_Q15_PENDING'
    assert report['observed']['n']==3
    assert report['observed']['mean_cycle_saving']==400
    with pytest.raises(AuditError):paired_report({**trace,'rows':trace['rows'][:-1]},m,ds)
