"""Build the actual FPGA experiment firmware with a checked Clang/RV32 toolchain.

This is machine-code preparation, NOT a claim of Q15-on-RV32 execution
or of FPGA synthesis/timing. Tool availability is explicit.
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import subprocess
import pytest

ROOT=Path(__file__).resolve().parents[1]
TOOLS=("clang", "ld.lld", "llvm-objcopy", "readelf")


def need_tools():
    missing=[x for x in TOOLS if not shutil.which(x)]
    if missing:pytest.skip("RV32 compiler tools unavailable: "+", ".join(missing))


def build(out,source=None):
    src=source or ROOT/"upstream/source_repo"
    return subprocess.run(["bash",str(ROOT/"tools/build_b_firmware_clang.sh"),str(out),str(src)],
                          cwd=ROOT,capture_output=True,text=True)


def test_clang_build_is_real_rv32_machine_image(tmp_path):
    need_tools()
    out=tmp_path/"rv32"
    p=build(out)
    assert p.returncode==0,p.stdout+p.stderr
    elf=(out/"rtnn_experiment.elf").read_bytes()
    binary=(out/"rtnn_experiment.bin").read_bytes()
    assert elf[:6]==b"\x7fELF\x01\x01"  # little-endian ELF32
    assert struct.unpack_from("<H",elf,18)[0]==243 # EM_RISCV
    assert struct.unpack_from("<I",elf,24)[0]==0x00100080
    headers=subprocess.check_output(["readelf","-l",str(out/"rtnn_experiment.elf")],text=True)
    assert sum(x.lstrip().startswith("LOAD ") for x in headers.splitlines())==1
    manifest=json.loads((out/"fpga_b_image_manifest.json").read_text())
    assert manifest["status"]=="IMAGE_GENERATED_NOT_SYNTHESIZED"
    assert manifest["bin_sha256"]==hashlib.sha256(binary).hexdigest()
    assert manifest["elf_sha256"]==hashlib.sha256(elf).hexdigest()
    assert manifest["stack_top"]==0x0013fff0
    assert manifest["load_bytes"]==len(binary)
    assert manifest["memory_bytes"]<=224*1024
    assert len((out/"rtnn_ram_words.hex").read_text().splitlines())==65536
    assert (out/"toolchain_manifest.json").is_file()
    tc=json.loads((out/"toolchain_manifest.json").read_text())
    assert tc["isa"]=="rv32im_zicsr"
    assert tc["model_sha256"]=="961a76b7e220bf2f665e7c04ab62063600aa2e7eccf3403d80ea730bc993ad9f"
    assert tc["claim"]=="COMPILED_NOT_EXECUTED_ON_RV32"
    assert tc['source_git_blobs']['realtime_nn_real_sequence_fixed_core.c']=='3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a'
    assert tc['source_sha256']['firmware/rtnn_board_main.c']==hashlib.sha256((ROOT/'firmware/rtnn_board_main.c').read_bytes()).hexdigest()
    assert tc['source_sha256']['generated/heldout360.h']==hashlib.sha256((ROOT/'generated/heldout360.h').read_bytes()).hexdigest()


def test_clang_build_rejects_changed_q15_core(tmp_path):
    need_tools()
    source=tmp_path/"tampered"/"experiments"
    source.mkdir(parents=True)
    src=ROOT/"upstream/source_repo"/"experiments"
    for name in ("realtime_nn_real_sequence_fixed_core.c","realtime_nn_real_sequence_fixed_core.h"):
        shutil.copyfile(src/name,source/name)
    with (source/"realtime_nn_real_sequence_fixed_core.c").open("a") as fp:fp.write("\n/* intentionally changed */\n")
    out=tmp_path/"reject"
    p=build(out,source.parent)
    assert p.returncode!=0
    assert "core" in (p.stderr+p.stdout).lower() and "SHA" in (p.stderr+p.stdout)
    assert not (out/"rtnn_experiment.bin").exists()
