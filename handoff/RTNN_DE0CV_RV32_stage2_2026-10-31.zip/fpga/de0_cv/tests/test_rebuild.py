"""Host-side regression for exact frozen image and untrusted UART traffic."""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from frozen_image import (ZIP_SHA, ELF_SHA, BIN_SHA, RAM_BASE, RAM_BYTES, ALIAS_START,
                          ALIAS_BYTES, STACK_TOP, ENTRY, InvalidArtifact, map_address,
                          elf_details, derive_reference, build)
from capture_audit import audit, CaptureError
from empirical_report import analyze

@pytest.fixture(scope='session')
def frozen():
    path=ROOT/'artifacts/rtnn_ibex_rtl_exact.zip'
    with zipfile.ZipFile(path) as z:
        return z.read('rtnn_ibex_rtl.elf'),z.read('rtnn_ibex_rtl.bin')

@pytest.fixture(scope='session')
def reference():
    return json.loads((ROOT/'quartus/preflight_reference.json').read_text())

@pytest.fixture(scope='session')
def simlog():
    return (ROOT/'tests/fixtures/known_good_sim_uart.log').read_bytes()


def test_sha_identity(frozen):
    elf,binary=frozen
    assert hashlib.sha256((ROOT/'artifacts/rtnn_ibex_rtl_exact.zip').read_bytes()).hexdigest()==ZIP_SHA
    assert hashlib.sha256(elf).hexdigest()==ELF_SHA
    assert hashlib.sha256(binary).hexdigest()==BIN_SHA
    assert len(binary)==117658


def test_elf_mapping(frozen):
    elf,binary=frozen
    info=elf_details(elf,binary)
    assert info['entry']==ENTRY
    assert info['load_file_bytes']==len(binary)
    assert info['load_mem_bytes']==122312
    assert info['stack_top']==STACK_TOP
    assert info['image_end']<RAM_BASE+RAM_BYTES-ALIAS_BYTES


def test_memory_alias() -> None:
    assert map_address(RAM_BASE)==0
    assert map_address(RAM_BASE+RAM_BYTES-1)==RAM_BYTES-1
    assert map_address(ALIAS_START)==RAM_BYTES-ALIAS_BYTES
    assert map_address(STACK_TOP)==RAM_BYTES-16
    assert map_address(ALIAS_START+ALIAS_BYTES-1)==RAM_BYTES-1
    for bad in (RAM_BASE-1, RAM_BASE+RAM_BYTES,ALIAS_START-1,ALIAS_START+ALIAS_BYTES,0x20000):
        with pytest.raises(InvalidArtifact): map_address(bad)


def test_reference_exact(reference):
    v=reference['vectors']
    assert [(x['test_index'],x['preferred_exit']) for x in v]==[(0,1),(24,3),(57,5)]
    assert [x['expected_fixed_class_prediction'] for x in v]==[
        [3]*7,[6,6,4,4,4,4,4],[1,1,8,8,8,8,8]]
    assert len(reference['vectors'])==3
    assert all(len(x['input_u8_64'])==64 for x in v)


def test_mif_no_overlaps_and_hex_matches_elf(frozen):
    elf,binary=frozen
    path=ROOT/'quartus/rtnn_ram_words.hex'
    words=path.read_text().splitlines()
    assert len(words)==65536
    assert all(len(w)==8 and int(w,16)>=0 for w in words)
    data=b''.join(int(x,16).to_bytes(4,'little') for x in words)
    assert data[:len(binary)]==binary
    assert data[len(binary):]==b'\x00'*(RAM_BYTES-len(binary))
    mif=(ROOT/'quartus/rtnn_ram_words.mif').read_text().splitlines()
    assert mif[0]=='WIDTH=32;' and mif[-1]=='END;'
    import re
    entries={}
    for line in mif:
        m=re.fullmatch(r'  ([0-9A-F]{4}) : ([0-9A-F]{8});',line)
        if m:
            key=int(m[1],16)
            assert key not in entries
            entries[key]=int(m[2],16)
    assert len(entries)==(len(binary)+3)//4
    assert [entries[i] for i in range(len(entries))]==[int(w,16) for w in words[:len(entries)]]
    assert f'  [{len(entries):04X}..FFFF] : 00000000;' in mif


def test_reference_regenerated_from_zip(reference):
    with zipfile.ZipFile(ROOT/'artifacts/rtnn_ibex_rtl_exact.zip') as z:
        expect=derive_reference(z.read('rtnn/realtime_nn_ibex_rtl_vectors_generated.h').decode(),
                                json.loads(z.read('realtime_nn_ibex_rtl_validation_results.json')))
    assert expect == reference


def test_good_log_is_actual_sim_log(reference,simlog):
    result=audit(simlog,reference)
    assert result['decision']=='PASS_REFERENCE_CONSISTENT'
    assert result['certification_rows']==21 and result['legacy_e2e_rows']==21
    assert [x[0] for x in result['cert_cycles_by_class'].values()]==[
        29620,615569,1201521,1787473,2373425,2959377,2959381]
    assert result['uart_log_sha256']==hashlib.sha256(simlog).hexdigest()


def test_observation_never_certifies(reference,simlog):
    out=analyze(simlog,reference,50_000_000,origin='sim_reference')
    assert out['status']=='OBSERVED_NOT_WCET'
    assert out['reusable_admission_bounds'] is None
    assert out['production_wcets'] is None
    assert out['validated_record_count']==42
    with pytest.raises(ValueError):analyze(simlog,reference,0,origin='sim_reference')
    with pytest.raises(ValueError):analyze(simlog,reference,50_000_000,origin='certified')


@pytest.mark.parametrize('old,new',[
  ('CERT,0,0,0,29620,3','CERT,0,0,0,29620,4'),
  ('CERT,0,0,0,29620,3','CERT,0,0,0,-1,3'),
  ('CERT,0,0,0,29620,3','CERT,0,0,0,0,3'),
  ('CERT,0,0,0,29620,3','CERT,0,0,0,4294967296,3'),
  ('CERT,0,0,0,29620,3','CERT,0,0,0,29620,30'),
  ('CERT,0,0,0,29620,3','CERT,0,999,0,29620,3'),
  ('E2E,0,0,1,1,1,657454,3','E2E,0,0,1,1,2,657454,3'),
  ('E2E,0,0,1,1,1,657454,3','E2E,0,0,1,0,1,657454,3'),
  ('E2E,0,0,1,1,1,657454,3','E2E,0,0,1,1,1,657454,2'),
  ('OVERHEAD,ONE,6','OVERHEAD,ONE,nan'),
  ('DONE','DON3'),
])
def test_modified_log_rejected(reference,simlog,old,new):
    raw=simlog.decode()
    assert old in raw
    mutated=raw.replace(old,new,1).encode()
    with pytest.raises(CaptureError): audit(mutated,reference)
    with pytest.raises(CaptureError): analyze(mutated,reference,50_000_000,origin='fpga_unverified')

@pytest.mark.parametrize('modifier',[
    lambda x: x.replace('CERT,0,0,0,29620,3\n','',1),
    lambda x: x+'CERT,0,0,0,29620,3\n',
    lambda x: x.replace('DONE\n','',1),
    lambda x: x.replace('DONE\n','DONE\nDONE\n',1),
    lambda x: 'GARBAGE\n'+x,
    lambda x: x.replace('OVERHEAD,ONE,6\n','',1),
    lambda x: x.replace('CERT,0,0,0,29620,3\n','CERT,0,0,0,29620,3\n'*2,1),
    lambda x: x.replace('E2E,0,0,0,0,0,29843,3\n','',1),
])
def test_incomplete_or_duplicated_log_rejected(reference,simlog,modifier):
    with pytest.raises(CaptureError): audit(modifier(simlog.decode()).encode(),reference)


def test_tampered_source_artifact_fails(reference):
    bad=json.loads(json.dumps(reference))
    bad['source_artifact']['elf_sha256']='0'*64
    with pytest.raises(CaptureError):audit((ROOT/'tests/fixtures/known_good_sim_uart.log').read_bytes(),bad)


def test_mutated_frozen_zip_not_written(tmp_path):
    original=(ROOT/'artifacts/rtnn_ibex_rtl_exact.zip').read_bytes()
    tampered=original[:-1]+bytes([original[-1]^1])
    inp=tmp_path/'bad.zip';inp.write_bytes(tampered)
    with pytest.raises(InvalidArtifact):build(inp,tmp_path/'generated')
    assert not (tmp_path/'generated').exists()


def test_software_build_marked_uncertified():
    manifest=json.loads((ROOT/'quartus/frozen_image_manifest.json').read_text())
    assert manifest['status']=='PREPARED_NOT_SYNTHESIZED'
    assert manifest['ibex_commit']=='7b5df75a041affe56e8c235260f98a09b3319008'
    assert manifest['ram_hex_sha256']==hashlib.sha256((ROOT/'quartus/rtnn_ram_words.hex').read_bytes()).hexdigest()
