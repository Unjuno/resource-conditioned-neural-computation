"""Experimental runner protocol, data provenance, schedule, and audit (test-first)."""
import json
import sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))


def test_request_roundtrip_and_crc():
    from experiment_wire import Request, Mode, encode_request, decode_request, FrameError
    original = Request(seq=234, input_id=24, mode=Mode.ADAPTIVE,
                       fixed_exit=0, budget_q16=32768, deadline_cycles=4000000,
                       model_id=0x52544e4e, build_id=0x52544c31)
    wire = encode_request(original)
    assert len(wire) == 32
    assert wire[:4] == b'RTNQ'
    assert decode_request(wire) == original
    for corrupted in (wire[:-1], wire + b'x', wire[:10]+bytes([wire[10]^1])+wire[11:], wire[:5]+b'\xff'+wire[6:]):
        with pytest.raises(FrameError):decode_request(corrupted)


def test_request_validation_blocks_out_of_range_and_unknown_mode():
    from experiment_wire import Request, Mode, encode_request, FrameError
    good = dict(seq=1,input_id=3,mode=Mode.FIXED,fixed_exit=2,budget_q16=65535,
                deadline_cycles=0,model_id=0x52544e4e,build_id=1)
    for key,val in [('seq',-1),('input_id',65536),('fixed_exit',7),('budget_q16',65536),('model_id',-1),('mode',9)]:
        with pytest.raises(FrameError): encode_request(Request(**{**good,key:val}))


def test_response_roundtrip_and_failure_invariants():
    from experiment_wire import Response, Status, Mode, encode_response, decode_response, FrameError
    r = Response(seq=3,input_id=25,mode=Mode.ADAPTIVE,status=Status.OK,
                 stop_reason=1,budget_q16=32768,deadline_cycles=0,
                 admitted_exit=3,executed_exit=2,prediction=4,label=4,
                 cycles=12345,model_id=0x52544e4e,build_id=99,binding_id=0,flags=0)
    raw=encode_response(r)
    assert len(raw)==48
    assert decode_response(raw)==r
    with pytest.raises(FrameError):decode_response(raw[:30]+bytes([raw[30]^1])+raw[31:])
    with pytest.raises(FrameError):encode_response(Response(**{**r.__dict__,'executed_exit':4}))
    with pytest.raises(FrameError):encode_response(Response(**{**r.__dict__,'cycles':-1}))
    bad=Response(**{**r.__dict__,'status':Status.REJECTED,'admitted_exit':-1,
                    'executed_exit':-1,'prediction':-1,'cycles':0})
    assert decode_response(encode_response(bad))==bad
    with pytest.raises(FrameError):encode_response(Response(**{**bad.__dict__,'executed_exit':0}))


def test_reference_matches_frozen_three_indices():
    from experiment_dataset import generate_heldout
    ref=json.loads((ROOT/'quartus/preflight_reference.json').read_text())
    out=generate_heldout(ref)
    assert out['schema']=='rtnn-de0cv-heldout-digits-v1'
    assert out['status']=='INPUTS_ONLY_Q15_PREDICTIONS_PENDING'
    assert len(out['records'])==360
    assert len({r['source_index'] for r in out['records']})==360
    for v in ref['vectors']:
        row=out['records'][v['test_index']]
        assert row['pixels_u8_64']==v['input_u8_64']
        assert row['label']==v['label']
    assert len(out['dataset_sha256'])==64


def test_schedule_full_and_reproducible():
    from experiment_matrix import make_matrix
    m=make_matrix(seed=17,count=360,which='fixed')
    assert m['status']=='PLANNED_NOT_EXECUTED'
    assert len(m['rows'])==2520
    assert len(set((r['input_id'],r['mode'],r['fixed_exit'],r['budget_q16']) for r in m['rows']))==2520
    a=make_matrix(seed=17,count=360,which='adaptive')
    assert len(a['rows'])==7560
    assert make_matrix(seed=17,count=360,which='adaptive')==a
    assert make_matrix(seed=23,count=360,which='adaptive')['rows']!=a['rows']
    assert set(x['budget_q16'] for x in a['rows']) == set(round(i*65535/20) for i in range(21))
    assert len(make_matrix(seed=1,count=360,which='paired')['rows'])==720
    assert len(make_matrix(seed=1,count=360,which='deadline')['rows'])==52920


def test_trace_audit_requires_complete_unique_and_binding(tmp_path):
    from experiment_wire import Request,Response,Status,Mode,encode_request,encode_response
    from experiment_audit import audit_trace, AuditError
    from experiment_matrix import make_matrix
    from experiment_dataset import generate_heldout
    ds=generate_heldout(json.loads((ROOT/'quartus/preflight_reference.json').read_text()))
    matrix=make_matrix(seed=2,count=3,which='fixed')
    cases=[]
    for r in matrix['rows']:
        q=Request(seq=r['seq'],input_id=r['input_id'],mode=Mode.FIXED,
                  fixed_exit=r['fixed_exit'],budget_q16=r['budget_q16'],
                  deadline_cycles=r['deadline_cycles'],model_id=0x52544e4e,build_id=1)
        v=ds['records'][r['input_id']]
        response=Response(seq=q.seq,input_id=q.input_id,mode=q.mode,status=Status.OK,
                          stop_reason=0,budget_q16=q.budget_q16,deadline_cycles=q.deadline_cycles,
                          admitted_exit=q.fixed_exit,executed_exit=q.fixed_exit,prediction=v['label'],label=v['label'],
                          cycles=100+q.fixed_exit,model_id=q.model_id,build_id=q.build_id,binding_id=0,flags=0)
        cases.append({'request_hex':encode_request(q).hex(),'response_hex':encode_response(response).hex()})
    def audit(rows,orig='synthetic_fixture',sha=None):
        return audit_trace({'schema':'rtnn-de0cv-experiment-trace-v1','origin':orig,
                            'status':'SYNTHETIC_NOT_BOARD' if orig=='synthetic_fixture' else 'CAPTURE_COMPLETE_UNAUDITED',
                            'sof_sha256':sha,'rows':rows},matrix,ds)
    ok=audit(cases)
    assert ok['status']=='HOST_STRUCTURE_PASS_Q15_REFERENCE_PENDING'
    assert ok['record_count']==21
    with pytest.raises(AuditError):audit(cases[:-1])
    with pytest.raises(AuditError):audit(cases+[cases[0]])
    with pytest.raises(AuditError):audit(cases,'fpga_de0cv')
    with pytest.raises(AuditError):audit(cases,'fpga_de0cv','a'*64)  # not equal to actual build manifest
    realish={'schema':'rtnn-de0cv-experiment-trace-v1','origin':'fpga_de0cv',
             'status':'CAPTURE_COMPLETE_UNAUDITED',
             'sof_sha256':'a'*64,'capture_transport':'uart_rx_3v3',
             'dataset_sha256':'0'*64,'schedule_sha256':matrix['schedule_sha256'],'rows':cases}
    with pytest.raises(AuditError,match='dataset SHA'):
        audit_trace(realish,matrix,ds,expected_sof_sha256='a'*64,
                    expected_build_id=1,expected_binding_id=0)
    bad=json.loads(json.dumps(cases));bad[3]['response_hex']=bad[3]['response_hex'][:-2]+'ff'
    with pytest.raises(AuditError):audit(bad)


def test_analysis_paired_cycles_not_block_fraction(tmp_path):
    from experiment_analysis import paired_metrics, AnalysisError
    rows=[{'input_id':0,'fixed2_cycles':1200,'adaptive_cycles':800,'fixed2_correct':1,'adaptive_correct':1},
          {'input_id':1,'fixed2_cycles':1300,'adaptive_cycles':1700,'fixed2_correct':1,'adaptive_correct':0},
          {'input_id':2,'fixed2_cycles':1400,'adaptive_cycles':700,'fixed2_correct':0,'adaptive_correct':1}]
    m=paired_metrics(rows,bootstrap_seed=7)
    assert m['n']==3
    assert m['mean_fixed2_cycles']==1300
    assert m['mean_adaptive_cycles'] == pytest.approx(1066.6666666667)
    assert m['paired_accuracy_delta_pp']==0
    assert m['mean_cycle_saving']>0
    assert m['cycle_speedup_ratio']>1
    with pytest.raises(AnalysisError):paired_metrics(rows+[rows[0]])
    with pytest.raises(AnalysisError):paired_metrics(rows[:1]+[{**rows[1],'adaptive_cycles':-1}]+rows[2:])


def test_status_mode_is_no_inference_ack():
    from experiment_wire import Response,Status,Mode,encode_response,decode_response
    s=Response(seq=10,input_id=0,mode=Mode.STATUS,status=Status.OK,stop_reason=0,
               budget_q16=0,deadline_cycles=0,admitted_exit=-1,executed_exit=-1,
               prediction=-1,label=-1,cycles=0,model_id=1,build_id=2,binding_id=0,flags=0)
    assert decode_response(encode_response(s))==s


def test_audit_cannot_promote_unverified_q15_reference():
    from experiment_audit import audit_trace,AuditError
    from experiment_dataset import generate_heldout
    from experiment_matrix import make_matrix
    ds=generate_heldout(json.loads((ROOT/'quartus/preflight_reference.json').read_text()))
    matrix=make_matrix(seed=1,count=1,which='fixed')
    fake={'schema':'rtnn-de0cv-frozen-q15-reference-v1','status':'TEST_FIXTURE_ONLY',
          'dataset_sha256':ds['dataset_sha256'],
          'predictions':{'0':{'predictions':[3]*7,'preferred_exit':1}}}
    trace={'schema':'rtnn-de0cv-experiment-trace-v1','origin':'synthetic_fixture','rows':[]}
    with pytest.raises(AuditError,match='Q15 oracle'):
        audit_trace(trace,matrix,ds,q15_oracle=fake)
