"""Machine-readable offline provenance must never claim an FPGA result."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))

def test_offline_manifest_separates_native_from_fpga(tmp_path):
    from offline_manifest import make_manifest
    manifest=make_manifest(ROOT,tmp_path/'offline.json')
    assert manifest['status']=='OFFLINE_VERIFIED_FPGA_UNTESTED'
    assert manifest['q15']['predictions_sha256']=='03eb958cfa8b4fd2f71a95fb47dbca512820c237c281473817bba685b92c743e'
    assert manifest['native_firmware']['functional_cases']==10080
    assert manifest['fpga']['physical_measurement_count']==0
    assert manifest['fpga']['sta_verified'] is False
