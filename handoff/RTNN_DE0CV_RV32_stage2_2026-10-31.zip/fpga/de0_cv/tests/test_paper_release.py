"""Publication pipeline must keep negative results and reject fake performance."""
import json,sys,importlib.util
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))

def module(name):
    assert importlib.util.find_spec(name) is not None, f'{name} is not implemented yet'
    return __import__(name)

def test_campaign_contains_only_frozen_existing_methods(tmp_path):
    c=module('paper_campaign').prepare(ROOT,tmp_path/'campaign')
    assert c['scope']=='EXISTING_METHOD_ONLY'
    assert c['primary_sessions']==10
    assert c['unique_accuracy_inputs']==360
    assert len(c['schedules'])==13
    total=0
    for entry in c['schedules']:
        m=json.loads((tmp_path/'campaign'/entry['matrix']).read_text())
        total+=len(m['rows'])
        assert all(r['mode'] in [1,2,3] and r['deadline_cycles']==0 for r in m['rows'])
        if m['experiment']=='paired':
            assert len(m['rows'])==720
            ab=0
            for a,b in zip(m['rows'][::2],m['rows'][1::2]):
                assert a['input_id']==b['input_id']
                assert {a['mode'],b['mode']}=={1,3}
                ab+=a['mode']==1
            assert ab==180
    assert total==24840

def test_campaign_is_deterministic_and_does_not_overwrite(tmp_path):
    mod=module('paper_campaign')
    a=mod.prepare(ROOT,tmp_path/'a');b=mod.prepare(ROOT,tmp_path/'b')
    assert a==b
    with pytest.raises(ValueError):mod.prepare(ROOT,tmp_path/'a')

def test_missing_real_hardware_evidence_blocks(tmp_path):
    c=module('paper_campaign');c.prepare(ROOT,tmp_path/'campaign')
    p=module('paper_results')
    with pytest.raises(ValueError,match='hardware|review|evidence'):
        p.load_hardware(tmp_path/'campaign')

def test_synthetic_cannot_be_promoted_by_q15_matching():
    p=module('paper_results')
    with pytest.raises(ValueError,match='physical|synthetic'):
        p.require_physical_trace({'origin':'synthetic_fixture','status':'CAPTURE_COMPLETE_UNAUDITED'})

def test_statistics_dont_inflate_accuracy_sample_size():
    p=module('paper_results');rows=[]
    for boot in range(10):
        for i in range(4):
            rows.append(dict(session_id=str(boot),input_id=i,fixed2_cycles=100,
                adaptive_cycles=80,fixed2_correct=int(i!=0),adaptive_correct=int(i!=0)))
    m=p.primary_metrics(rows,bootstrap_samples=500)
    assert m['unique_inputs']==4
    assert m['sessions']==10
    assert m['timing_pairs']==40
    assert m['accuracy_denominator']==4
    assert m['cycle_saving_fraction']==pytest.approx(.2)
    assert m['accuracy_delta_pp']==0
    assert m['mean_cycle_saving_ci95']==[20.,20.]

def test_negative_timing_result_is_reported_not_discarded():
    p=module('paper_results')
    rows=[dict(session_id='b1',input_id=i,fixed2_cycles=100,adaptive_cycles=125,
               fixed2_correct=1,adaptive_correct=1) for i in range(5)]
    m=p.primary_metrics(rows,bootstrap_samples=500)
    assert m['mean_cycle_saving']==-25
    assert m['performance_decision']=='NO_SPEEDUP_OBSERVED'
    assert m['cycle_speedup_ratio']==pytest.approx(.8)

def test_duplicate_pair_and_missing_input_rejected():
    p=module('paper_results')
    a=dict(session_id='b1',input_id=0,fixed2_cycles=100,adaptive_cycles=80,fixed2_correct=1,adaptive_correct=1)
    with pytest.raises(ValueError):p.primary_metrics([a,a],bootstrap_samples=500)
    b={**a,'input_id':1};c={**a,'session_id':'b2'}
    with pytest.raises(ValueError):p.primary_metrics([a,b,c],bootstrap_samples=500)

def test_prediction_instability_across_repeats_rejected():
    p=module('paper_results')
    a=dict(session_id='b1',input_id=0,fixed2_cycles=100,adaptive_cycles=80,fixed2_correct=1,adaptive_correct=1)
    with pytest.raises(ValueError):p.primary_metrics([a,{**a,'session_id':'b2','adaptive_correct':0}],bootstrap_samples=500)

def test_collector_refuses_before_opening_serial_without_hardware(tmp_path):
    module('paper_campaign').prepare(ROOT,tmp_path/'campaign')
    c=module('paper_collect')
    with pytest.raises(ValueError):c.collect(ROOT,tmp_path/'campaign','primary_01','/dev/DOES_NOT_EXIST')

def test_full_export_pipeline_with_test_only_physical_metadata(tmp_path):
    """All bytes here are synthetic test fixtures in tmp_path, NEVER measurements.
    Exercise real validators/file hashes/statistics without a real serial port.
    """
    from paper_campaign import prepare,MODEL_ID,BUILD_ID
    from paper_results import export_results,load_hardware
    from experiment_wire import Request,Response,Mode,Status,encode_request,encode_response
    import hashlib
    base=tmp_path/'test_campaign';c=prepare(ROOT,base)
    h=json.loads((base/'hardware_review.json').read_text())
    h.update(status='OPERATOR_REVIEWED_FOR_EMPIRICAL_RUN',pcb_revision='TEST_ONLY',
        board_identifier='SYNTHETIC_UNIT_TEST_NOT_A_BOARD',clock_hz=50000000,
        clock_source_and_tolerance='SYNTHETIC_TEST_ONLY',reviewer='TEST',reviewed_at_utc='TEST')
    h['gates']={k:True for k in h['gates']};h['tools']={k:'TEST' for k in h['tools']}
    for key in h['files']:
        fp=base/'evidence'/key;fp.write_bytes(('SYNTHETIC UNIT TEST ONLY '+key).encode())
        h['files'][key]={'path':str(fp.relative_to(base)),'sha256':hashlib.sha256(fp.read_bytes()).hexdigest()}
    (base/'hardware_review.json').write_text(json.dumps(h))
    assert load_hardware(base)['board_identifier']=='SYNTHETIC_UNIT_TEST_NOT_A_BOARD'
    ds=json.loads((ROOT/'generated/heldout360.json').read_text())
    oracle=json.loads((ROOT/'generated/frozen_q15_oracle.json').read_text())
    hardware_hash=hashlib.sha256((base/'hardware_review.json').read_bytes()).hexdigest()
    for spec in c['schedules']:
        sid=spec['session_id'];mp=json.loads((base/spec['matrix']).read_text())
        ss=base/'sessions'/f'{sid}.json';s=json.loads(ss.read_text())
        s.update(status='READY_FOR_ACQUISITION',boot_id=sid,operator='TEST',started_at_utc='TEST',
                 board_identifier=h['board_identifier'],cold_boot_confirmed=True,programming_log=h['files']['programming_log'])
        ss.write_text(json.dumps(s));rows=[];events=[]
        for r in mp['rows']:
            q=Request(**r,model_id=MODEL_ID,build_id=BUILD_ID);ref=oracle['predictions'][str(q.input_id)]
            cap=q.budget_q16*6//65535
            e=q.fixed_exit if q.mode==Mode.FIXED else cap if q.mode==Mode.CAPPED_NO_STOP else min(cap,5,ref['preferred_exit'])
            reason=0 if q.mode in (Mode.FIXED,Mode.CAPPED_NO_STOP) else 1 if e<min(cap,5) else 2
            rsp=Response(q.seq,q.input_id,q.mode,Status.OK,reason,q.budget_q16,0,
                 q.fixed_exit if q.mode==Mode.FIXED else cap,e,ref['predictions'][e],ds['records'][q.input_id]['label'],
                 100+e*100,MODEL_ID,BUILD_ID,0,0)
            raw={'request_hex':encode_request(q).hex(),'response_hex':encode_response(rsp).hex()}
            rows.append(raw);events.append({**raw,'status':'DECODED_IDENTITY_MATCHED'})
        journal=base/'captures'/f'{sid}.wire.jsonl';journal.write_text(''.join(json.dumps(x)+'\n' for x in events))
        trace={'schema':'rtnn-de0cv-experiment-trace-v1','origin':'fpga_de0cv','status':'CAPTURE_COMPLETE_UNAUDITED',
          'capture_transport':'uart_rx_3v3','sof_sha256':h['files']['sof']['sha256'],
          'dataset_sha256':ds['dataset_sha256'],'schedule_sha256':mp['schedule_sha256'],
          'campaign_sha256':c['campaign_sha256'],'session_id':sid,'hardware_review_sha256':hardware_hash,
          'session_review_sha256':hashlib.sha256(ss.read_bytes()).hexdigest(),
          'wire_journal':{'path':str(journal.relative_to(base)),'sha256':hashlib.sha256(journal.read_bytes()).hexdigest()},'rows':rows}
        (base/'captures'/f'{sid}.json').write_text(json.dumps(trace))
    report=export_results(ROOT,base,tmp_path/'test_report')
    assert report['primary']['unique_inputs']==360
    assert report['primary']['timing_pairs']==3600
    assert report['primary']['sessions']==10
    assert report['primary']['fixed2_accuracy']==339/360
    assert len(report['secondary'])==49
    assert (tmp_path/'test_report/per_request.csv').read_text().count('\n')==24841
    assert report['primary']['hard_wcet_proven'] is False
    plots=module('paper_plots').render(tmp_path/'test_report/results.json',tmp_path/'test_plots')
    assert len([x for x in plots if x.suffix=='.png'])==4
    # Derived tables must stay bound to the JSON that produced the plots.
    paired_csv=tmp_path/'test_report/paired_by_input_session.csv'
    original=paired_csv.read_bytes();paired_csv.write_bytes(original+b'\n')
    with pytest.raises(ValueError,match='hash|changed'):
        module('paper_plots').render(tmp_path/'test_report/results.json',tmp_path/'bad_plots')
    paired_csv.write_bytes(original)
    # Counterbalanced sequence order is part of the experiment, not merely IDs.
    trace_path=base/'captures/primary_01.json';t=json.loads(trace_path.read_text())
    journal=base/t['wire_journal']['path'];ev=[json.loads(x) for x in journal.read_text().splitlines()]
    t['rows'][0],t['rows'][1]=t['rows'][1],t['rows'][0]
    ev[0],ev[1]=ev[1],ev[0]
    journal.write_text(''.join(json.dumps(x)+'\n' for x in ev))
    t['wire_journal']['sha256']=hashlib.sha256(journal.read_bytes()).hexdigest()
    trace_path.write_text(json.dumps(t))
    with pytest.raises(ValueError,match='order'):
        export_results(ROOT,base,tmp_path/'invalid_order_report')
    # A missing physical evidence file blocks even though all numeric data match.
    (base/h['files']['sof']['path']).unlink()
    with pytest.raises(ValueError,match='evidence'):
        export_results(ROOT,base,tmp_path/'invalid_report')

def test_plotter_refuses_unmeasured_or_synthetic_report(tmp_path):
    p=module('paper_plots')
    src=tmp_path/'r.json';src.write_text(json.dumps({'status':'SYNTHETIC_NOT_BOARD'}))
    with pytest.raises(ValueError):p.render(src,tmp_path/'figs')
