import sys
import zipfile
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))

def test_original_old_elf_not_accepted_as_b_build():
    from build_b_image import build, InvalidBImage
    with zipfile.ZipFile(ROOT/'artifacts/rtnn_ibex_rtl_exact.zip') as z:
        elf=z.read('rtnn_ibex_rtl.elf')
        binary=z.read('rtnn_ibex_rtl.bin')
    with pytest.raises(InvalidBImage):build(elf,binary)
