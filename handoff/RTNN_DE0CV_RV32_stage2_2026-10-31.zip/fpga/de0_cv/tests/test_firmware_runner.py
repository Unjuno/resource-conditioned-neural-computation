"""Native host smoke tests of firmware dispatcher using a *stub* core.

Tests only control flow and the binary protocol. This does NOT prove Q15
functionality; that needs the real model and a separately pinned oracle.
"""
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from experiment_wire import (Request,Response,Mode,Status,encode_request,decode_response)


def compile_runner(tmp_path):
    import json
    from experiment_dataset import generate_heldout
    ref=json.loads((ROOT/'quartus/preflight_reference.json').read_text())
    data=generate_heldout(ref)
    # generator must have created a header so firmware uses the exact frozen inputs
    inputfile=ROOT/'generated/heldout360.h'
    if not inputfile.exists():
        r=subprocess.run([sys.executable,'tools/experiment_dataset.py',
                          '--preflight','quartus/preflight_reference.json',
                          '--out','generated/heldout360.json',
                          '--c-header',str(inputfile)],cwd=ROOT,capture_output=True,text=True)
        assert r.returncode==0,r.stderr
    exe=tmp_path/'firmware_host_stub'
    r=subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror',
                      '-Ifirmware','-Igenerated','-Itests/fixtures',
                      'firmware/rtnn_experiment_wire.c','firmware/rtnn_experiment_runner.c',
                      'tests/fixtures/firmware_core_stub.c',
                      'tests/fixtures/firmware_runner_host_main.c',
                      '-o',str(exe)],cwd=ROOT,capture_output=True,text=True)
    assert r.returncode==0,r.stderr
    return exe


def query(exe,req):
    r=subprocess.run([str(exe)],input=encode_request(req).hex()+'\n',
                     capture_output=True,text=True)
    assert r.returncode==0,r.stderr
    return decode_response(bytes.fromhex(r.stdout.strip()))


def test_firmware_dispatch_and_fail_closed(tmp_path):
    exe=compile_runner(tmp_path)
    def req(mode,*,budget=65535,deadline=0,exit=0,build=0x44563032):
        return Request(seq=7,input_id=24,mode=mode,fixed_exit=exit,budget_q16=budget,
                       deadline_cycles=deadline,model_id=0x52544e4e,build_id=build)
    s=query(exe,req(Mode.STATUS))
    assert s.status==Status.OK and s.executed_exit==-1 and s.cycles==0
    f=query(exe,req(Mode.FIXED,exit=6))
    assert f.status==Status.OK and f.executed_exit==6 and f.admitted_exit==6
    a=query(exe,req(Mode.ADAPTIVE,budget=32768))
    assert a.status==Status.OK and a.executed_exit<=3
    bad=query(exe,req(Mode.FIXED,exit=3,build=9))
    assert bad.status==Status.WRONG_ID and bad.executed_exit==-1 and bad.cycles==0
    d=query(exe,req(Mode.DEADLINE_ADAPTIVE,deadline=5000000))
    assert d.status==Status.REJECTED and d.executed_exit==-1
    assert d.label==-1 and d.stop_reason==0  # no accepted inference took place
