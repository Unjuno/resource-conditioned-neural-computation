import hashlib
import json
import sys
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))


def test_preparer_refuses_missing_flat_and_original_A_image(tmp_path):
    from prepare_b_quartus import prepare,BuildPreparationError
    raw=(ROOT/'quartus/rtnn_ram_words.hex').read_bytes()
    source=tmp_path/'b';source.mkdir()
    (source/'rtnn_ram_words.hex').write_bytes(raw)
    manifest={'status':'IMAGE_GENERATED_NOT_SYNTHESIZED',
              'hex_sha256':hashlib.sha256(raw).hexdigest(),
              'bin_sha256':'f'*64,'schema':'rtnn-de0cv-b-firmware-ram-v1'}
    (source/'fpga_b_image_manifest.json').write_text(json.dumps(manifest))
    with pytest.raises(BuildPreparationError):prepare(ROOT,source,tmp_path/'quartus_b',tmp_path/'missing.v')
    flat=tmp_path/'ibex_flat.v';flat.write_text('module test; endmodule\n')
    with pytest.raises(BuildPreparationError,match='frozen A RAM image'):
        prepare(ROOT,source,tmp_path/'quartus_b',flat)
    assert not (tmp_path/'quartus_b').exists()
