"""Reproduce complete 360x2 ISA-level predictions with actual RV32 code.

The test may run with a local Clang+LLD+G++ toolchain; it does not
require a physical board or claim an Ibex timing proof.
"""
import json
import shutil
import subprocess
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]


def test_all_720_experiment_requests_execute_in_rv32_isa(tmp_path):
    for tool in ('g++','clang','ld.lld','llvm-objcopy','readelf'):
        if not shutil.which(tool):pytest.skip(tool+' not installed')
    build=tmp_path/'b'
    p=subprocess.run(['bash',str(ROOT/'tools/build_b_firmware_clang.sh'),str(build),str(ROOT/'upstream/source_repo')],cwd=ROOT,capture_output=True,text=True,timeout=60)
    assert p.returncode==0,p.stdout+p.stderr
    emulator=tmp_path/'rtnn_rv32_isa'
    p=subprocess.run(['g++','-O3','-std=c++17',str(ROOT/'tools/rtnn_rv32_isa_smoke.cpp'),'-o',str(emulator)],capture_output=True,text=True,timeout=40)
    assert p.returncode==0,p.stdout+p.stderr
    out=tmp_path/'results'
    p=subprocess.run(['python3',str(ROOT/'tools/rv32_isa_full_gate.py'),
                      '--binary',str(build/'rtnn_experiment.bin'),'--emulator',str(emulator),
                      '--out-dir',str(out)],cwd=ROOT,capture_output=True,text=True,timeout=120)
    assert p.returncode==0,p.stdout+p.stderr
    j=json.loads((out/'isa_gate.json').read_text())
    assert j['decision']=='PASS_ISA_LEVEL_ONLY'
    assert j['requests_checked']==720
    assert j['prediction_mismatches']==0
    assert j['execution_mismatches']==0
    assert j['fixed2_correct']==339
    assert j['adaptive_correct']==339
    assert j['adaptive_exit_histogram']==[0,263,81,7,2,7,0]
    assert j['not_rtl_or_fpga_timing'] is True
