module tb_rtnn_uart_tx;
  logic clk=0; always #5 clk=~clk;
  logic rst_n=0,start=0,tx,ready;
  logic [7:0] data;
  rtnn_uart_tx #(.CLOCK_HZ(8000),.BAUD(1000)) dut (
    .clk_i(clk),.rst_ni(rst_n),.start_i(start),.data_i(data),
    .tx_o(tx),.ready_o(ready));
  task automatic transmit(input logic [7:0] c);
    @(negedge clk);
    while (!ready) @(negedge clk);
    data=c; start=1;
    @(posedge clk); #1;
    if (tx!==1'b0) $fatal(1,"start bit");
    @(negedge clk); start=0;
    repeat(12) @(posedge clk);
    for (int i=0;i<8;i++) begin
      if (tx !== c[i]) $fatal(1,"data bit %0d wrong",i);
      repeat(8) @(posedge clk);
    end
    if (tx!==1'b1) $fatal(1,"stop bit");
    repeat(10) @(posedge clk);
    if (!ready || !tx) $fatal(1,"did not return idle");
  endtask
  initial begin
    repeat(3) @(negedge clk); rst_n=1;
    transmit(8'h41);
    transmit(8'h0a);
    $display("UART_TX_TEST_PASS");$finish;
  end
endmodule
