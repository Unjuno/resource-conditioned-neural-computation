module tb_rtnn_uart_rx;
  logic clk=0;always #5 clk=~clk;
  logic rst_n=0,rx=1;logic [7:0] ch;logic valid,frame_err;
  int n=0;
  rtnn_uart_rx #(.CLOCK_HZ(1000000),.BAUD(100000)) dut (
    .clk_i(clk),.rst_ni(rst_n),.rx_i(rx),.byte_o(ch),
    .valid_o(valid),.framing_error_o(frame_err));
  always @(posedge clk) if(valid) begin
    n++;
    if(ch !== 8'ha5) $fatal(1,"RX byte mismatch");
  end
  initial begin
    repeat(5) @(negedge clk);rst_n=1;
    @(negedge clk);rx=0;
    repeat(10) @(negedge clk);
    for (int i=0;i<8;i++)begin
      rx=((8'ha5 >> i) & 1'b1);repeat(10) @(negedge clk);
    end
    rx=1;repeat(20) @(negedge clk);
    if(n!=1||frame_err) $fatal(1,"RX did not decode one valid frame");
    $display("UART_RX_TEST_PASS");$finish;
  end
endmodule
