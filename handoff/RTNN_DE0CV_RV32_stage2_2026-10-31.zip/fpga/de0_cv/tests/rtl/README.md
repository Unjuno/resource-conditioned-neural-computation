These testbenches are NOT claimed to have executed in the current environment.
When Verilator is installed, use ../../tools/run_rtl_unit_tests.sh. The RAM
one-cycle/stack-alias bench and UART bench are unit tests. They do NOT verify
the entire Ibex SoC, Quartus inference, or post-synthesis timing.
