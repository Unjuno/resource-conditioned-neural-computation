module tb_rtnn_de0_cv_ram;
  logic clk = 0;
  always #5 clk = ~clk;
  logic rst_n=0;
  logic dreq=0,dwe=0, ireq=0;
  logic [3:0] be=4'hf;
  logic [31:0] daddr=32'h00100000, dwdata=0, iaddr=32'h00100000;
  logic dhit,dvalid,ihit,ivalid;
  logic [31:0] drdata,irdata;
  rtnn_de0_cv_ram dut (
    .clk_i(clk),.rst_ni(rst_n),.data_req_i(dreq),.data_we_i(dwe),
    .data_be_i(be),.data_addr_i(daddr),.data_wdata_i(dwdata),
    .data_hit_o(dhit),.data_rvalid_o(dvalid),.data_rdata_o(drdata),
    .instr_req_i(ireq),.instr_addr_i(iaddr),
    .instr_hit_o(ihit),.instr_rvalid_o(ivalid),.instr_rdata_o(irdata)
  );
  initial begin
    repeat(3) @(negedge clk);
    rst_n=1;
    // Exact frozen ELF trap vector is 'j _trap': 0x0000006f.
    ireq=1; iaddr=32'h00100000;
    @(posedge clk); #1;
    if (!ivalid || !ihit || irdata !== 32'h0000006f) $fatal(1,"trap vector read");
    @(negedge clk);ireq=0;
    // Stack top alias at 0x001ffff0 maps to on-chip 0x0013fff0.
    dreq=1;dwe=1;daddr=32'h001ffff0;dwdata=32'haabbccdd;
    @(posedge clk); #1;
    if (!dvalid || !dhit) $fatal(1,"stack write");
    @(negedge clk);dwe=0;daddr=32'h0013fff0;
    @(posedge clk); #1;
    if (drdata !== 32'haabbccdd) $fatal(1,"alias did not map same words");
    @(negedge clk);daddr=32'h00140000;
    #1; if (dhit) $fatal(1,"oversized direct region decoded");
    daddr=32'h001f7ffc;
    #1; if (dhit) $fatal(1,"alias underrun decoded");
    $display("RAM_ALIAS_TEST_PASS");$finish;
  end
endmodule
