"""Execute the actual B RV32 binary against a deterministic ISA-level test peripheral.

Not an Ibex RTL, bus latency, or FPGA timing simulator.
"""
import json
import shutil
import subprocess
import sys
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from experiment_wire import Request,Mode,Status,encode_request,decode_response,RESPONSE

@pytest.mark.parametrize("ids_modes",[[(0,Mode.FIXED),(24,Mode.ADAPTIVE),(57,Mode.ADAPTIVE)]])
def test_rv32_machine_image_executes_q15_protocol(ids_modes,tmp_path):
    for tool in ('g++','clang','ld.lld','llvm-objcopy','readelf'):
        if not shutil.which(tool):pytest.skip('tool missing: '+tool)
    out=tmp_path/'b'
    proc=subprocess.run(['bash',str(ROOT/'tools/build_b_firmware_clang.sh'),str(out),
                         str(ROOT/'upstream/source_repo')],cwd=ROOT,capture_output=True,text=True)
    assert proc.returncode==0,proc.stdout+proc.stderr
    emulator=tmp_path/'rtnn_rv32_isa'
    cp=subprocess.run(['g++','-O2','-std=c++17','-Wall','-Wextra',
                       str(ROOT/'tools/rtnn_rv32_isa_smoke.cpp'),'-o',str(emulator)],
                      capture_output=True,text=True)
    assert cp.returncode==0,cp.stdout+cp.stderr
    requests=[]
    for seq,(iid,mode) in enumerate(ids_modes):
        requests.append(Request(seq=seq+1,input_id=iid,mode=mode,
                                fixed_exit=2 if mode==Mode.FIXED else 0,
                                budget_q16=65535,deadline_cycles=0,
                                model_id=0x52544e4e,build_id=0x44563032))
    p=subprocess.run([str(emulator),str(out/'rtnn_experiment.bin'),str(len(requests))],
                     input=b''.join(encode_request(x) for x in requests),
                     capture_output=True,timeout=90)
    assert p.returncode==0,p.stderr.decode(errors='replace')
    assert len(p.stdout)==RESPONSE.size*len(requests)
    oracle=json.loads((ROOT/'generated/frozen_q15_oracle.json').read_text())['predictions']
    data=json.loads((ROOT/'generated/heldout360.json').read_text())['records']
    for i,q in enumerate(requests):
        r=decode_response(p.stdout[i*RESPONSE.size:(i+1)*RESPONSE.size])
        ref=oracle[str(q.input_id)]
        expected_depth=2 if q.mode==Mode.FIXED else ref['preferred_exit']
        assert (r.seq,r.input_id,r.mode,r.status)==(q.seq,q.input_id,q.mode,Status.OK)
        assert r.prediction==ref['predictions'][expected_depth]
        assert r.executed_exit==expected_depth
        assert r.label==data[q.input_id]['label']
        assert r.cycles>0


def test_rv32_rejects_bad_crc_wrong_build_and_uncertified_deadline(tmp_path):
    for tool in ('g++','clang','ld.lld','llvm-objcopy','readelf'):
        if not shutil.which(tool):pytest.skip('tool missing: '+tool)
    out=tmp_path/'b'
    p=subprocess.run(['bash',str(ROOT/'tools/build_b_firmware_clang.sh'),str(out),str(ROOT/'upstream/source_repo')],
                     cwd=ROOT,capture_output=True,text=True,timeout=40)
    assert p.returncode==0,p.stdout+p.stderr
    emulator=tmp_path/'rv32'
    p=subprocess.run(['g++','-O3','-std=c++17',str(ROOT/'tools/rtnn_rv32_isa_smoke.cpp'),'-o',str(emulator)],
                     capture_output=True,text=True,timeout=30)
    assert p.returncode==0,p.stdout+p.stderr
    def req(seq,mode,build=0x44563032):
        return Request(seq=seq,input_id=0,mode=mode,fixed_exit=0,
                       budget_q16=65535,deadline_cycles=100000,
                       model_id=0x52544e4e,build_id=build)
    good=encode_request(req(1,Mode.STATUS))
    bad=bytearray(good)
    bad[-1]^=0x01 # corrupt CRC; firmware must reject
    stream=bytes(bad)+good+encode_request(req(2,Mode.ADAPTIVE,0x11111111))+encode_request(req(3,Mode.DEADLINE_ADAPTIVE))
    p=subprocess.run([str(emulator),str(out/'rtnn_experiment.bin'),'4'],input=stream,
                     capture_output=True,timeout=30)
    assert p.returncode==0,p.stderr.decode(errors='replace')
    statuses=[decode_response(p.stdout[i*RESPONSE.size:(i+1)*RESPONSE.size]).status
              for i in range(4)]
    assert statuses==[Status.BAD_FRAME,Status.OK,Status.WRONG_ID,Status.REJECTED]
