"""Host compiler checks syntax of embedded board main, not RV32 linking or RTL."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]

def test_baremetal_main_compiles_as_host_c(tmp_path):
    r=subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror',
                      '-DHOST_SYNTAX_ONLY','-Ifirmware',
                      '-c','firmware/rtnn_board_main.c',
                      '-o',str(tmp_path/'board.o')],cwd=ROOT,capture_output=True,text=True)
    assert r.returncode==0,r.stderr


def test_host_model_reference_exposes_full_exit_and_preferred():
    s=(ROOT/'firmware/rtnn_host_model_reference.c').read_text()
    assert 'rtnn_fixed_infer_exit' in s
    assert 'rtnn_fixed_preferred_exit' in s
    assert 'RTNN_TEST_COUNT' in s
