"""PC<->firmware binary stop-and-wait, no timing claims from UART latency."""
import sys
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from experiment_wire import (Request, Response,Mode,Status,encode_response,decode_request)

class FakeSerial:
    def __init__(self, mutate=None):
        self.out=b'';self.rx=b'';self.mutate=mutate
    def write(self, buf):
        self.out+=buf
        q=decode_request(buf)
        r=Response(seq=q.seq,input_id=q.input_id,mode=q.mode,status=Status.OK,
                   stop_reason=0,budget_q16=q.budget_q16,deadline_cycles=q.deadline_cycles,
                   admitted_exit=q.fixed_exit,executed_exit=q.fixed_exit,
                   prediction=4,label=4,cycles=101,
                   model_id=q.model_id,build_id=q.build_id,binding_id=0,flags=0)
        self.rx+=encode_response(self.mutate(r) if self.mutate else r)
        return len(buf)
    def read(self,n):
        buf=self.rx[:n];self.rx=self.rx[n:];return buf


def test_transport_request_reply_exact():
    from experiment_driver import Session
    q=Request(seq=1,input_id=2,mode=Mode.FIXED,fixed_exit=2,budget_q16=65535,
              deadline_cycles=0,model_id=0x52544e4e,build_id=2)
    s=Session(FakeSerial())
    result=s.exchange(q)
    assert result['response'].cycles==101
    assert len(s.trace)==1
    assert s.trace[0]['request_hex']==s.transport.out.hex()
    assert s.trace[0]['response_hex'].startswith('52544e52')


def test_transport_rejects_wrong_seq_and_short_read():
    from experiment_driver import Session,DriverError
    q=Request(seq=1,input_id=2,mode=Mode.FIXED,fixed_exit=2,budget_q16=65535,
              deadline_cycles=0,model_id=1,build_id=2)
    bad=FakeSerial(mutate=lambda r:Response(**{**r.__dict__,'seq':99}))
    with pytest.raises(DriverError):Session(bad).exchange(q)
    class Short(FakeSerial):
        def read(self,n):return b''
    with pytest.raises(DriverError):Session(Short()).exchange(q)
