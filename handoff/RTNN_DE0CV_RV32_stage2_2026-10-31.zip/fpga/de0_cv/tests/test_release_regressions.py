"""Real regression cases; synthetic timing is only a validator test fixture."""
import hashlib,json,sys
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from experiment_wire import Request,Response,Mode,Status,encode_request,encode_response
from experiment_matrix import make_matrix
from experiment_audit import audit_trace
from offline_q15_protocol_fixture import EXPECTED_ORACLE_DIGEST

def test_capped_no_stop_accepts_sixth_block_at_full_budget():
    ds=json.loads((ROOT/'generated/heldout360.json').read_text())
    oracle=json.loads((ROOT/'generated/frozen_q15_oracle.json').read_text())
    m=make_matrix(63,1,'fixed');m['experiment']='capped'
    r=dict(seq=1,input_id=0,mode=int(Mode.CAPPED_NO_STOP),fixed_exit=0,budget_q16=65535,deadline_cycles=0)
    m['rows']=[r];m['record_count']=1
    m['schedule_sha256']=hashlib.sha256(json.dumps(m['rows'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
    q=Request(**r,model_id=0x52544e4e,build_id=0x44563032)
    p=oracle['predictions']['0']['predictions'][6]
    a=Response(seq=1,input_id=0,mode=Mode.CAPPED_NO_STOP,status=Status.OK,stop_reason=0,
        budget_q16=65535,deadline_cycles=0,admitted_exit=6,executed_exit=6,prediction=p,
        label=ds['records'][0]['label'],cycles=100,model_id=q.model_id,build_id=q.build_id,binding_id=0,flags=0)
    trace=dict(schema='rtnn-de0cv-experiment-trace-v1',origin='synthetic_fixture',status='SYNTHETIC_NOT_BOARD',
               rows=[dict(request_hex=encode_request(q).hex(),response_hex=encode_response(a).hex())])
    assert audit_trace(trace,m,ds,q15_oracle=oracle,expected_q15_predictions_sha256=EXPECTED_ORACLE_DIGEST)['accepted']==1

def test_failed_uart_reply_preserved_before_decode():
    from experiment_driver import Session,DriverError
    class Bad:
        def write(self,b):return len(b)
        def read(self,n):return b'\xff'*n
    s=Session(Bad())
    q=Request(1,0,Mode.FIXED,2,65535,0,0x52544e4e,0x44563032)
    with pytest.raises(DriverError):s.exchange(q)
    assert s.raw_transactions[0]['response_hex']=='ff'*48
    assert s.raw_transactions[0]['status']=='FAILED'
    assert s.raw_transactions[0]['request_hex']==encode_request(q).hex()
    assert s.trace==[]

def test_partial_uart_reply_preserved_on_timeout():
    from experiment_driver import Session,DriverError
    class Short:
        def __init__(self):self.reads=0
        def write(self,b):return len(b)
        def read(self,n):self.reads+=1;return b'RTNR' if self.reads==1 else b''
    s=Session(Short());q=Request(1,0,Mode.FIXED,2,65535,0,0x52544e4e,0x44563032)
    with pytest.raises(DriverError):s.exchange(q)
    assert s.raw_transactions[0]['response_hex']==b'RTNR'.hex()
    assert s.raw_transactions[0]['status']=='FAILED'
