#!/usr/bin/env python3
"""Fail-closed host structural audit for binary experimental UART captures.

Cannot authenticate a physical FPGA by itself. Q15 equivalence remains PENDING
unless a separately pinned same-model prediction oracle is provided.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from experiment_wire import (Request,Response,Mode,Status,decode_request,decode_response,
                             FrameError)
from verify_q15_oracle import EXPECTED_ACC_COUNTS, EXPECTED_PREFERRED_HIST


class AuditError(ValueError):
    pass


def fail_if(condition: bool, message: str):
    if condition:
        raise AuditError(message)


def load_expected(matrix: dict, dataset: dict) -> tuple[dict,dict]:
    fail_if(matrix.get('schema') != 'rtnn-de0cv-experiment-matrix-v1', 'matrix schema mismatch')
    fail_if(dataset.get('schema') != 'rtnn-de0cv-heldout-digits-v1', 'dataset schema mismatch')
    fail_if(dataset.get('status') != 'INPUTS_ONLY_Q15_PREDICTIONS_PENDING', 'dataset provenance changed')
    d={r['input_id']:r for r in dataset['records']}
    fail_if(len(d)!=360 or len(dataset['records'])!=360, 'heldout dataset must have 360 unique inputs')
    from experiment_dataset import canonical_bytes
    digest=hashlib.sha256(canonical_bytes(dataset['records'])).hexdigest()
    fail_if(dataset.get('dataset_sha256')!=digest, 'dataset tampered since freeze')
    expected={r['seq']:r for r in matrix['rows']}
    fail_if(len(expected)!=len(matrix['rows']) or not expected, 'duplicate or empty schedule')
    fail_if(set(expected)!=set(range(1,len(expected)+1)), 'noncanonical schedule IDs')
    canon=json.dumps(matrix['rows'],sort_keys=True,separators=(',',':')).encode()
    fail_if(hashlib.sha256(canon).hexdigest()!=matrix.get('schedule_sha256'), 'schedule tampered since freeze')
    return expected,d


def verified_oracle(oracle:dict, dataset:dict, expected_sha256:str|None) -> None:
    """An externally pinned digest is mandatory. Self-asserted JSON status is not trust."""
    fail_if(not expected_sha256 or len(expected_sha256)!=64 or
            any(ch not in '0123456789abcdef' for ch in expected_sha256),
            'Q15 oracle requires externally pinned expected SHA-256')
    fail_if(oracle.get('schema')!='rtnn-de0cv-frozen-q15-reference-v1' or
            oracle.get('status')!='Q15_REFERENCE_NATIVE_C_MATCHES_PINNED_CHECKS' or
            oracle.get('dataset_sha256')!=dataset.get('dataset_sha256') or
            oracle.get('record_count')!=360, 'Q15 oracle provenance/status invalid')
    predictions=oracle.get('predictions')
    fail_if(not isinstance(predictions,dict) or set(predictions)!={str(i) for i in range(360)},
            'Q15 oracle missing or duplicate input IDs')
    counts=[0]*7;hist=[0]*7;policy_correct=0
    for i,dat in enumerate(dataset['records']):
        v=predictions[str(i)]
        fail_if(not isinstance(v,dict) or
                set(v)!={'predictions','preferred_exit'} or
                type(v['preferred_exit']) is not int or not 0<=v['preferred_exit']<=5 or
                not isinstance(v['predictions'],list) or len(v['predictions'])!=7 or
                any(type(p) is not int or not 0<=p<=9 for p in v['predictions']),
                'Q15 oracle malformed row')
        hist[v['preferred_exit']]+=1
        for j,p in enumerate(v['predictions']):counts[j]+=int(p==dat['label'])
        policy_correct+=int(v['predictions'][v['preferred_exit']]==dat['label'])
    fail_if(hist!=EXPECTED_PREFERRED_HIST or counts!=EXPECTED_ACC_COUNTS or
            policy_correct!=339, 'Q15 oracle frozen full-domain aggregate mismatch')
    # This digest must be compared with a separately saved result of running
    # pinned native C+weights. A checksum of a fabricated file proves nothing.
    digest=hashlib.sha256(json.dumps(predictions,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    fail_if(digest!=expected_sha256, 'Q15 oracle differs from externally pinned output')


def audit_trace(trace: dict,matrix: dict,dataset: dict, *,
                expected_sof_sha256: str | None=None,
                expected_build_id: int | None=None,
                expected_binding_id: int | None=None,
                q15_oracle: dict | None=None,
                expected_q15_predictions_sha256:str|None=None) -> dict:
    expected, ds=load_expected(matrix,dataset)
    if q15_oracle is not None:
        verified_oracle(q15_oracle,dataset,expected_q15_predictions_sha256)
    fail_if(trace.get('schema')!='rtnn-de0cv-experiment-trace-v1', 'trace schema mismatch')
    origin=trace.get('origin')
    fail_if(origin not in ('synthetic_fixture','fpga_de0cv','rtl_simulation'), 'unrecognized origin')
    valid_status=('SYNTHETIC_NOT_BOARD','CAPTURE_COMPLETE_UNAUDITED') if origin=='synthetic_fixture' else ('CAPTURE_COMPLETE_UNAUDITED',)
    fail_if(trace.get('status') not in valid_status, 'trace status incomplete or invalid')
    if origin=='fpga_de0cv':
        fail_if(not expected_sof_sha256 or expected_build_id is None or expected_binding_id is None,
                'physical capture requires external verified SOF/build/binding identities')
        fail_if(trace.get('sof_sha256')!=expected_sof_sha256,
                'SOF identity mismatch (host metadata is not a device attestation)')
        fail_if(trace.get('capture_transport')!='uart_rx_3v3', 'missing capture transport')
        fail_if(trace.get('dataset_sha256')!=dataset['dataset_sha256'], 'dataset SHA mismatch')
        fail_if(trace.get('schedule_sha256')!=matrix['schedule_sha256'], 'schedule SHA mismatch')
    fail_if(matrix.get('status') not in ('PLANNED_NOT_EXECUTED','PLANNED_WITH_UNVERIFIED_TARGET_BOUNDS'),
            'deadline matrix needs an explicit target timing table before execution')
    deadline_bounds=matrix.get('total_bounds')
    if matrix.get('experiment')=='deadline':
        fail_if(matrix.get('status')!='PLANNED_WITH_UNVERIFIED_TARGET_BOUNDS' or
                matrix.get('bound_status')!='UNVERIFIED_EXPLORATORY_ONLY' or
                not isinstance(deadline_bounds,list) or len(deadline_bounds)!=7 or
                any(type(x) is not int or not 0<x<2**32 for x in deadline_bounds) or
                deadline_bounds!=sorted(deadline_bounds) or
                type(matrix.get('binding_id')) is not int or matrix['binding_id']<=0,
                'deadline bounds and binding not reviewed as exploratory target')
        fail_if(origin=='fpga_de0cv' and expected_binding_id!=matrix['binding_id'],
                'physical deadline binding ID not independently confirmed')
    else:
        fail_if(matrix.get('status')!='PLANNED_NOT_EXECUTED',
                'nondeadline matrix unexpectedly bound to unverified timing')
    rows=trace.get('rows')
    fail_if(not isinstance(rows,list) or len(rows)!=len(expected), 'trace record count mismatch')
    seen=set()
    accepted=0;rejected=0;verified=0
    by_mode={}
    for n,row in enumerate(rows):
        try:
            req=decode_request(bytes.fromhex(row['request_hex']))
            rsp=decode_response(bytes.fromhex(row['response_hex']))
        except (FrameError,ValueError,KeyError,TypeError) as e:
            raise AuditError(f'bad UART frame at row {n}: {e}') from e
        fail_if(req.seq in seen or req.seq not in expected,'duplicate/unknown request sequence')
        seen.add(req.seq)
        wanted=expected[req.seq]
        for key in ('input_id','mode','fixed_exit','budget_q16','deadline_cycles'):
            fail_if(getattr(req,key)!=wanted[key], f'request mismatch for seq={req.seq}: {key}')
        fail_if(req.input_id not in ds, 'input_id missing from frozen dataset')
        fail_if(req.model_id!=rsp.model_id or req.build_id!=rsp.build_id or
                req.seq!=rsp.seq or req.input_id!=rsp.input_id or req.mode!=rsp.mode or
                req.budget_q16!=rsp.budget_q16 or req.deadline_cycles!=rsp.deadline_cycles,
                f'request/response mismatch seq={req.seq}')
        fail_if(rsp.flags!=0, 'hardware fault/cap violation flag nonzero')
        if expected_build_id is not None:
            fail_if(req.build_id!=expected_build_id, 'build ID mismatch')
        if expected_binding_id is not None:
            fail_if(rsp.binding_id!=expected_binding_id, 'binding ID mismatch')
        if req.mode==Mode.DEADLINE_ADAPTIVE:
            fail_if(rsp.binding_id!=matrix['binding_id'], 'wrong deadline binding ID')
            expected_admitted=max((i for i,lim in enumerate(deadline_bounds) if lim<=req.deadline_cycles),default=-1)
        else:
            expected_admitted=None
        if rsp.status==Status.REJECTED:
            fail_if(req.mode != Mode.DEADLINE_ADAPTIVE or expected_admitted!=-1 or
                    rsp.stop_reason!=0, 'unexpected rejection despite fitting deadline')
            rejected+=1
            continue
        fail_if(rsp.status != Status.OK, f'non-OK status seq={req.seq}: {rsp.status}')
        fail_if(rsp.label!=ds[req.input_id]['label'], 'device reports wrong frozen label')
        if req.mode==Mode.FIXED:
            fail_if((rsp.admitted_exit,rsp.executed_exit)!=(req.fixed_exit,req.fixed_exit),
                    'FIXED mode ran wrong number of blocks')
            fail_if(rsp.stop_reason!=0, 'FIXED stop reason invalid')
        elif req.mode in (Mode.ADAPTIVE,Mode.CAPPED_NO_STOP,Mode.DEADLINE_ADAPTIVE):
            maxcap=(req.budget_q16*6)//65535
            if req.mode==Mode.DEADLINE_ADAPTIVE:
                fail_if(rsp.admitted_exit!=expected_admitted,
                        'deadline admitted class disagrees with bound table')
                fail_if(rsp.cycles>req.deadline_cycles,
                        'deadline cycles overrun (preserve raw trace as failure evidence)')
            else:
                fail_if(rsp.admitted_exit!=maxcap, 'admitted class exceeds/misses budget ceiling')
            allowed=min(maxcap,rsp.admitted_exit,6 if req.mode==Mode.CAPPED_NO_STOP else 5)
            fail_if(rsp.executed_exit>allowed, 'budget/deadline/policy cap exceeded')
            if req.mode != Mode.CAPPED_NO_STOP:
                fail_if(rsp.executed_exit>5, 'deployed seed63 policy exceeds max_exit=5')
            if req.mode==Mode.CAPPED_NO_STOP:
                fail_if(rsp.executed_exit!=maxcap, 'NO_STOP did not execute full budget')
                fail_if(rsp.stop_reason!=0, 'NO_STOP stop reason invalid')
            else:
                if rsp.executed_exit<allowed:
                    fail_if(rsp.stop_reason!=1, 'early stop reason inconsistent with execution')
                elif req.mode==Mode.DEADLINE_ADAPTIVE and rsp.admitted_exit<maxcap and allowed==rsp.admitted_exit:
                    fail_if(rsp.stop_reason!=3, 'deadline stop reason missing at cap')
                else:
                    fail_if(rsp.stop_reason!=2, 'budget/policy stop reason inconsistent')
        if q15_oracle is not None:
            exp=q15_oracle['predictions'].get(str(req.input_id))
            fail_if(not exp or len(exp.get('predictions',[]))!=7, 'Q15 reference missing input')
            fail_if(rsp.prediction!=exp['predictions'][rsp.executed_exit], 'Q15 exact prediction mismatch')
            if req.mode in (Mode.ADAPTIVE,Mode.DEADLINE_ADAPTIVE):
                expected_exit=min(exp['preferred_exit'], (req.budget_q16*6)//65535, 5,
                                  rsp.admitted_exit)
                fail_if(rsp.executed_exit!=expected_exit,
                        'Q15 preferred stopping or budget execution mismatch')
            verified+=1
        accepted+=1
        by_mode[str(req.mode.name)]=by_mode.get(str(req.mode.name),0)+1
    fail_if(len(seen)!=len(expected),'trace incomplete')
    status=('HOST_STRUCTURE_AND_Q15_REFERENCE_PASS' if q15_oracle is not None
            else 'HOST_STRUCTURE_PASS_Q15_REFERENCE_PENDING')
    return {'schema':'rtnn-de0cv-experiment-audit-v1','status':status,
            'origin':origin,'record_count':len(rows),'accepted':accepted,
            'rejected':rejected,'q15_predictions_compared':verified,
            'by_mode':by_mode,
            'trace_sha256':hashlib.sha256(json.dumps(trace,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
            'nonclaims':['No proof that a claimed FPGA origin is genuine from host trace alone.',
                         'No hard timing bound can be inferred from observed cycle counts.',
                         'Without an independent Q15 oracle, prediction equivalence is NOT tested.']}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--trace',type=Path,required=True)
    p.add_argument('--matrix',type=Path,required=True)
    p.add_argument('--dataset',type=Path,required=True)
    p.add_argument('--out',type=Path)
    p.add_argument('--q15-oracle',type=Path)
    p.add_argument('--expected-q15-predictions-sha256')
    p.add_argument('--expected-sof-sha256')
    p.add_argument('--expected-build-id',type=lambda x:int(x,0))
    p.add_argument('--expected-binding-id',type=lambda x:int(x,0))
    args=p.parse_args()
    try:
        out=audit_trace(json.loads(args.trace.read_text()),json.loads(args.matrix.read_text()),
                        json.loads(args.dataset.read_text()),
                        q15_oracle=json.loads(args.q15_oracle.read_text()) if args.q15_oracle else None,
                        expected_q15_predictions_sha256=args.expected_q15_predictions_sha256,
                        expected_sof_sha256=args.expected_sof_sha256,
                        expected_build_id=args.expected_build_id,
                        expected_binding_id=args.expected_binding_id)
    except (AuditError,ValueError,KeyError,FrameError) as e:
        p.exit(2,f'EXPERIMENT_AUDIT_FAIL: {e}\n')
    result=json.dumps(out,indent=2)+'\n'
    if args.out:
        args.out.parent.mkdir(parents=True,exist_ok=True)
        args.out.write_text(result)
    print(result,end='')

if __name__=='__main__':main()
