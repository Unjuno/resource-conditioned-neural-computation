#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "$0")/.." && pwd)
cd "$here"
mkdir -p build
python3 tools/frozen_image.py \
  --artifact artifacts/rtnn_ibex_rtl_exact.zip \
  --out-dir quartus > build/preflight_manifest.json
python3 -m pytest -q tests/test_rebuild.py
python3 tools/capture_audit.py \
  --reference quartus/preflight_reference.json \
  --uart-log tests/fixtures/known_good_sim_uart.log \
  --out build/sim_capture_audit.json > /dev/null
python3 tools/empirical_report.py \
  --reference quartus/preflight_reference.json \
  --uart-log tests/fixtures/known_good_sim_uart.log \
  --clock-hz 50000000 --origin sim_reference \
  --out build/sim_observed_not_wcet.json > /dev/null
printf 'HOST_PREFLIGHT=PASS (not FPGA synth/RTL equivalence/board PASS)\n'
