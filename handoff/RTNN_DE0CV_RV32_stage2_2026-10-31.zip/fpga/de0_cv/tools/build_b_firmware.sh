#!/usr/bin/env bash
# Build a NEW B firmware for FPGA experiments. Unlike A, linker/bytes change.
set -euo pipefail
if (($# != 1));then echo 'usage: build_b_firmware.sh /path/to/resource-conditioned-neural-computation' >&2;exit 2;fi
here=$(cd "$(dirname "$0")/.." && pwd)
repo=$(cd "$1" && pwd)
: "${RISCV_PREFIX:=riscv64-unknown-elf-}"
for tool in gcc nm size objcopy; do
  command -v "${RISCV_PREFIX}${tool}" >/dev/null || { echo "BLOCKED missing ${RISCV_PREFIX}${tool}" >&2; exit 2; }
done
[[ -f "$repo/experiments/realtime_nn_real_sequence_fixed_core.c" ]] || { echo 'missing main repository Q15 core' >&2; exit 2; }
[[ "$(git hash-object "$repo/experiments/realtime_nn_real_sequence_fixed_core.c")" == '3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a' ]] || { echo 'refusing changed model core' >&2; exit 2; }
[[ "$(git hash-object "$repo/experiments/realtime_nn_real_sequence_fixed_core.h")" == 'ac185458e21b956db01cb18504bdb507c0c69618' ]] || { echo 'refusing changed model header' >&2; exit 2; }
mkdir -p "$here/build/fpga_b" "$here/generated"
unzip -p "$here/artifacts/rtnn_ibex_rtl_exact.zip" \
  rtnn/realtime_nn_real_sequence_fixed_weights_generated.h \
  > "$here/build/fpga_b/realtime_nn_real_sequence_fixed_weights_generated.h"
[[ "$(sha256sum "$here/build/fpga_b/realtime_nn_real_sequence_fixed_weights_generated.h"|cut -d' ' -f1)" == 961a76b7e220bf2f665e7c04ab62063600aa2e7eccf3403d80ea730bc993ad9f ]] || { echo 'model weight SHA mismatch' >&2; exit 2; }
python3 "$here/tools/experiment_dataset.py" --preflight "$here/quartus/preflight_reference.json" \
 --out "$here/generated/heldout360.json" --c-header "$here/generated/heldout360.h"
"${RISCV_PREFIX}gcc" -O2 -std=c11 -ffreestanding -fno-builtin -fno-pie \
 -march=rv32im_zicsr -mabi=ilp32 -nostdlib -nostartfiles -nodefaultlibs \
 -I"$repo/experiments" -I"$here/generated" -I"$here/build/fpga_b" -I"$here/firmware" \
 -Wl,-T,"$here/firmware/rtnn_experiment.ld" \
 "$here/firmware/rtnn_experiment_start.S" \
 "$repo/experiments/realtime_nn_real_sequence_fixed_core.c" \
 "$here/firmware/rtnn_experiment_wire.c" "$here/firmware/rtnn_experiment_runner.c" \
 "$here/firmware/rtnn_board_main.c" -lgcc -o "$here/build/fpga_b/rtnn_experiment.elf"
[[ -z "$("${RISCV_PREFIX}nm" -u "$here/build/fpga_b/rtnn_experiment.elf")" ]] || { echo 'undefined symbols remain' >&2;exit 2; }
"${RISCV_PREFIX}size" "$here/build/fpga_b/rtnn_experiment.elf"
"${RISCV_PREFIX}objcopy" -O binary "$here/build/fpga_b/rtnn_experiment.elf" "$here/build/fpga_b/rtnn_experiment.bin"
python3 "$here/tools/build_b_image.py" --elf "$here/build/fpga_b/rtnn_experiment.elf" \
 --bin "$here/build/fpga_b/rtnn_experiment.bin" --out-dir "$here/build/fpga_b"
echo 'B_FIRMWARE_BUILT_UNVERIFIED_ON_FPGA (deadline binding disabled)'
