#!/usr/bin/env python3
"""Synthetic 720-frame transport smoke test. NEVER a board/ML performance test."""
from __future__ import annotations
import json
from pathlib import Path
from experiment_dataset import generate_heldout
from experiment_matrix import make_matrix
from experiment_wire import (decode_request,encode_response,Mode,Status,Response)
from experiment_driver import Session
from experiment_report import paired_report

class ScriptedTransport:
    def __init__(self,ds):self.ds=ds;self.pending=b''
    def write(self,data):
        q=decode_request(data)
        if self.pending:raise RuntimeError('unsolicited overlapping command')
        n=q.fixed_exit if q.mode==Mode.FIXED else 1
        pred=self.ds['records'][q.input_id]['label']
        r=Response(seq=q.seq,input_id=q.input_id,mode=q.mode,status=Status.OK,
                   stop_reason=0 if q.mode==Mode.FIXED else 1,
                   budget_q16=q.budget_q16,deadline_cycles=q.deadline_cycles,
                   admitted_exit=q.fixed_exit if q.mode==Mode.FIXED else 6,
                   executed_exit=n,prediction=pred,label=pred,
                   cycles=1200 if q.mode==Mode.FIXED else 800,
                   model_id=q.model_id,build_id=q.build_id,binding_id=0,flags=0)
        self.pending=encode_response(r)
        return len(data)
    def read(self,n):
        b=self.pending[:n];self.pending=self.pending[n:];return b


def selftest(root:Path,outdir:Path):
    ds=generate_heldout(json.loads((root/'quartus/preflight_reference.json').read_text()))
    matrix=make_matrix(seed=63,count=360,which='paired')
    session=Session(ScriptedTransport(ds))
    from experiment_wire import Request
    for row in matrix['rows']:
        q=Request(seq=row['seq'],input_id=row['input_id'],mode=Mode(row['mode']),
                  fixed_exit=row['fixed_exit'],budget_q16=row['budget_q16'],
                  deadline_cycles=row['deadline_cycles'],model_id=0x52544e4e,
                  build_id=0x44563032)
        session.exchange(q)
    trace={'schema':'rtnn-de0cv-experiment-trace-v1',
           'origin':'synthetic_fixture',
           'status':'SYNTHETIC_NOT_BOARD','rows':session.trace}
    report=paired_report(trace,matrix,ds)
    outdir.mkdir(parents=True,exist_ok=True)
    (outdir/'synthetic_trace.json').write_text(json.dumps(trace,indent=2)+'\n')
    (outdir/'synthetic_matrix.json').write_text(json.dumps(matrix,indent=2)+'\n')
    (outdir/'synthetic_report.json').write_text(json.dumps(report,indent=2)+'\n')
    return {'trace_status':'SYNTHETIC_NOT_BOARD','record_count':len(session.trace),'report':report}

if __name__=='__main__':
    here=Path(__file__).resolve().parents[1]
    r=selftest(here,here/'build/selftest_v2')
    print(r['trace_status'],r['record_count'],r['report']['status'])
