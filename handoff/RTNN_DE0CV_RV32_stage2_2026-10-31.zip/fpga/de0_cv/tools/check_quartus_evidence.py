#!/usr/bin/env python3
"""Record physical reports as immutable evidence; NEVER infer PASS from text.

The Fitter/STA must be reviewed manually or validated against trusted data
fields by a separate exact-version parser. This tool only binds report bytes.
"""
import argparse,hashlib,json
from pathlib import Path

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    a=argparse.ArgumentParser(description=__doc__)
    for p in ('sof','fit_report','sta_report','ram_hex','source_flat','uart_log'):
        a.add_argument('--'+p.replace('_','-'),required=True,type=Path)
    a.add_argument('--quartus-version',required=True)
    a.add_argument('--out',required=True,type=Path)
    o=a.parse_args()
    if not o.quartus_version.strip(): a.error('blank quartus version')
    artifacts={}
    for name in ('sof','fit_report','sta_report','ram_hex','source_flat','uart_log'):
        path=getattr(o,name)
        if not path.is_file() or path.stat().st_size==0: a.error(f'empty or missing {name}')
        artifacts[name]={'size_bytes':path.stat().st_size, 'sha256':sha(path)}
    record={'schema':'rtnn-fpga-build-evidence-v1','status':'RECORD_ONLY_NOT_CERTIFIED',
            'quartus_version_reported_by_operator':o.quartus_version,
            'files':artifacts,'machine_verified_sta_closed':False,
            'memory_primitive_mapping_verified':False,'board_identity_verified':False,
            'production_wcets':None}
    o.out.parent.mkdir(parents=True,exist_ok=True)
    o.out.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))
if __name__=='__main__': main()
