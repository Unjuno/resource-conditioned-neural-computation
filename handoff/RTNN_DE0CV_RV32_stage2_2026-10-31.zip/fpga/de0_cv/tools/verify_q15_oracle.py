#!/usr/bin/env python3
"""Check the REAL frozen-Q15 native inference CSV against pinned RTNN evidence.

Only actual C model outputs can complete the oracle. This script cannot
synthesize predictions from labels, training seed, or old float results.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path

class OracleError(ValueError):pass

EXPECTED_COLUMNS=['input_id','label','preferred_exit']+[f'exit{i}' for i in range(7)]
EXPECTED_ACC_COUNTS=[171,328,339,338,336,336,333]
EXPECTED_PREFERRED_HIST=[0,263,81,7,2,7,0]


def verify_csv(text:str,dataset:dict,preflight:dict,*,check_known_aggregate:bool=True)->dict:
    if dataset.get('schema')!='rtnn-de0cv-heldout-digits-v1' or len(dataset.get('records',[]))!=360:
        raise OracleError('dataset missing or not frozen 360 inputs')
    if preflight.get('schema')!='rtnn-de0-cv-preflight-v1':
        raise OracleError('wrong pinned preflight reference')
    rows=list(csv.reader(io.StringIO(text)))
    if not rows or rows[0]!=EXPECTED_COLUMNS or len(rows)!=361:
        raise OracleError('wrong CSV header or row count')
    oracle={};hist=[0]*7;counts=[0]*7;correct_policy=0
    for row_index,line in enumerate(rows[1:]):
        if len(line)!=10 or any(not x.isascii() or not x.isdecimal() for x in line):
            raise OracleError(f'invalid CSV row {row_index}')
        r=[int(x) for x in line]
        iid,label,pref,*preds=r
        expected=dataset['records'][row_index]
        if iid!=row_index or label!=expected['label'] or not 0<=pref<=5 or any(not 0<=p<=9 for p in preds):
            raise OracleError(f'bad row/index/label/prediction {row_index}')
        for v in preflight['vectors']:
            if v['test_index']==iid and (preds!=v['expected_fixed_class_prediction'] or pref!=v['preferred_exit']):
                raise OracleError(f'mismatch with pinned RTL reference at test index {iid}')
        hist[pref]+=1
        for j,p in enumerate(preds):counts[j]+=p==label
        correct_policy+=preds[pref]==label
        oracle[str(iid)]={'predictions':preds,'preferred_exit':pref}
    if check_known_aggregate and (hist!=EXPECTED_PREFERRED_HIST or
                                  counts!=EXPECTED_ACC_COUNTS or correct_policy!=339):
        raise OracleError('frozen seed63 Q15 aggregate mismatch; do not certify')
    return {'schema':'rtnn-de0cv-frozen-q15-reference-v1',
            'status':'Q15_REFERENCE_NATIVE_C_MATCHES_PINNED_CHECKS' if check_known_aggregate else 'TEST_FIXTURE_ONLY',
            'dataset_sha256':dataset['dataset_sha256'],
            'raw_csv_sha256':hashlib.sha256(text.encode('ascii')).hexdigest(),
            'record_count':360,'accuracy_correct_by_exit':counts,
            'policy_correct':correct_policy,'preferred_histogram':hist,
            'predictions':oracle,
            'nonclaim':'This verifies exact decisions for this held-out set, not all possible inputs.'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--csv',type=Path,required=True)
    p.add_argument('--dataset',type=Path,required=True)
    p.add_argument('--preflight',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    try:
        result=verify_csv(a.csv.read_text(),json.loads(a.dataset.read_text()),
                          json.loads(a.preflight.read_text()))
    except (OracleError,ValueError) as e:p.exit(2,f'Q15_ORACLE_FAIL: {e}\n')
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(result,indent=2)+'\n')
    print(result['status'],result['raw_csv_sha256'])

if __name__=='__main__':main()
