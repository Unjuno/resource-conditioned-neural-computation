#!/usr/bin/env python3
"""Stop-and-wait UART experiment driver; bytes and identity are recorded.

Serial timeouts/partial outputs abort. No implicit replay or retry: a retry
could perform NN work twice and corrupt comparisons.
"""
from __future__ import annotations
import argparse
import json
import hashlib
from pathlib import Path
from experiment_wire import (Request, Response,Mode,Status,
                             encode_request,decode_response,FrameError,RESPONSE)

class DriverError(RuntimeError):
    pass


def validate_run_plan(matrix:dict, *, allow_exploratory_deadline:bool=False) -> dict:
    """Require an explicit opt-in before running an unverified target timing table.

    Exploratory admission is an empirical experiment, NOT a WCET certificate.
    """
    if matrix.get('experiment')=='deadline':
        if matrix.get('status')!='PLANNED_WITH_UNVERIFIED_TARGET_BOUNDS':
            raise DriverError('no explicit FPGA deadline table; cannot run deadline experiment')
        if not allow_exploratory_deadline:
            raise DriverError('deadline table unverified; pass explicit exploratory opt-in')
        if (matrix.get('bound_status')!='UNVERIFIED_EXPLORATORY_ONLY' or
            not isinstance(matrix.get('total_bounds'),list) or
            len(matrix['total_bounds'])!=7 or
            any(type(x) is not int or x<=0 for x in matrix['total_bounds']) or
            matrix['total_bounds']!=sorted(matrix['total_bounds']) or
            type(matrix.get('binding_id')) is not int or matrix['binding_id']<=0):
            raise DriverError('invalid exploratory FPGA deadline table')
        return {'claim_scope':'EMPIRICAL_EXPLORATORY_ONLY'}
    if matrix.get('status')!='PLANNED_NOT_EXECUTED':
        raise DriverError('matrix unresolved or timing bounds unaudited')
    return {'claim_scope':'FIXED_OR_ADAPTIVE_NO_TIMING_CERTIFICATION'}

class Session:
    def __init__(self, transport, journal=None):
        self.transport=transport
        self.trace=[]
        self.raw_transactions=[]
        self.journal=journal

    def exchange(self,request:Request) -> dict:
        from datetime import datetime, timezone
        frame=encode_request(request)
        response=b''
        event={'request_hex':frame.hex(),'response_hex':'','status':'FAILED',
               'host_utc_started':datetime.now(timezone.utc).isoformat()}
        try:
            if self.transport.write(frame)!=len(frame):
                raise DriverError('short UART write; transaction aborted')
            while len(response)<RESPONSE.size:
                chunk=self.transport.read(RESPONSE.size-len(response))
                if not chunk:
                    raise DriverError('timeout/truncated response (no automatic replay)')
                response+=chunk
            try:rsp=decode_response(response)
            except FrameError as e:raise DriverError(f'invalid board reply: {e}') from e
            if (rsp.seq!=request.seq or rsp.input_id!=request.input_id or
                rsp.mode!=request.mode or rsp.budget_q16!=request.budget_q16 or
                rsp.deadline_cycles!=request.deadline_cycles or
                rsp.model_id!=request.model_id or rsp.build_id!=request.build_id):
                raise DriverError('board response does not match request/expected identities')
            result={'request_hex':frame.hex(),'response_hex':response.hex()}
            self.trace.append(result)
            event['status']='DECODED_IDENTITY_MATCHED'
            return {'response':rsp,'raw':result}
        except Exception as e:
            event['error']=str(e)
            raise
        finally:
            event['response_hex']=response.hex()
            event['host_utc_finished']=datetime.now(timezone.utc).isoformat()
            self.raw_transactions.append(event)
            if self.journal is not None:
                self.journal(event)


def run(matrix:dict,dataset:dict,port:str,baud:int,timeout:float,
        model_id:int,build_id:int,sof:Path,out:Path,
        allow_exploratory_deadline:bool=False):
    from experiment_audit import load_expected
    from experiment_wire import FrameError
    load_expected(matrix,dataset)
    scope=validate_run_plan(matrix,allow_exploratory_deadline=allow_exploratory_deadline)
    if not sof.is_file():
        raise DriverError('real SOF file required; do not supply a guessed hash')
    if baud<=0 or timeout<=0:
        raise DriverError('invalid UART parameters')
    try:import serial
    except ImportError as e:raise DriverError('pyserial required on physical host') from e
    sofdigest=hashlib.sha256(sof.read_bytes()).hexdigest()
    trace={'schema':'rtnn-de0cv-experiment-trace-v1','origin':'fpga_de0cv',
           'capture_transport':'uart_rx_3v3','sof_sha256':sofdigest,
           'dataset_sha256':dataset['dataset_sha256'],
           'schedule_sha256':matrix['schedule_sha256'],
           'claim_scope':scope['claim_scope'],
           'status':'INCOMPLETE','rows':[]}
    out.parent.mkdir(parents=True,exist_ok=True)
    with serial.Serial(port=port,baudrate=baud,timeout=timeout,write_timeout=timeout) as con:
        session=Session(con)
        try:
            for row in matrix['rows']:
                req=Request(seq=row['seq'],input_id=row['input_id'],
                            mode=Mode(row['mode']),fixed_exit=row['fixed_exit'],
                            budget_q16=row['budget_q16'],deadline_cycles=row['deadline_cycles'],
                            model_id=model_id,build_id=build_id)
                res=session.exchange(req)['response']
                if res.status==Status.REJECTED and matrix.get('experiment')=='deadline':
                    # Rejected requests are valid observations. Preserve them;
                    # the strict auditor checks that no class fits the deadline.
                    pass
                elif res.status!=Status.OK:
                    raise DriverError(f'board declined seq={req.seq} status={res.status}')
                trace['rows']=session.trace
            trace['status']='CAPTURE_COMPLETE_UNAUDITED'
        finally:
            trace['rows']=session.trace
            trace['raw_transactions']=session.raw_transactions
            out.write_text(json.dumps(trace,indent=2)+'\n')
    return trace


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--matrix',type=Path,required=True)
    p.add_argument('--dataset',type=Path,required=True)
    p.add_argument('--port',required=True)
    p.add_argument('--baud',type=int,default=115200)
    p.add_argument('--timeout',type=float,default=3.0)
    p.add_argument('--model-id',type=lambda s:int(s,0),required=True)
    p.add_argument('--build-id',type=lambda s:int(s,0),required=True)
    p.add_argument('--sof',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--allow-exploratory-deadline',action='store_true',
                   help='explicit opt-in; data may NEVER be called hard-RT/WCET')
    args=p.parse_args()
    try:
        r=run(json.loads(args.matrix.read_text()),json.loads(args.dataset.read_text()),
              args.port,args.baud,args.timeout,args.model_id,args.build_id,args.sof,args.out,
              allow_exploratory_deadline=args.allow_exploratory_deadline)
        print('CAPTURE_COMPLETE_UNAUDITED',len(r['rows']))
    except (DriverError,FrameError,ValueError,KeyError) as e:p.exit(2,f'DRIVER_ABORTED: {e}\n')

if __name__=='__main__':main()
