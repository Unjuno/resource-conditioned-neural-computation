#!/usr/bin/env python3
"""Native actual-Q15 firmware functional regression. NEVER FPGA timing data."""
from __future__ import annotations
import csv
import hashlib
import json
import subprocess
from pathlib import Path

CORE_SHA='3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a'
HEADER_SHA='ac185458e21b956db01cb18504bdb507c0c69618'
WEIGHTS_SHA='961a76b7e220bf2f665e7c04ab62063600aa2e7eccf3403d80ea730bc993ad9f'
PINNED_PREDICTIONS_SHA='03eb958cfa8b4fd2f71a95fb47dbca512820c237c281473817bba685b92c743e'

class GateFailure(RuntimeError):pass


def sha(path:Path):return hashlib.sha256(path.read_bytes()).hexdigest()


def run_gate(root:Path,out:Path)->dict:
    core=root/'upstream/source_repo/experiments/realtime_nn_real_sequence_fixed_core.c'
    head=core.with_suffix('.h')
    frozen_head=root/'build/q15/realtime_nn_real_sequence_fixed_weights_generated.h'
    source_oracle=root/'generated/frozen_q15_oracle.json'
    if subprocess.check_output(['git','hash-object',str(core)],text=True).strip()!=CORE_SHA:
        raise GateFailure('upstream Q15 C source git blob changed')
    if subprocess.check_output(['git','hash-object',str(head)],text=True).strip()!=HEADER_SHA:
        raise GateFailure('upstream Q15 header git blob changed')
    if sha(frozen_head)!=WEIGHTS_SHA:raise GateFailure('Q15 frozen weights changed')
    oracle=json.loads(source_oracle.read_text())
    digest=hashlib.sha256(json.dumps(oracle['predictions'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
    if digest!=PINNED_PREDICTIONS_SHA:raise GateFailure('native Q15 oracle differs from independently pinned digest')
    out.mkdir(parents=True,exist_ok=True)
    binary=out/'host_actual_q15_firmware'
    build=['gcc','-O2','-std=c11','-Wall','-Wextra',
           '-I'+str(root/'firmware'),'-I'+str(root/'generated'),
           '-I'+str(core.parent),'-I'+str(frozen_head.parent),
           str(core),str(root/'firmware/rtnn_experiment_runner.c'),
           str(root/'tests/fixtures/native_q15_fw_e2e.c'),'-o',str(binary)]
    compile=subprocess.run(build,capture_output=True,text=True,timeout=60)
    if compile.returncode!=0:raise GateFailure('native GCC failed: '+compile.stderr)
    run=subprocess.run([str(binary)],capture_output=True,text=True,timeout=160)
    if run.returncode!=0:raise GateFailure('native Q15 firmware failed: '+run.stderr)
    (out/'host_actual_q15_firmware.csv').write_text(run.stdout)
    rows=list(csv.DictReader(run.stdout.splitlines()))
    fixed=0;adaptive=0;pred_mm=0;exec_mm=0;reason_mm=0;cap_bad=0;status_bad=0
    from experiment_matrix import make_matrix
    budgets=sorted({r['budget_q16'] for r in make_matrix(63,360,'adaptive')['rows']})
    for row in rows:
        iid=int(row['input_id']);mode=int(row['mode']);param=int(row['param'])
        admitted=int(row['admitted_exit']);e=int(row['executed_exit']);pred=int(row['prediction'])
        reason=int(row['stop_reason']);status=int(row['status']);flags=int(row['flags'])
        ref=oracle['predictions'][str(iid)]
        if mode==1:
            fixed+=1;want_e=param;want_admitted=param;want_reason=0
        elif mode==3:
            adaptive+=1;b=budgets[param];want_admitted=(b*6)//65535
            want_e=min(ref['preferred_exit'],want_admitted,5)
            want_reason=1 if want_e<min(want_admitted,5) else 2
        else:raise GateFailure('unexpected mode')
        pred_mm+=int(pred!=ref['predictions'][want_e]);exec_mm+=int(e!=want_e)
        reason_mm+=int(reason!=want_reason);cap_bad+=int(admitted!=want_admitted or e>min(want_admitted,5 if mode==3 else 6))
        status_bad+=int(status!=0 or flags!=0)
    verdict={'status':'NATIVE_Q15_FIRMWARE_MATCHES_PINNED_MODEL' if all(x==0 for x in (pred_mm,exec_mm,reason_mm,cap_bad,status_bad)) and fixed==2520 and adaptive==7560 else 'FAIL',
             'fixed_cases':fixed,'adaptive_cases':adaptive,'prediction_mismatches':pred_mm,
             'executed_exit_mismatches':exec_mm,'stop_reason_mismatches':reason_mm,
             'budget_cap_violations':cap_bad,'status_errors':status_bad,
             'q15_predictions_sha256':digest,'host_csv_sha256':hashlib.sha256(run.stdout.encode()).hexdigest(),
             'real_fpga_claimed':False,'timing_claim':'FORBIDDEN: native fake clock callback'}
    (out/'native_firmware_verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
    if verdict['status']=='FAIL':raise GateFailure('native Q15 firmware mismatches: '+json.dumps(verdict))
    return verdict

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'build/native_q15_fw')
    a=p.parse_args();print(json.dumps(run_gate(a.root,a.out),indent=2))
