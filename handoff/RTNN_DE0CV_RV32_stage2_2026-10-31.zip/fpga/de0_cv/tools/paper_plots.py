#!/usr/bin/env python3
"""Generate figures from the audited PHYSICAL results export; no dummy figures.

This is a presentation tool, not hardware attestation or a WCET proof. Do not
manually fabricate the required report status; obtain it with paper_results.py.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,statistics
from pathlib import Path
from collections import defaultdict

def render(report_file:Path,out:Path)->list[Path]:
    r=json.loads(report_file.read_text())
    if r.get('status')!='PHYSICAL_RECORDS_AUDITED_OPERATOR_REVIEWED':
        raise ValueError('unmeasured/synthetic/unaudited report cannot generate paper figures')
    if out.exists():raise ValueError('figure destination exists; refusing overwrite')
    pairs_file=report_file.parent/'paired_by_input_session.csv'
    if not pairs_file.is_file() or not r.get('secondary') or not r.get('primary'):
        raise ValueError('incomplete results export')
    for name,sha in r.get('derived_file_sha256',{}).items():
        p=report_file.parent/name
        if p.parent.resolve()!=report_file.parent.resolve() or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=sha:
            raise ValueError('derived table hash changed: '+name)
    if 'paired_by_input_session.csv' not in r.get('derived_file_sha256',{}):
        raise ValueError('missing derived table hash')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    out.mkdir(parents=True);created=[]
    def save(fig,name):
        fig.tight_layout()
        for ext in ('png','svg'):
            p=out/f'{name}.{ext}';fig.savefig(p,dpi=180);created.append(p)
        plt.close(fig)
    rows=r['secondary']
    fig,ax=plt.subplots(figsize=(7.2,4.8))
    for mode,label in [('FIXED','Fixed exits'),('CAPPED_NO_STOP','Budget cap only'),('ADAPTIVE','Adaptive stopping')]:
        group=sorted([x for x in rows if x['mode']==mode],key=lambda x:x['control'])
        ax.plot([x['mean_cycles'] for x in group],[100*x['accuracy'] for x in group],marker='o',label=label)
    ax.set_xlabel('Mean measured processor cycles / request');ax.set_ylabel('Benchmark accuracy (%)')
    ax.set_title('Same-model accuracy / observed cycle trade-off');ax.legend();ax.grid(True,alpha=.3)
    save(fig,'figure1_accuracy_cycles')
    fig,ax=plt.subplots(figsize=(7.2,4.8))
    for mode,label in [('CAPPED_NO_STOP','Cap only'),('ADAPTIVE','Adaptive')]:
        group=sorted([x for x in rows if x['mode']==mode],key=lambda x:x['control'])
        ax.plot([100*x['control']/65535 for x in group],[x['mean_executed_blocks'] for x in group],marker='o',label=label)
    ax.set_xlabel('External compute budget (%)');ax.set_ylabel('Mean executed optional blocks')
    ax.set_title('Physical work count vs budget');ax.legend();ax.grid(True,alpha=.3)
    save(fig,'figure2_budget_work')
    grouped=defaultdict(list)
    for row in csv.DictReader(pairs_file.open()):grouped[int(row['input_id'])].append(row)
    f=[statistics.mean(int(v['fixed2_cycles']) for v in grouped[i]) for i in sorted(grouped)]
    a=[statistics.mean(int(v['adaptive_cycles']) for v in grouped[i]) for i in sorted(grouped)]
    fig,ax=plt.subplots(figsize=(6.4,5.2));ax.scatter(f,a,alpha=.5)
    lo=min(f+a);hi=max(f+a);ax.plot([lo,hi],[lo,hi],linestyle='--',label='Equal cycles')
    ax.set_xlabel('Fixed exit 2: session-mean cycles');ax.set_ylabel('Adaptive: session-mean cycles')
    ax.set_title('Paired inputs; below line is faster adaptive execution');ax.legend();ax.grid(True,alpha=.3)
    save(fig,'figure3_paired_cycles')
    bs=r['primary']['boot_session_summaries']
    fig,ax=plt.subplots(figsize=(7.2,4.8));ax.plot(range(1,len(bs)+1),[x['mean_cycle_saving'] for x in bs],marker='o')
    ax.axhline(0,linestyle='--');ax.set_xlabel('Independent cold-boot session');ax.set_ylabel('Mean fixed2 minus adaptive cycles')
    ax.set_title('Session sensitivity (not additional accuracy samples)');ax.grid(True,alpha=.3)
    save(fig,'figure4_boot_sensitivity')
    (out/'figure_sources.json').write_text(json.dumps({'results_sha256':hashlib.sha256(report_file.read_bytes()).hexdigest(),
      'paired_csv_sha256':hashlib.sha256(pairs_file.read_bytes()).hexdigest(),
      'scope':'OBSERVED_PHYSICAL_CASE_STUDY_NOT_WCET','matplotlib_version':matplotlib.__version__},indent=2)+'\n')
    return created

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--report',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    try:created=render(a.report,a.out)
    except (ValueError,KeyError,OSError) as e:p.exit(2,f'FIGURE_GENERATION_BLOCKED: {e}\n')
    print('FIGURES_FROM_AUDITED_PHYSICAL_REPORT',len(created))
if __name__=='__main__':main()
