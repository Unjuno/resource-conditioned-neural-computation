#!/usr/bin/env bash
# Controlled conversion gateway, NOT an assertion of equivalent RTL.
set -euo pipefail
usage() { echo "usage: IBEX_ROOT=<pinned ibex checkout> IBEX_SOURCE_LIST=<ordered .sv/.v list> $0" >&2; exit 2; }
: "${IBEX_ROOT:?set IBEX_ROOT to the pinned upstream clone}"
: "${IBEX_SOURCE_LIST:?set IBEX_SOURCE_LIST to an ordered, explicitly reviewed source list}"
command -v sv2v >/dev/null || { echo 'sv2v absent' >&2; exit 2; }
command -v git >/dev/null || exit 2
want=7b5df75a041affe56e8c235260f98a09b3319008
actual=$(git -C "$IBEX_ROOT" rev-parse HEAD)
[[ "$actual" == "$want" ]] || { echo "IBEX commit mismatch: $actual" >&2; exit 2; }
[[ -f "$IBEX_SOURCE_LIST" ]] || usage
here=$(cd "$(dirname "$0")/.." && pwd)
output="$here/quartus/ibex_flat.v"
files=()
while IFS= read -r source || [[ -n "$source" ]]; do
  [[ -z "$source" || "$source" == \#* ]] && continue
  if [[ "$source" == /* ]]; then f="$source"; else f="$IBEX_ROOT/$source"; fi
  [[ -f "$f" ]] || { echo "missing Ibex source $f" >&2; exit 2; }
  [[ "$f" == *.sv || "$f" == *.v ]] || { echo "not RTL source: $f" >&2; exit 2; }
  files+=("$f")
done < "$IBEX_SOURCE_LIST"
((${#files[@]} > 0)) || { echo 'empty source list' >&2; exit 2; }
# Package ordering must come from an audited FuseSoC/EDAM list. We append
# our SoC sources so imported ibex/prim packages precede their use.
files+=("$here/rtl/rtnn_uart_tx.sv" "$here/rtl/rtnn_uart_rx.sv" "$here/rtl/rtnn_de0_cv_ram.sv" \
        "$here/rtl/rtnn_de0_cv_soc.sv" "$here/rtl/rtnn_de0_cv_top.sv")
tmp=$(mktemp)
trap 'rm -f "$tmp"' EXIT
sv2v --define=SYNTHESIS \
  -I"$IBEX_ROOT/rtl" \
  -I"$IBEX_ROOT/vendor/lowrisc_ip/ip/prim/rtl" \
  -I"$IBEX_ROOT/vendor/lowrisc_ip/ip/prim_generic/rtl" \
  "${files[@]}" > "$tmp"
[[ -s "$tmp" ]] || { echo 'empty sv2v output' >&2; exit 2; }
cp "$tmp" "$output"
sha256sum "$output" | tee "$here/quartus/ibex_flat.sha256"
echo 'NOTE: CONVERTED_ONLY; must run independent equivalence test and Quartus Fitter.' >&2
