#!/usr/bin/env python3
"""Freeze the *existing* sklearn digits held-out split; do not retrain RTNN.

The generated input dataset is not an independent Q15 prediction oracle.
Every output records its provenance and refuses split changes that would
invalidate the three pinned Simple-System reference inputs.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path


def canonical_bytes(records: list[dict]) -> bytes:
    return json.dumps(records,sort_keys=True,separators=(',',':')).encode('ascii')


def generate_heldout(preflight: dict) -> dict:
    import numpy as np
    import sklearn
    from sklearn.datasets import load_digits
    from sklearn.model_selection import train_test_split
    assert preflight['schema'] == 'rtnn-de0-cv-preflight-v1'
    x = load_digits()
    inputs=np.asarray(x.images)
    labels=np.asarray(x.target)
    if len(inputs)!=1797 or inputs.shape[1:]!=(8,8):
        raise ValueError('unexpected sklearn digits dataset')
    indices=list(range(len(inputs)))
    train,tmp=train_test_split(indices,test_size=.4,random_state=123,stratify=labels)
    valid,test=train_test_split(tmp,test_size=.5,random_state=456,stratify=labels[tmp])
    if (len(train),len(valid),len(test)) != (1078,359,360):
        raise ValueError('unexpected split sizes')
    rows=[]
    for i,k in enumerate(test):
        v=inputs[k].flatten()
        if not np.all((v>=0)&(v<=16)&(v==v.astype('uint8'))):
            raise ValueError('image not 8-bit integers in 0..16')
        rows.append({'input_id':i,'source_index':int(k),'pixels_u8_64':[int(z) for z in v],
                     'label':int(labels[k])})
    for v in preflight['vectors']:
        r=rows[v['test_index']]
        if r['pixels_u8_64'] != v['input_u8_64'] or r['label'] != v['label']:
            raise ValueError('pinned RTL input mismatch: dataset or sklearn split changed')
    return {'schema':'rtnn-de0cv-heldout-digits-v1',
            'status':'INPUTS_ONLY_Q15_PREDICTIONS_PENDING',
            'source':'sklearn.datasets.load_digits',
            'split':'stratified train_test_split 123 then 456 (60/20/20)',
            'sklearn_version':sklearn.__version__,
            'dataset_sha256':hashlib.sha256(canonical_bytes(rows)).hexdigest(),
            'record_count':len(rows), 'records':rows,
            'nonclaim':'Input and labels are pinned; predictions for all 360 must be checked against the frozen Q15 model before E2/E3 are labeled PASS.'}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--preflight',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--c-header',type=Path)
    opts=ap.parse_args()
    result=generate_heldout(json.loads(opts.preflight.read_text()))
    opts.out.parent.mkdir(parents=True,exist_ok=True)
    opts.out.write_text(json.dumps(result,indent=2)+'\n')
    if opts.c_header:
        rows=result['records']
        lines=['/* Auto-generated held-out inputs; NOT an independent prediction oracle. */',
               '#ifndef RTNN_DIGITS_HELDOUT_GENERATED_H',
               '#define RTNN_DIGITS_HELDOUT_GENERATED_H', '#include <stdint.h>',
               '#define RTNN_TEST_COUNT 360u',
               'static const uint8_t rtnn_test_pixels[360][64] = {']
        for r in rows:
            lines.append('  {'+','.join(map(str,r['pixels_u8_64']))+'},')
        lines.extend(['};', 'static const uint8_t rtnn_test_labels[360] = {',
                      ','.join(str(r['label']) for r in rows),
                      '};', '#endif'])
        opts.c_header.parent.mkdir(parents=True,exist_ok=True)
        opts.c_header.write_text('\n'.join(lines)+'\n')
    print(json.dumps({'status':result['status'],'rows':len(result['records']),
                      'dataset_sha256':result['dataset_sha256']},indent=2))

if __name__=='__main__':main()
