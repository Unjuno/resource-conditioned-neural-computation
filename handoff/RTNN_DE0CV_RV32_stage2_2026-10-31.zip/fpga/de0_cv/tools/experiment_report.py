#!/usr/bin/env python3
"""Primary E4: same-input fixed-2 vs adaptive RTNN cycle comparison.

A report cannot be built without a structurally complete audited capture.
Synthetic traces are always tagged; observations are never called WCET.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from experiment_audit import audit_trace,AuditError
from experiment_wire import Mode,decode_request,decode_response
from experiment_analysis import paired_metrics


def paired_report(trace:dict,matrix:dict,dataset:dict, *,q15_oracle:dict|None=None,
                  expected_sof_sha256:str|None=None,
                  expected_build_id:int|None=None,expected_binding_id:int|None=None,
                  expected_q15_predictions_sha256:str|None=None)->dict:
    if matrix.get('experiment')!='paired':
        raise AuditError('only paired fixed2/adaptive experiment may make E4 report')
    audit=audit_trace(trace,matrix,dataset,q15_oracle=q15_oracle,
                      expected_sof_sha256=expected_sof_sha256,
                      expected_build_id=expected_build_id,
                      expected_binding_id=expected_binding_id,
                      expected_q15_predictions_sha256=expected_q15_predictions_sha256)
    pairs={}
    for r in trace['rows']:
        req=decode_request(bytes.fromhex(r['request_hex']))
        rsp=decode_response(bytes.fromhex(r['response_hex']))
        assert rsp.status==0
        sub=pairs.setdefault(req.input_id,{})
        key='fixed2' if req.mode==Mode.FIXED and req.fixed_exit==2 else 'adaptive'
        if key in sub:raise AuditError('duplicate paired experiment mode')
        sub[key]=rsp
    rows=[]
    ds={v['input_id']:v for v in dataset['records']}
    for iid,parts in sorted(pairs.items()):
        if set(parts)!={'fixed2','adaptive'}:raise AuditError('paired input missing a comparison mode')
        label=ds[iid]['label']
        rows.append({'input_id':iid,'fixed2_cycles':parts['fixed2'].cycles,
                     'adaptive_cycles':parts['adaptive'].cycles,
                     'fixed2_correct':int(parts['fixed2'].prediction==label),
                     'adaptive_correct':int(parts['adaptive'].prediction==label)})
    observed=paired_metrics(rows)
    return {'schema':'rtnn-de0cv-e4-paired-report-v1',
            'status':'OBSERVATIONAL_PAIRS_Q15_CHECKED' if q15_oracle is not None
                     else 'OBSERVATIONAL_PAIRS_Q15_PENDING',
            'origin':trace['origin'],'audit':audit,'observed':observed,
            'physical_timing_usable':trace['origin']=='fpga_de0cv',
            'timing_classification': ('PHYSICAL_CAPTURE_REQUIRES_EXTERNAL_PROVENANCE_REVIEW'
                 if trace['origin']=='fpga_de0cv' else 'SYNTHETIC_OR_RTL_NOT_PHYSICAL_PERFORMANCE'),
            'nonclaims':['These are observed cycles, not a proven WCET.',
                         'Synthetic fixtures must never be reported as physical performance.',
                         'E4 is not a verified same-model experiment without full Q15 oracle.']}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--trace',type=Path,required=True)
    p.add_argument('--matrix',type=Path,required=True)
    p.add_argument('--dataset',type=Path,required=True)
    p.add_argument('--q15-oracle',type=Path)
    p.add_argument('--expected-q15-predictions-sha256')
    p.add_argument('--expected-sof-sha256')
    p.add_argument('--expected-build-id',type=lambda x:int(x,0))
    p.add_argument('--expected-binding-id',type=lambda x:int(x,0))
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    report=paired_report(json.loads(a.trace.read_text()),json.loads(a.matrix.read_text()),
                         json.loads(a.dataset.read_text()),
                         q15_oracle=json.loads(a.q15_oracle.read_text()) if a.q15_oracle else None,
                         expected_q15_predictions_sha256=a.expected_q15_predictions_sha256,
                         expected_sof_sha256=a.expected_sof_sha256,
                         expected_build_id=a.expected_build_id,
                         expected_binding_id=a.expected_binding_id)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(report,indent=2)+'\n')
    print(report['status'],report['origin'],report['observed']['n'])
if __name__=='__main__':main()
