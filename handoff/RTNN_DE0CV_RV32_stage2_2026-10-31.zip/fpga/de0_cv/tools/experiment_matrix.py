#!/usr/bin/env python3
"""Deterministic experiment schedule. PLANNED != FPGA executed.

Deadline matrices carry a symbolic deadline_index until a new, verified
FPGA-specific timing binding is available. No old Simple-System cycles.
"""
from __future__ import annotations
import argparse
import json
import hashlib
import random
from pathlib import Path
from experiment_wire import Mode


def make_matrix(seed: int, count: int, which: str) -> dict:
    if type(seed) is not int or type(count) is not int or not (0 <= seed < 2**32) or not (1 <= count <= 360):
        raise ValueError('seed/count invalid; count must be 1..360')
    if which not in ('fixed','adaptive','paired','deadline'):
        raise ValueError('unknown experiment matrix')
    rows=[]
    budgets=[round(i*65535/20) for i in range(21)]
    for iid in range(count):
        if which=='fixed':
            rows.extend({'input_id':iid,'mode':int(Mode.FIXED),'fixed_exit':k,
                         'budget_q16':65535,'deadline_cycles':0} for k in range(7))
        if which=='adaptive':
            rows.extend({'input_id':iid,'mode':int(Mode.ADAPTIVE),'fixed_exit':0,
                         'budget_q16':b,'deadline_cycles':0} for b in budgets)
        if which=='paired':
            rows.extend([{'input_id':iid,'mode':int(Mode.FIXED),'fixed_exit':2,
                          'budget_q16':65535,'deadline_cycles':0},
                         {'input_id':iid,'mode':int(Mode.ADAPTIVE),'fixed_exit':0,
                          'budget_q16':65535,'deadline_cycles':0}])
        if which=='deadline':
            for b in budgets:
                for idx in range(7):
                    rows.append({'input_id':iid,'mode':int(Mode.DEADLINE_ADAPTIVE),
                                 'fixed_exit':0,'budget_q16':b,
                                 'deadline_cycles':None,'deadline_index':idx})
    random.Random(seed).shuffle(rows)
    for i,r in enumerate(rows):r['seq']=i+1
    canon=json.dumps(rows,sort_keys=True,separators=(',',':')).encode()
    return {'schema':'rtnn-de0cv-experiment-matrix-v1',
            'status': 'PLANNED_NEEDS_FPGA_BOUNDS' if which=='deadline' else 'PLANNED_NOT_EXECUTED',
            'experiment':which,'seed':seed,'record_count':len(rows),
            'schedule_sha256':hashlib.sha256(canon).hexdigest(),'rows':rows}


def bind_deadlines(matrix: dict, *, total_bounds: list[int], binding_id: int) -> dict:
    """Turn symbolic deadlines into executable requests after external proof review.

    This method never claims that bounds are certified; caller must provide an
    audited, immutable target-specific binding and record provenance separately.
    """
    if matrix.get('status')!='PLANNED_NEEDS_FPGA_BOUNDS':
        raise ValueError('not a symbolic deadline matrix')
    if len(total_bounds)!=7 or any(type(n) is not int or n <= 0 or n >= 2**32 for n in total_bounds):
        raise ValueError('seven positive finite FPGA total bounds required')
    if sorted(total_bounds)!=total_bounds or type(binding_id) is not int or binding_id<=0:
        raise ValueError('bounds must be monotone and binding ID nonzero')
    out=json.loads(json.dumps(matrix))
    for r in out['rows']:
        r['deadline_cycles']=total_bounds[r.pop('deadline_index')]
    out['status']='PLANNED_WITH_UNVERIFIED_TARGET_BOUNDS'
    out['binding_id']=binding_id
    # Bind the exact seven target-specific experimental bounds to the schedule;
    # these are NOT WCET evidence. Every execution/audit must review provenance.
    out['total_bounds']=list(total_bounds)
    out['bound_status']='UNVERIFIED_EXPLORATORY_ONLY'
    out['schedule_sha256']=hashlib.sha256(
        json.dumps(out['rows'],sort_keys=True,separators=(',',':')).encode()
    ).hexdigest()
    return out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--seed',type=int,default=63)
    ap.add_argument('--count',type=int,default=360)
    ap.add_argument('--which',choices=('fixed','paired','adaptive','deadline'),required=True)
    args=ap.parse_args()
    out=make_matrix(args.seed,args.count,args.which)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(out,indent=2)+'\n')
    print(out['status'],out['record_count'],out['schedule_sha256'])

if __name__=='__main__':main()
