#!/usr/bin/env python3
"""Paired same-input cycle comparisons, no implicit WCET or certification.

All metrics refer to an explicitly supplied capture, not synthetic estimates.
"""
from __future__ import annotations
from random import Random
import statistics


class AnalysisError(ValueError):
    pass


def paired_metrics(rows: list[dict], *, bootstrap_seed: int = 63, bootstrap_samples: int = 2000) -> dict:
    if not rows or len({r.get('input_id') for r in rows})!=len(rows):
        raise AnalysisError('missing rows or duplicate input_id')
    for r in rows:
        if type(r.get('input_id')) is not int or r['input_id']<0:
            raise AnalysisError('invalid input_id')
        for key in ('fixed2_cycles','adaptive_cycles'):
            if type(r.get(key)) is not int or r[key]<=0:
                raise AnalysisError(f'nonpositive or noninteger {key}')
        for key in ('fixed2_correct','adaptive_correct'):
            if type(r.get(key)) is not int or r[key] not in (0,1):
                raise AnalysisError(f'invalid correctness {key}')
    if type(bootstrap_seed) is not int or type(bootstrap_samples) is not int or bootstrap_samples<100:
        raise AnalysisError('invalid bootstrap configuration')
    f=[r['fixed2_cycles'] for r in rows]
    a=[r['adaptive_cycles'] for r in rows]
    savings=[x-y for x,y in zip(f,a)]
    delta=[r['adaptive_correct']-r['fixed2_correct'] for r in rows]
    rng=Random(bootstrap_seed)
    boots=[]
    for _ in range(bootstrap_samples):
        idx=[rng.randrange(len(rows)) for _ in rows]
        boots.append(sum(savings[i] for i in idx)/len(idx))
    boots.sort()
    return {'n':len(rows),'mean_fixed2_cycles':statistics.mean(f),
            'mean_adaptive_cycles':statistics.mean(a),
            'mean_cycle_saving':statistics.mean(savings),
            'cycle_speedup_ratio':statistics.mean(f)/statistics.mean(a),
            'fixed2_accuracy':statistics.mean(r['fixed2_correct'] for r in rows),
            'adaptive_accuracy':statistics.mean(r['adaptive_correct'] for r in rows),
            'paired_accuracy_delta_pp':100*statistics.mean(delta),
            'paired_disagreements_in_correctness':sum(x!=0 for x in delta),
            'bootstrap_mean_cycle_saving_95pct':[boots[int(.025*bootstrap_samples)],
                                                  boots[min(bootstrap_samples-1,int(.975*bootstrap_samples))]],
            'bootstrap_seed':bootstrap_seed,
            'status':'OBSERVATIONAL_ONLY_NOT_WCET',
            'nonclaim':'No real board performance result or timing upper bound is implied by this calculation.'}
