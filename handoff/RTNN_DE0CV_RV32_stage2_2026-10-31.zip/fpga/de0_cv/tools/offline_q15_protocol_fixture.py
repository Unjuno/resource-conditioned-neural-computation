#!/usr/bin/env python3
"""Real Q15 oracle / synthetic UART wire regression. No hardware/timing claim."""
from __future__ import annotations
import json
import hashlib
from pathlib import Path
from experiment_wire import Request,Response,Mode,Status,encode_request,encode_response
from experiment_matrix import make_matrix
from experiment_report import paired_report

EXPECTED_ORACLE_DIGEST='03eb958cfa8b4fd2f71a95fb47dbca512820c237c281473817bba685b92c743e'


def run_fixture(root:Path,out:Path)->dict:
    dataset=json.loads((root/'generated/heldout360.json').read_text())
    oracle=json.loads((root/'generated/frozen_q15_oracle.json').read_text())
    m=make_matrix(seed=63,count=360,which='paired')
    rows=[]
    for r in m['rows']:
        mode=Mode(r['mode']);iid=r['input_id']
        ref=oracle['predictions'][str(iid)];pref=ref['preferred_exit']
        e=2 if mode==Mode.FIXED else pref
        reason=0 if mode==Mode.FIXED else (1 if pref<5 else 2)
        q=Request(seq=r['seq'],input_id=iid,mode=mode,fixed_exit=r['fixed_exit'],
                  budget_q16=r['budget_q16'],deadline_cycles=r['deadline_cycles'],
                  model_id=0x52544e4e,build_id=0x44563032)
        # Deliberately synthetic cycles; MUST NOT be used as speedup evidence.
        resp=Response(seq=q.seq,input_id=iid,mode=mode,status=Status.OK,stop_reason=reason,
                      budget_q16=q.budget_q16,deadline_cycles=q.deadline_cycles,
                      admitted_exit=2 if mode==Mode.FIXED else 6,
                      executed_exit=e,prediction=ref['predictions'][e],
                      label=dataset['records'][iid]['label'],cycles=100,
                      model_id=q.model_id,build_id=q.build_id,binding_id=0,flags=0)
        rows.append({'request_hex':encode_request(q).hex(),
                     'response_hex':encode_response(resp).hex()})
    trace={'schema':'rtnn-de0cv-experiment-trace-v1','origin':'synthetic_fixture',
           'status':'SYNTHETIC_NOT_BOARD','rows':rows}
    report=paired_report(trace,m,dataset,q15_oracle=oracle,
                         expected_q15_predictions_sha256=EXPECTED_ORACLE_DIGEST)
    a=b=diff_a=diff_b=0; total=0
    for rec in dataset['records']:
        i=rec['input_id'];p=oracle['predictions'][str(i)];k=p['preferred_exit'];total+=k
        ac=p['predictions'][k]==rec['label'];fc=p['predictions'][2]==rec['label']
        a+=ac;b+=fc;diff_a+=ac and not fc;diff_b+=fc and not ac
    result={'status':'SYNTHETIC_Q15_WIRE_REGRESSION_ONLY',
            'q15_checked':report['audit']['q15_predictions_compared'],
            'fixed2_correct':b,'adaptive_correct':a,
            'adaptive_only_correct':diff_a,'fixed2_only_correct':diff_b,
            'mean_adaptive_blocks':total/360,'physical_timing_usable':False,
            'actual_model_used_for_predictions':True,
            'fake_clock_cycles_in_capture':100,
            'warning':'DO NOT USE synthetic cycle values as FPGA, RTL, or CPU performance evidence'}
    out.mkdir(parents=True,exist_ok=True)
    (out/'Q15_paired_synthetic_trace.json').write_text(json.dumps(trace,indent=2)+'\n')
    (out/'Q15_paired_synthetic_matrix.json').write_text(json.dumps(m,indent=2)+'\n')
    (out/'Q15_paired_synthetic_report.json').write_text(json.dumps(report,indent=2)+'\n')
    (out/'Q15_paired_synthetic_verdict.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();print(json.dumps(run_fixture(a.root,a.out),indent=2))
