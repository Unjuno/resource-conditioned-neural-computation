#!/usr/bin/env python3
"""Generate observations ONLY after re-running the strict UART verifier.

Never accepts an unchecked CSV, and never emits a WCET/admission certificate.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from capture_audit import audit, CaptureError


def analyze(raw: bytes, reference: dict, clock_hz: int, *, origin: str) -> dict:
    if origin not in {'sim_reference', 'fpga_unverified'}:
        raise ValueError('origin must be sim_reference or fpga_unverified')
    if not isinstance(clock_hz, int) or not (1 <= clock_hz <= 500_000_000):
        raise ValueError('clock_hz outside declared range')
    verified = audit(raw, reference)  # abort on any functional or shape mismatch
    classes = []
    for cls in range(7):
        cycles = verified['cert_cycles_by_class'][str(cls)]
        classes.append({'class': cls, 'samples': len(cycles),
                        'min_cycles': min(cycles), 'max_observed_cycles': max(cycles),
                        'range_cycles': max(cycles)-min(cycles),
                        'max_observed_seconds': max(cycles)/clock_hz})
    return {'schema': 'rtnn-de0-cv-observation-only-v2',
            'status': 'OBSERVED_NOT_WCET', 'origin': origin,
            'clock_hz_assumed_not_sta_verified': clock_hz,
            'uart_log_sha256': hashlib.sha256(raw).hexdigest(),
            'validated_record_count': 42,
            'class_observations': classes,
            'reusable_admission_bounds': None,
            'production_wcets': None,
            'note': 'The pinned binary still contains Simple-System RTL_TOTAL. Use FPGA-specific rebuilt admission after an independently defended physical cycle bound is available.'}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--reference', required=True, type=Path)
    ap.add_argument('--uart-log', required=True, type=Path)
    ap.add_argument('--clock-hz', type=int, required=True)
    ap.add_argument('--origin', choices=['sim_reference','fpga_unverified'], required=True)
    ap.add_argument('--out', required=True, type=Path)
    a=ap.parse_args()
    try:
        output = analyze(a.uart_log.read_bytes(), json.loads(a.reference.read_text()), a.clock_hz, origin=a.origin)
    except (CaptureError, ValueError, KeyError) as e:
        ap.exit(2, f'REJECTED: {e}\n')
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps(output, indent=2)+'\n')
    print(json.dumps(output, indent=2))

if __name__ == '__main__':
    main()
