#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "$0")/.." && pwd)
command -v verilator >/dev/null || { echo 'verilator not installed; RTL UNIT TESTS NOT EXECUTED' >&2; exit 2; }
cd "$here/quartus" # $readmemh path
mkdir -p "$here/build/rtl"
verilator --binary --timing -Wno-fatal --top-module tb_rtnn_de0_cv_ram \
  --Mdir "$here/build/rtl/ram" "$here/rtl/rtnn_de0_cv_ram.sv" \
  "$here/tests/rtl/tb_rtnn_de0_cv_ram.sv"
"$here/build/rtl/ram/Vtb_rtnn_de0_cv_ram"
verilator --binary --timing -Wno-fatal --top-module tb_rtnn_uart_tx \
  --Mdir "$here/build/rtl/uart" "$here/rtl/rtnn_uart_tx.sv" \
  "$here/tests/rtl/tb_rtnn_uart_tx.sv"
"$here/build/rtl/uart/Vtb_rtnn_uart_tx"

verilator --binary --timing -Wno-fatal --top-module tb_rtnn_uart_rx \
  --Mdir "$here/build/rtl/uart_rx" "$here/rtl/rtnn_uart_rx.sv" \
  "$here/tests/rtl/tb_rtnn_uart_rx.sv"
"$here/build/rtl/uart_rx/Vtb_rtnn_uart_rx"
