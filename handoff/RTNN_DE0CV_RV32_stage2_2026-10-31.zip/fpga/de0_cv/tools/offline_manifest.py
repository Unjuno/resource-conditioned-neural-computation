#!/usr/bin/env python3
"""Record exactly what was verified without making hardware claims."""
from __future__ import annotations
import hashlib
import json
import platform
import shutil
import subprocess
from pathlib import Path


def sha(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_manifest(root:Path,out:Path)->dict:
    z=root/'generated/frozen_q15_oracle.json'
    c=root/'upstream/source_repo/experiments/realtime_nn_real_sequence_fixed_core.c'
    h=c.with_suffix('.h')
    weights=root/'build/q15/realtime_nn_real_sequence_fixed_weights_generated.h'
    frozen_zip=root/'artifacts/rtnn_ibex_rtl_exact.zip'
    verdict=json.loads((root/'evidence/native_q15_firmware/native_firmware_verdict.json').read_text())
    if verdict.get('status')!='NATIVE_Q15_FIRMWARE_MATCHES_PINNED_MODEL':
        raise ValueError('native firmware not PASS; cannot produce offline verification manifest')
    oracle=json.loads(z.read_text()); pred_hash=hashlib.sha256(
        json.dumps(oracle['predictions'],sort_keys=True,separators=(',',':')).encode()
    ).hexdigest()
    if pred_hash!='03eb958cfa8b4fd2f71a95fb47dbca512820c237c281473817bba685b92c743e':
        raise ValueError('oracle source checksum changed')
    vals={
      'schema':'rtnn-de0cv-offline-provenance-v1',
      'status':'OFFLINE_VERIFIED_FPGA_UNTESTED',
      'research_repo':'Unjuno/resource-conditioned-neural-computation',
      'research_main_sha':'ea903d3b76c4cb50732c3f9c72c8ed2084c2cb23',
      'ibex_commit':'7b5df75a041affe56e8c235260f98a09b3319008',
      'frozen':{'zip_sha256':sha(frozen_zip),'exact_core_git_blob':subprocess.check_output(['git','hash-object',str(c)],text=True).strip(),
                'exact_header_git_blob':subprocess.check_output(['git','hash-object',str(h)],text=True).strip(),
                'weights_header_sha256':sha(weights)},
      'q15':{'records':oracle['record_count'],'predictions_sha256':pred_hash,
             'raw_csv_sha256':oracle['raw_csv_sha256'],
             'fixed_exit_correct':oracle['accuracy_correct_by_exit'],
             'preferred_exit_histogram':oracle['preferred_histogram'],
             'preferred_correct':oracle['policy_correct'],
             'mean_preferred_blocks':sum(i*n for i,n in enumerate(oracle['preferred_histogram']))/360},
      'native_firmware':{'functional_cases':verdict['fixed_cases']+verdict['adaptive_cases'],
                         'prediction_mismatches':verdict['prediction_mismatches'],
                         'exit_mismatches':verdict['executed_exit_mismatches'],
                         'stop_reason_mismatches':verdict['stop_reason_mismatches'],
                         'status_errors':verdict['status_errors'],
                         'host_csv_sha256':verdict['host_csv_sha256'],
                         'timing_valid':False},
      'verification_environment':{'python':platform.python_version(),
                                  'gcc':subprocess.check_output(['gcc','-dumpfullversion'],text=True).strip(),
                                  'eda_tool_executables':{x:shutil.which(x) for x in ('verilator','sv2v','quartus_sh','quartus_sta','riscv64-unknown-elf-gcc')}},
      'fpga':{'physical_measurement_count':0,'rtl_integration_simulated':False,
              'sv2v_equivalence':False,'sta_verified':False,'fitter_verified':False,
              'configured_board_build_sha256':None,'board_cycle_upper_bounds':None},
      'paper_claim_scope':['native fixed-Q15 accuracy/reference decisions',
                           'native firmware correctness of 10,080 cases',
                           'protocol and host audit regression only'],
      'paper_prohibited':['DE0-CV FPGA inference accuracy',
                          'DE0-CV measured cycles or speedup',
                          'hardware deadline admission',
                          'FPGA hard-real-time or production WCET']}
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(vals,indent=2,ensure_ascii=False)+'\n')
    return vals

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();print(json.dumps(make_manifest(a.root,a.out),indent=2,ensure_ascii=False))
