#!/usr/bin/env python3
"""Create an isolated Quartus B workspace; never overwrite frozen A RAM.

This is a packaging gate, NOT sv2v verification, synthesis, or timing closure.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil

class BuildPreparationError(ValueError):pass

def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()

def prepare(root:Path,source:Path,destination:Path,flat:Path)->dict:
    if not flat.is_file() or flat.stat().st_size==0:
        raise BuildPreparationError('pinned and converted Ibex flat RTL missing')
    hexfile=source/'rtnn_ram_words.hex'
    manfile=source/'fpga_b_image_manifest.json'
    if not hexfile.is_file() or not manfile.is_file():
        raise BuildPreparationError('missing B firmware image/manifest')
    man=json.loads(manfile.read_text())
    if man.get('schema')!='rtnn-de0cv-b-firmware-ram-v1' or man.get('status')!='IMAGE_GENERATED_NOT_SYNTHESIZED':
        raise BuildPreparationError('wrong B firmware manifest')
    hexdata=hexfile.read_bytes()
    if sha(hexdata)!=man.get('hex_sha256'):
        raise BuildPreparationError('B RAM hex does not match generated manifest')
    lines=hexdata.splitlines()
    if len(lines)!=65536 or any(len(x)!=8 or any(c not in b'0123456789abcdefABCDEF' for c in x) for x in lines):
        raise BuildPreparationError('wrong B on-chip RAM hex layout')
    a=json.loads((root/'quartus/frozen_image_manifest.json').read_text())
    if sha(hexdata)==a['ram_hex_sha256']:
        raise BuildPreparationError('cannot compile frozen A RAM image as B experiment')
    if man.get('bin_sha256')==a['bin_sha256']:
        raise BuildPreparationError('B firmware binary matches old A image')
    if destination.exists():
        raise BuildPreparationError('destination already exists; no implicit overwrites')
    for f in ('rtnn_de0_cv.qsf','rtnn_de0_cv.qpf','rtnn_de0_cv.sdc'):
        if not (root/'quartus'/f).is_file():
            raise BuildPreparationError('missing Quartus project source '+f)
    destination.mkdir(parents=True)
    for f in ('rtnn_de0_cv.qsf','rtnn_de0_cv.qpf','rtnn_de0_cv.sdc'):
        shutil.copyfile(root/'quartus'/f,destination/f)
    shutil.copyfile(flat,destination/'ibex_flat.v')
    shutil.copyfile(hexfile,destination/'rtnn_ram_words.hex')
    out={'schema':'rtnn-de0cv-b-quartus-package-v1',
         'status':'PREPARED_NOT_ELABORATED_NOT_SYNTHESIZED',
         'flat_rtl_sha256':sha(flat.read_bytes()),
         'b_ram_hex_sha256':sha(hexdata),
         'source_b_manifest_sha256':sha(manfile.read_bytes()),
         'qsf_sha256':sha((destination/'rtnn_de0_cv.qsf').read_bytes()),
         'nonclaims':['Converted RTL not proven equivalent.',
                      'Quartus Fitter and STA not run.',
                      'FPGA bitstream not built.']}
    (destination/'b_build_preparation.json').write_text(json.dumps(out,indent=2)+'\n')
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--b-build',type=Path,required=True)
    p.add_argument('--flat',type=Path,required=True)
    p.add_argument('--out-dir',type=Path,required=True)
    a=p.parse_args()
    try:r=prepare(a.root,a.b_build,a.out_dir,a.flat)
    except (BuildPreparationError,ValueError) as e:p.exit(2,f'B_QUARTUS_PREP_FAIL: {e}\n')
    print(r['status'])
if __name__=='__main__':main()
