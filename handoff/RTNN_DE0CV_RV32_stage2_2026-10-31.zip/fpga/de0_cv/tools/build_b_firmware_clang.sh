#!/usr/bin/env bash
# Offline RV32 machine-image build when a RISC-V GCC toolchain is absent.
# This does NOT prove instruction-level equivalence, RTL operation, or timing.
set -euo pipefail
if (($# != 2)); then
  echo 'usage: build_b_firmware_clang.sh OUTPUT_DIRECTORY PINNED_SOURCE_REPO' >&2
  exit 2
fi
here=$(cd "$(dirname "$0")/.." && pwd)
out="$1"
repo=$(cd "$2" && pwd)
[[ ! -e "$out" ]] || { echo "Refusing existing output destination: $out" >&2; exit 2; }
for tool in clang ld.lld llvm-objcopy readelf git unzip sha256sum python3; do
  command -v "$tool" >/dev/null || { echo "Missing tool $tool" >&2; exit 2; }
done
src="$repo/experiments"
for f in realtime_nn_real_sequence_fixed_core.c realtime_nn_real_sequence_fixed_core.h; do
  [[ -f "$src/$f" ]] || { echo "Missing model core $src/$f" >&2; exit 2; }
done
[[ "$(git hash-object "$src/realtime_nn_real_sequence_fixed_core.c")" == '3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a' ]] || {
  echo 'Q15 core Git blob SHA mismatch' >&2; exit 2; }
[[ "$(git hash-object "$src/realtime_nn_real_sequence_fixed_core.h")" == 'ac185458e21b956db01cb18504bdb507c0c69618' ]] || {
  echo 'Q15 core header Git blob SHA mismatch' >&2; exit 2; }
[[ -s "$here/generated/heldout360.h" ]] || { echo 'Missing frozen test dataset header' >&2; exit 2; }
mkdir -p "$out"
# A requested output directory is new; a failed compile must retain its log.
weights="$out/realtime_nn_real_sequence_fixed_weights_generated.h"
unzip -p "$here/artifacts/rtnn_ibex_rtl_exact.zip" \
  rtnn/realtime_nn_real_sequence_fixed_weights_generated.h > "$weights"
want=961a76b7e220bf2f665e7c04ab62063600aa2e7eccf3403d80ea730bc993ad9f
[[ "$(sha256sum "$weights" | cut -d' ' -f1)" == "$want" ]] || {
  echo 'Frozen model weight SHA mismatch' >&2; exit 2; }
flags=(--target=riscv32-unknown-elf -march=rv32im_zicsr -mabi=ilp32
       -O2 -std=c11 -ffreestanding -fno-builtin -fno-pic -fno-pie
       -fuse-ld=lld -nostdlib -Wl,--no-relax
       -Wl,-T,"$here/firmware/rtnn_experiment.ld")
clang "${flags[@]}" \
  -I"$src" -I"$here/generated" -I"$out" -I"$here/firmware" \
  "$here/firmware/rtnn_experiment_start.S" \
  "$src/realtime_nn_real_sequence_fixed_core.c" \
  "$here/firmware/rtnn_experiment_wire.c" \
  "$here/firmware/rtnn_experiment_runner.c" \
  "$here/firmware/rtnn_board_main.c" \
  "$here/firmware/rtnn_freestanding_mem.c" \
  -o "$out/rtnn_experiment.elf" 2>&1 | tee "$out/compiler.log"
# The builder also checks machine/endian/program headers and stack layout.
llvm-objcopy -O binary "$out/rtnn_experiment.elf" "$out/rtnn_experiment.bin"
python3 "$here/tools/build_b_image.py" \
  --elf "$out/rtnn_experiment.elf" --bin "$out/rtnn_experiment.bin" --out-dir "$out"
python3 - "$out" "$want" "$here" "$repo" <<'PY2'
import hashlib,json,subprocess,sys
from pathlib import Path
p=Path(sys.argv[1]);weight=sys.argv[2]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def ver(cmd):return subprocess.check_output(cmd,text=True).splitlines()[0]
e=Path(p/'rtnn_experiment.elf')
root=Path(sys.argv[3]); model_root=Path(sys.argv[4])
fixed_sources=[
  'firmware/rtnn_experiment_start.S','firmware/rtnn_experiment_wire.c',
  'firmware/rtnn_experiment_wire.h','firmware/rtnn_experiment_runner.c',
  'firmware/rtnn_experiment_runner.h','firmware/rtnn_board_main.c',
  'firmware/rtnn_freestanding_mem.c','firmware/rtnn_experiment.ld',
  'generated/heldout360.h','tools/build_b_firmware_clang.sh',
  'tools/build_b_image.py'
]
source_sha={f:sha(root/f) for f in fixed_sources}
source_sha.update({f'upstream/experiments/{name}':sha(model_root/'experiments'/name) for name in (
  'realtime_nn_real_sequence_fixed_core.c','realtime_nn_real_sequence_fixed_core.h')})
s=subprocess.check_output(['readelf','-Ws',str(e)],text=True)
undefined=[line for line in s.splitlines() if ' UND ' in line and not line.lstrip().startswith('0:')]
if undefined:raise SystemExit(f'unresolved RV32 symbols: {undefined}')
manifest={
    'schema':'rtnn-de0cv-clang-rv32-build-v1',
    'claim':'COMPILED_NOT_EXECUTED_ON_RV32',
    'compiler':ver(['clang','--version']),'linker':ver(['ld.lld','--version']),
    'isa':'rv32im_zicsr','abi':'ilp32','flags':'-O2 -ffreestanding -fno-builtin -nostdlib --no-relax',
    'elf_sha256':sha(e),'bin_sha256':sha(p/'rtnn_experiment.bin'),
    'model_sha256':weight,
    'source_sha256':source_sha,
    'source_git_blobs':{
       'realtime_nn_real_sequence_fixed_core.c':'3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a',
       'realtime_nn_real_sequence_fixed_core.h':'ac185458e21b956db01cb18504bdb507c0c69618'},
    'linker_sha256':sha(Path(sys.argv[3])/'firmware/rtnn_experiment.ld'),
    'includes_old_simple_system_cycle_table':False,
    'fpga_timing_bounds_available':False,
    'unresolved_symbol_count':len(undefined),
    'nonclaims':['Machine-code image not yet executed in RTL simulator or FPGA.',
                 'Clang output is distinct from the prior GCC Simple-System ELF.',
                 'No FPGA WCET certificate.']
}
(p/'toolchain_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
PY2
echo 'CLANG_RV32_B_IMAGE_READY_NOT_RTL_VERIFIED'
