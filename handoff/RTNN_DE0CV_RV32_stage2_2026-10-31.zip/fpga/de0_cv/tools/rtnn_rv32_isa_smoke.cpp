/* Minimal RV32IM+Zicsr interpreter for HOST-ONLY firmware integration tests.
 * Not a Verilator/Ibex RTL simulator, not cycle accurate, not formal proof.
 * A single memory-mapped UART peripheral supplies request bytes on demand.
 * A simulated mcycle increments per ISA instruction, not per Ibex cycle.
 * Unsupported instructions or memory accesses fail closed.
 */
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
constexpr uint32_t BASE=0x00100000, SIZE=256*1024;
constexpr uint32_t UART_TX=0x00020000, UART_RX_STATUS=0x00020010;
constexpr uint32_t UART_RX_DATA=0x00020014;
constexpr uint32_t BUILD_MAGIC=0x52544e4e;
constexpr size_t RSP_BYTES=48, REQ_BYTES=32;
int32_t sext(uint32_t value,unsigned bits){
    uint32_t sign=uint32_t(1) << (bits-1);
    return static_cast<int32_t>((value^sign)-sign);
}
struct Machine {
  std::array<uint32_t,32> reg{};
  std::vector<uint8_t> ram;
  std::vector<uint8_t> rx,tx;
  uint32_t pc=BASE+0x80;
  uint64_t instructions=0;
  size_t rx_index=0;
  Machine(const std::vector<uint8_t>&image,const std::vector<uint8_t>&input)
    :ram(SIZE,0),rx(input){
    if(image.empty()||image.size()>ram.size()||input.size()%REQ_BYTES!=0)
      throw std::runtime_error("invalid BIN or UART request length");
    std::copy(image.begin(),image.end(),ram.begin());
  }
  size_t offset(uint32_t addr,unsigned bytes){
    uint64_t mapped=addr;
    // Match the A stack alias too; the B image uses the direct 256-KiB stack.
    if(addr>=0x001f8000 && addr<0x00200000)
      mapped=uint64_t(BASE)+0x38000+(addr-0x001f8000);
    if(mapped<BASE||mapped+bytes>uint64_t(BASE)+SIZE)
      throw std::runtime_error("RAM out of range at "+std::to_string(addr));
    return static_cast<size_t>(mapped-BASE);
  }
  uint32_t load(uint32_t addr,unsigned bytes){
    if(addr==UART_RX_STATUS && bytes==4) return rx_index<rx.size()?1:0;
    if(addr==UART_RX_DATA && bytes==4)
      return rx_index<rx.size()?rx[rx_index++]:0;
    if(addr==0x00020004 && bytes==4) return 1;
    if(addr==0x00020008 && bytes==4) return 0;
    if(addr==0x0002000c && bytes==4) return BUILD_MAGIC;
    if(addr>=0x00020000 && addr<0x00020400)
      throw std::runtime_error("unsupported MMIO read: "+std::to_string(addr));
    if((addr&(bytes-1))!=0) throw std::runtime_error("unaligned load");
    size_t p=offset(addr,bytes);
    uint32_t v=0;for(unsigned i=0;i<bytes;i++)v|=uint32_t(ram[p+i])<<(8*i);
    return v;
  }
  void store(uint32_t addr,uint32_t value,unsigned bytes){
    if(addr==UART_TX && bytes==4){tx.push_back(uint8_t(value));return;}
    if(addr==UART_RX_STATUS && bytes==4 && value==2)return;
    if(addr==0x00020008 && bytes==4)return;
    if(addr>=0x00020000 && addr<0x00020400)
      throw std::runtime_error("unsupported MMIO write: "+std::to_string(addr));
    if((addr&(bytes-1))!=0) throw std::runtime_error("unaligned store");
    size_t p=offset(addr,bytes);
    for(unsigned i=0;i<bytes;i++)ram[p+i]=uint8_t(value>>(8*i));
  }
  uint32_t csr(uint32_t idx){
    if(idx==0xb00 ||idx==0xc00)return uint32_t(instructions);
    if(idx==0xb80 ||idx==0xc80)return uint32_t(instructions>>32);
    throw std::runtime_error("unsupported CSR index: "+std::to_string(idx));
  }
  void step(){
    if((pc&3)!=0)throw std::runtime_error("unaligned PC");
    uint32_t ins=load(pc,4);
    if((ins&3)!=3)throw std::runtime_error("unexpected compressed instruction");
    const unsigned opc=ins&0x7f,rd=(ins>>7)&31,f3=(ins>>12)&7;
    const unsigned rs1=(ins>>15)&31,rs2=(ins>>20)&31,f7=(ins>>25)&127;
    const uint32_t a=reg[rs1],b=reg[rs2];
    const int32_t imm_i=sext(ins>>20,12);
    const uint32_t imm_s=((ins>>7)&31)|(((ins>>25)&127)<<5);
    uint32_t next=pc+4, v=0;
    bool write_rd=true;
    switch(opc){
      case 0x37:v=ins&0xfffff000;break; // LUI
      case 0x17:v=pc+(ins&0xfffff000);break; // AUIPC
      case 0x6f: { // JAL
        uint32_t imm=((ins>>31)<<20)|(((ins>>12)&255)<<12)|(((ins>>20)&1)<<11)|(((ins>>21)&1023)<<1);
        v=pc+4;next=pc+sext(imm,21);break;
      }
      case 0x67: { // JALR
        if(f3!=0)throw std::runtime_error("invalid JALR");
        v=pc+4;next=(a+uint32_t(imm_i))&~uint32_t(1);break;
      }
      case 0x63: { // BRANCH
        write_rd=false;
        uint32_t imm=((ins>>31)<<12)|(((ins>>7)&1)<<11)|(((ins>>25)&63)<<5)|(((ins>>8)&15)<<1);
        bool take=false;
        switch(f3){
          case 0: take=a==b;break; case 1: take=a!=b;break;
          case 4: take=int32_t(a)<int32_t(b);break;
          case 5: take=int32_t(a)>=int32_t(b);break;
          case 6: take=a<b;break; case 7: take=a>=b;break;
          default: throw std::runtime_error("invalid branch funct3");
        }
        if(take)next=pc+sext(imm,13);break;
      }
      case 0x03: { // LOAD
        uint32_t addr=a+uint32_t(imm_i);
        switch(f3){
          case 0:v=uint32_t(sext(load(addr,1),8));break;
          case 1:v=uint32_t(sext(load(addr,2),16));break;
          case 2:v=load(addr,4);break;
          case 4:v=load(addr,1);break;
          case 5:v=load(addr,2);break;
          default:throw std::runtime_error("invalid load size");
        }
        break;
      }
      case 0x23: { // STORE
        write_rd=false;
        uint32_t addr=a+uint32_t(sext(imm_s,12));
        if(f3==0)store(addr,b,1);
        else if(f3==1)store(addr,b,2);
        else if(f3==2)store(addr,b,4);
        else throw std::runtime_error("invalid store size");
        break;
      }
      case 0x13: { // OP-IMM
        unsigned sh=(ins>>20)&31;
        switch(f3){
          case 0:v=a+uint32_t(imm_i);break;
          case 2:v=int32_t(a)<imm_i;break;
          case 3:v=a<uint32_t(imm_i);break;
          case 4:v=a^uint32_t(imm_i);break;
          case 6:v=a|uint32_t(imm_i);break;
          case 7:v=a&uint32_t(imm_i);break;
          case 1:if(f7!=0)throw std::runtime_error("invalid SLLI");v=a<<sh;break;
          case 5:
            if(f7==0)v=a>>sh;
            else if(f7==32)v=uint32_t(int32_t(a)>>sh);
            else throw std::runtime_error("invalid SRLI/SRAI");
            break;
          default:throw std::runtime_error("invalid OP-IMM");
        }
        break;
      }
      case 0x33: { // OP and RV32M
        if(f7==1){
          switch(f3){
            case 0:v=uint32_t(uint64_t(a)*b);break;
            case 1:v=uint32_t((int64_t(int32_t(a))*int64_t(int32_t(b)))>>32);break;
            case 2:v=uint32_t((int64_t(int32_t(a))*int64_t(b))>>32);break;
            case 3:v=uint32_t((uint64_t(a)*uint64_t(b))>>32);break;
            case 4: {
              if(!b)v=UINT32_MAX;
              else if(a==0x80000000 && b==UINT32_MAX)v=a;
              else v=uint32_t(int32_t(a)/int32_t(b));break;
            }
            case 5:v=b?a/b:UINT32_MAX;break;
            case 6: {
              if(!b)v=a;
              else if(a==0x80000000 && b==UINT32_MAX)v=0;
              else v=uint32_t(int32_t(a)%int32_t(b));break;
            }
            case 7:v=b?a%b:a;break;
            default:throw std::runtime_error("invalid RV32M funct3");
          }
        }else{
          switch(f3){
            case 0:v=f7==32?a-b:a+b;break;
            case 1:v=a<<(b&31);break;
            case 2:v=int32_t(a)<int32_t(b);break;
            case 3:v=a<b;break;
            case 4:v=a^b;break;
            case 5:v=f7==32?uint32_t(int32_t(a)>>(b&31)):a>>(b&31);break;
            case 6:v=a|b;break;
            case 7:v=a&b;break;
            default:throw std::runtime_error("invalid OP funct3");
          }
          if(f7!=0 && !(f7==32&&(f3==0||f3==5)))
            throw std::runtime_error("unsupported OP funct7");
        }
        break;
      }
      case 0x0f:write_rd=false;break; // FENCE
      case 0x73: { // CSR reads only; the test never writes mcycle.
        unsigned idx=(ins>>20)&0xfff;
        if(f3==2 && rs1==0)v=csr(idx);
        else if(f3==1 && rs1==0)v=csr(idx);
        else throw std::runtime_error("unsupported system/CSR operation");
        break;
      }
      default:throw std::runtime_error("unsupported opcode "+std::to_string(opc));
    }
    if(write_rd && rd)reg[rd]=v;
    reg[0]=0;
    pc=next;
    ++instructions;
  }
  void run(size_t replies){
    const uint64_t limit=UINT64_C(2000000000);
    while(tx.size()<replies*RSP_BYTES){
      if(instructions>=limit)throw std::runtime_error("ISA instruction budget exceeded");
      try{step();}
      catch(const std::exception&e){
        throw std::runtime_error(std::string(e.what())+" at pc="+std::to_string(pc)
                                 +" insns="+std::to_string(instructions));
      }
    }
    if(tx.size()!=replies*RSP_BYTES)throw std::runtime_error("unexpected response size");
  }
};
}
int main(int argc,char **argv){
  try{
    if(argc!=3)throw std::runtime_error("usage: rtnn_rv32_isa_smoke ELF_BINARY RESPONSES");
    std::ifstream f(argv[1],std::ios::binary);
    if(!f)throw std::runtime_error("cannot open BIN");
    std::vector<uint8_t> image((std::istreambuf_iterator<char>(f)),std::istreambuf_iterator<char>());
    std::vector<uint8_t> input((std::istreambuf_iterator<char>(std::cin)),std::istreambuf_iterator<char>());
    size_t count=std::stoul(argv[2]);
    if(!count||count>1000||input.size()!=count*REQ_BYTES)
      throw std::runtime_error("request count/byte count mismatch");
    Machine cpu(image,input);
    cpu.run(count);
    std::cout.write(reinterpret_cast<const char*>(cpu.tx.data()),cpu.tx.size());
    std::cerr<<"ISA_LEVEL_ONLY instructions="<<cpu.instructions
             <<" replies="<<count<<" NO_IBEX_CYCLES_NO_FPGA_PROOF\n";
    return 0;
  }catch(const std::exception&e){std::cerr<<"ISA_SMOKE_FAIL: "<<e.what()<<"\n";return 2;}
}
