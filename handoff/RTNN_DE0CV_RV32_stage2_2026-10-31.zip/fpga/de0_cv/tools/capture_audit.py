#!/usr/bin/env python3
"""Strict verifier for the original frozen RTL harness serial grammar.

OVERHEAD,ONE,n
OVERHEAD,TWO,n
CERT,slot,test_index,class,cycles,prediction    (3*7 rows)
E2E,slot,test_index,budget_class,admitted,executed,cycles,prediction (3*7)
DONE

Works on the actual verified Ibex Simple-System log; usable on DE0-CV UART
only after its gate-level and capture transport have been validated.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path


class CaptureError(ValueError):
    pass


def need(condition: bool, message: str) -> None:
    if not condition:
        raise CaptureError(message)


def uint(s: str, context: str, *, maxval: int = 0xffffffff) -> int:
    need(bool(s) and s.isascii() and s.isdecimal(),
         f'invalid decimal integer at {context}')
    n = int(s)
    need(0 <= n <= maxval, f'integer out of range at {context}')
    return n


def validate_reference(reference: dict) -> dict[int, dict]:
    need(reference.get('schema') == 'rtnn-de0-cv-preflight-v1', 'wrong reference schema')
    need(reference.get('finite_classes') == list(range(7)), 'wrong classes')
    src = reference.get('source_artifact') or {}
    from frozen_image import ZIP_SHA, ELF_SHA, BIN_SHA
    need(src.get('frozen_zip_sha256') == ZIP_SHA and src.get('elf_sha256') == ELF_SHA
         and src.get('bin_sha256') == BIN_SHA, 'reference is not the pinned artifact')
    vectors = reference.get('vectors', [])
    need(len(vectors) == 3, 'wrong reference vector count')
    by_slot = {}
    for row in vectors:
        slot = row['slot']
        need(type(slot) is int and slot in range(3) and slot not in by_slot, 'invalid slot')
        need(type(row['test_index']) is int and row['test_index'] >= 0, 'bad reference test index')
        need(type(row['preferred_exit']) is int and 0 <= row['preferred_exit'] <= 5, 'bad preferred exit')
        preds = row['expected_fixed_class_prediction']
        need(len(preds) == 7 and all(type(p) is int and 0 <= p < 10 for p in preds),
             'bad predictions in reference')
        pixels = row['input_u8_64']
        need(len(pixels) == 64 and all(type(p) is int and 0 <= p <= 255 for p in pixels), 'bad pixel array')
        by_slot[slot] = row
    need(set(by_slot) == set(range(3)), 'noncanonical slots')
    return by_slot


def audit(raw: bytes, reference: dict) -> dict:
    try:
        lines = raw.decode('ascii').splitlines()
    except UnicodeDecodeError as e:
        raise CaptureError('non-ASCII serial transcript') from e
    need(bool(lines), 'empty capture')
    slots = validate_reference(reference)
    cert, e2e, overhead = {}, {}, {}
    ended = False
    for line_no, rawline in enumerate(lines, 1):
        line = rawline.strip()
        need(bool(line) and line == rawline, f'blank or padded line at {line_no}')
        need(not ended, 'trailing data after DONE (multiple boots not implicitly accepted)')
        p = line.split(',')
        typ = p[0]
        if typ == 'OVERHEAD':
            need(len(p) == 3 and p[1] in ('ONE', 'TWO'), f'bad OVERHEAD at {line_no}')
            need(not cert and not e2e, 'overhead after inference rows')
            need(p[1] not in overhead, 'duplicate overhead')
            overhead[p[1]] = uint(p[2], f'overhead line {line_no}')
        elif typ == 'CERT':
            need(len(p) == 6, f'bad CERT field count at {line_no}')
            slot, idx, cls, cycles, pred = [uint(z, f'CERT line {line_no}') for z in p[1:]]
            need(slot in slots and cls in range(7), 'bad CERT slot/class')
            need(idx == slots[slot]['test_index'], 'wrong test_index in CERT')
            need((slot, cls) not in cert, 'duplicate CERT')
            need(not e2e, 'CERT after E2E')
            need(cycles > 0, 'CERT nonpositive cycles')
            need(pred == slots[slot]['expected_fixed_class_prediction'][cls],
                 f'CERT prediction mismatch at ({slot},{cls})')
            cert[(slot, cls)] = cycles
        elif typ == 'E2E':
            need(len(p) == 8, f'bad E2E field count at {line_no}')
            slot, idx, cls, admitted, executed, cycles, pred = [uint(z, f'E2E line {line_no}') for z in p[1:]]
            need(slot in slots and cls in range(7), 'bad E2E slot/class')
            need(idx == slots[slot]['test_index'], 'wrong E2E test_index')
            need((slot, cls) not in e2e, 'duplicate E2E')
            need(len(cert) == 21, 'E2E before complete CERT table')
            need(admitted in range(7) and admitted >= cls, 'legacy admitted label mismatch')
            expected = min(cls, 5, slots[slot]['preferred_exit'])
            need(executed == expected, 'wrong executed class')
            need(pred == slots[slot]['expected_fixed_class_prediction'][executed],
                 'E2E prediction mismatch')
            need(cycles > 0, 'E2E nonpositive cycles')
            e2e[(slot, cls)] = {'cycles': cycles, 'admitted': admitted, 'executed': executed}
        elif typ == 'DONE':
            need(len(p) == 1 and len(cert) == len(e2e) == 21 and set(overhead) == {'ONE', 'TWO'},
                 'DONE before all results received')
            ended = True
        else:
            raise CaptureError(f'unknown line type {typ!r} at {line_no}')
    expected_pairs = {(s,c) for s in range(3) for c in range(7)}
    need(ended and set(cert) == set(e2e) == expected_pairs, 'incomplete capture')
    by = {str(c): [cert[(s,c)] for s in range(3)] for c in range(7)}
    return {
        'schema': 'rtnn-de0-cv-frozen-uart-audit-v1',
        'decision': 'PASS_REFERENCE_CONSISTENT',
        'uart_log_sha256': hashlib.sha256(raw).hexdigest(),
        'certification_rows': 21, 'legacy_e2e_rows': 21,
        'overhead': overhead,
        'cert_cycles_by_class': by,
        'legacy_e2e_max_observed': [max(e2e[(s,c)]['cycles'] for s in range(3)) for c in range(7)],
        'nonclaims': [
            'This output does not prove the serial data came from a given bitstream.',
            'E2E uses the FROZEN OLD Simple-System RTL_TOTAL; FPGA deadline admission has NOT been certified.',
            'Observed maxima across three vectors are NOT hard WCET or a statistically justified p99 bound.'
        ],
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--reference', required=True, type=Path)
    ap.add_argument('--uart-log', required=True, type=Path)
    ap.add_argument('--out', type=Path)
    args = ap.parse_args()
    try:
        result = audit(args.uart_log.read_bytes(), json.loads(args.reference.read_text()))
    except (CaptureError, json.JSONDecodeError, KeyError, ValueError) as e:
        ap.exit(2, f'CAPTURE_FAIL: {e}\n')
    rendered = json.dumps(result, indent=2)+'\n'
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(rendered)
    print(rendered, end='')


if __name__ == '__main__':
    main()
