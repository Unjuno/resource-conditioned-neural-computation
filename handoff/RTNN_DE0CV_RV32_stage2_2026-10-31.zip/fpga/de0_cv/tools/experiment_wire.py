#!/usr/bin/env python3
"""Versioned byte-exact RTNN experimental UART frames.

All multibyte fields are little-endian. CRC-32/ISO-HDLC covers all bytes
except the final little-endian CRC. This protocol is *not* a certification of
an FPGA implementation or of the identity of the transmitting device.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
import struct
import zlib


class FrameError(ValueError):
    pass


class Mode(IntEnum):
    STATUS = 0
    FIXED = 1
    CAPPED_NO_STOP = 2
    ADAPTIVE = 3
    DEADLINE_ADAPTIVE = 4


class Status(IntEnum):
    OK = 0
    REJECTED = 1
    BAD_FRAME = 2
    WRONG_ID = 3
    BAD_REQUEST = 4
    INTERNAL_ERROR = 5


REQUEST = struct.Struct('<4sBBBBIHHIIII')
RESPONSE = struct.Struct('<4sBBBBIHHIbbbbIIIIII')
VERSION = 1
REQUEST_MAGIC = b'RTNQ'
RESPONSE_MAGIC = b'RTNR'


@dataclass(frozen=True)
class Request:
    seq: int
    input_id: int
    mode: Mode
    fixed_exit: int
    budget_q16: int
    deadline_cycles: int
    model_id: int
    build_id: int


@dataclass(frozen=True)
class Response:
    seq: int
    input_id: int
    mode: Mode
    status: Status
    stop_reason: int
    budget_q16: int
    deadline_cycles: int
    admitted_exit: int
    executed_exit: int
    prediction: int
    label: int
    cycles: int
    model_id: int
    build_id: int
    binding_id: int
    flags: int


def ensure_uint(name: str, value: int, bits: int) -> None:
    if type(value) is not int or not (0 <= value < (1 << bits)):
        raise FrameError(f'{name} must be unsigned {bits}-bit integer')


def ensure_int(name: str, value: int, low: int, high: int) -> None:
    if type(value) is not int or not (low <= value <= high):
        raise FrameError(f'{name} out of range [{low},{high}]')


def check_mode(value: int) -> Mode:
    try:
        return Mode(value)
    except ValueError as e:
        raise FrameError(f'unknown mode {value}') from e


def check_status(value: int) -> Status:
    try:
        return Status(value)
    except ValueError as e:
        raise FrameError(f'unknown status {value}') from e


def check_request(req: Request) -> None:
    for name, bits in [('seq',32),('input_id',16),('fixed_exit',8),
                       ('budget_q16',16),('deadline_cycles',32),('model_id',32),('build_id',32)]:
        ensure_uint(name, getattr(req, name), bits)
    check_mode(req.mode)
    ensure_int('fixed_exit', req.fixed_exit, 0, 6)
    if req.mode != Mode.FIXED and req.fixed_exit != 0:
        raise FrameError('fixed_exit must be zero for non-FIXED modes')
    if req.mode == Mode.DEADLINE_ADAPTIVE and req.deadline_cycles == 0:
        # A truly too-short deadline is allowed and must lead to REJECTED.
        pass
    if req.model_id == 0 or req.build_id == 0:
        raise FrameError('model and build identities cannot be zero')


def check_response(res: Response) -> None:
    for name, bits in [('seq',32),('input_id',16),('budget_q16',16),('deadline_cycles',32),
                       ('cycles',32),('model_id',32),('build_id',32),('binding_id',32),('flags',32)]:
        ensure_uint(name, getattr(res, name), bits)
    check_mode(res.mode)
    check_status(res.status)
    ensure_int('stop_reason',res.stop_reason,0,3)
    ensure_int('admitted_exit',res.admitted_exit,-1,6)
    ensure_int('executed_exit',res.executed_exit,-1,6)
    ensure_int('prediction',res.prediction,-1,9)
    ensure_int('label',res.label,-1,9)
    if res.status == Status.OK and res.mode == Mode.STATUS:
        if (res.admitted_exit,res.executed_exit,res.prediction,res.label,res.cycles)!=( -1,-1,-1,-1,0):
            raise FrameError('STATUS must not claim model inference')
    elif res.status == Status.OK:
        if res.admitted_exit < 0 or not (0 <= res.executed_exit <= res.admitted_exit):
            raise FrameError('successful execution violates admitted cap')
        if res.prediction < 0 or res.label < 0 or res.cycles == 0:
            raise FrameError('successful result missing prediction/label/cycles')
    else:
        if (res.admitted_exit, res.executed_exit, res.prediction, res.cycles) != (-1,-1,-1,0):
            raise FrameError('failed/rejected result must not claim executed inference')


def append_crc(prefix: bytes) -> bytes:
    return prefix + struct.pack('<I',zlib.crc32(prefix) & 0xffffffff)


def check_crc(raw: bytes, expected_size: int, magic: bytes) -> None:
    if len(raw) != expected_size or raw[:4] != magic or raw[4] != VERSION:
        raise FrameError('wrong length, magic, or protocol version')
    if zlib.crc32(raw[:-4]) & 0xffffffff != struct.unpack_from('<I',raw, len(raw)-4)[0]:
        raise FrameError('CRC-32 mismatch')


def encode_request(req: Request) -> bytes:
    check_request(req)
    return append_crc(REQUEST.pack(REQUEST_MAGIC, VERSION, int(req.mode), req.fixed_exit, 0,
                                   req.seq, req.input_id, req.budget_q16, req.deadline_cycles,
                                   req.model_id, req.build_id, 0)[:-4])


def decode_request(raw: bytes) -> Request:
    check_crc(raw, REQUEST.size, REQUEST_MAGIC)
    (magic,version,mode,fe,flags,seq,iid,budget,deadline,mid,bid,crc)=REQUEST.unpack(raw)
    if flags != 0:
        raise FrameError('reserved request flags nonzero')
    req=Request(seq,iid,check_mode(mode),fe,budget,deadline,mid,bid)
    check_request(req)
    return req


def encode_response(res: Response) -> bytes:
    check_response(res)
    return append_crc(RESPONSE.pack(RESPONSE_MAGIC,VERSION,int(res.status),int(res.mode),
                                    res.stop_reason,res.seq,res.input_id,res.budget_q16,
                                    res.deadline_cycles,res.admitted_exit,res.executed_exit,
                                    res.prediction,res.label,res.cycles,res.model_id,
                                    res.build_id,res.binding_id,res.flags,0)[:-4])


def decode_response(raw: bytes) -> Response:
    check_crc(raw,RESPONSE.size,RESPONSE_MAGIC)
    (magic,version,status,mode,reason,seq,iid,budget,deadline,admitted,executed,
     pred,label,cycles,mid,bid,binding,flags,crc)=RESPONSE.unpack(raw)
    res=Response(seq,iid,check_mode(mode),check_status(status),reason,budget,deadline,
                 admitted,executed,pred,label,cycles,mid,bid,binding,flags)
    check_response(res)
    return res


if __name__ == '__main__':
    print(f'RTNN experiment wire v1: request={REQUEST.size} response={RESPONSE.size}')
