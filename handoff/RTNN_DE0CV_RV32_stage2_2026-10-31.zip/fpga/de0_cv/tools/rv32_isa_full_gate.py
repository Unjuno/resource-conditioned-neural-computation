#!/usr/bin/env python3
"""Validate real RV32IM machine-code/Q15 decisions on all 360 held-out inputs.

The interpreter models an ideal single-cycle-per-instruction CSR clock and a
logical UART mailbox, NOT the Ibex pipeline or its memory/clock timing. Results
must never be labeled FPGA timing, WCET, or RTL measurements.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
from pathlib import Path
from experiment_wire import Request,Mode,Status,RESPONSE,encode_request,decode_response
from experiment_audit import verified_oracle
from offline_q15_protocol_fixture import EXPECTED_ORACLE_DIGEST

ROOT=Path(__file__).resolve().parents[1]
MODEL=0x52544e4e
BUILD=0x44563032

def sha(raw:bytes)->str:return hashlib.sha256(raw).hexdigest()

def run(binary:Path,emulator:Path,output:Path)->dict:
    dataset=json.loads((ROOT/'generated/heldout360.json').read_text())
    oracle=json.loads((ROOT/'generated/frozen_q15_oracle.json').read_text())
    verified_oracle(oracle,dataset,EXPECTED_ORACLE_DIGEST)
    binary_data=binary.read_bytes()
    manifest=json.loads((binary.parent/'fpga_b_image_manifest.json').read_text())
    if manifest.get('bin_sha256')!=sha(binary_data):
        raise ValueError('compiled B binary SHA does not match build manifest')
    reqs=[]
    for iid in range(360):
        for mode in (Mode.FIXED,Mode.ADAPTIVE):
            reqs.append(Request(seq=len(reqs)+1,input_id=iid,mode=mode,
                   fixed_exit=2 if mode==Mode.FIXED else 0,
                   budget_q16=65535,deadline_cycles=0,
                   model_id=MODEL,build_id=BUILD))
    tx=b''.join(encode_request(req) for req in reqs)
    proc=subprocess.run([str(emulator),str(binary),str(len(reqs))],
                        input=tx,capture_output=True,timeout=120)
    if proc.returncode!=0:
        raise RuntimeError('RV32 interpreter failed: '+proc.stderr.decode(errors='replace'))
    if len(proc.stdout)!=len(reqs)*RESPONSE.size:
        raise ValueError('RV32 simulator returned wrong response count')
    if b'NO_IBEX_CYCLES_NO_FPGA_PROOF' not in proc.stderr:
        raise ValueError('ISA simulator identity/status missing')
    good_fixed=good_adaptive=0
    errors=0
    hist=[0]*7
    for n,q in enumerate(reqs):
        rsp=decode_response(proc.stdout[n*RESPONSE.size:(n+1)*RESPONSE.size])
        ref=oracle['predictions'][str(q.input_id)]
        expected_depth=2 if q.mode==Mode.FIXED else ref['preferred_exit']
        if (rsp.seq,rsp.input_id,rsp.mode,rsp.status,rsp.model_id,rsp.build_id)!=(
            q.seq,q.input_id,q.mode,Status.OK,MODEL,BUILD):
            raise ValueError(f'RV32 response identity/status mismatch at input {q.input_id}')
        if rsp.flags or rsp.admitted_exit!=(2 if q.mode==Mode.FIXED else 6):
            raise ValueError(f'RV32 mode/cap mismatch at input {q.input_id}')
        if rsp.executed_exit!=expected_depth:
            raise ValueError(f'RV32 exit mismatch at input {q.input_id}, mode {q.mode.name}')
        if rsp.prediction!=ref['predictions'][expected_depth]:
            errors+=1
        if rsp.label!=dataset['records'][q.input_id]['label']:
            raise ValueError(f'RV32 input/label mismatch at {q.input_id}')
        if rsp.cycles==0:raise ValueError('missing ISA instruction count proxy')
        if q.mode==Mode.ADAPTIVE:
            hist[expected_depth]+=1
            good_adaptive+=int(rsp.prediction==rsp.label)
        else:good_fixed+=int(rsp.prediction==rsp.label)
    if errors or good_fixed!=339 or good_adaptive!=339 or hist!=[0,263,81,7,2,7,0]:
        raise ValueError('RV32 predictions disagree with pinned Q15 reference')
    output.mkdir(parents=True,exist_ok=False)
    (output/'requests.bin').write_bytes(tx)
    (output/'responses.bin').write_bytes(proc.stdout)
    result={
        'schema':'rtnn-rv32-isa-full-regression-v1',
        'decision':'PASS_ISA_LEVEL_ONLY',
        'hardware':'NONE: instruction-level C++ test interpreter',
        'instruction_clock':'one count per ISA instruction; NOT Ibex mcycle-equivalent',
        'requests_checked':len(reqs),'prediction_mismatches':errors,
        'execution_mismatches':0,'fixed2_correct':good_fixed,
        'adaptive_correct':good_adaptive,'adaptive_exit_histogram':hist,
        'frozen_q15_predictions_sha256':EXPECTED_ORACLE_DIGEST,
        'b_binary_sha256':sha(binary_data),
        'request_stream_sha256':sha(tx),'response_stream_sha256':sha(proc.stdout),
        'not_rtl_or_fpga_timing':True,
        'nonclaims':['No processor-cycle accuracy, no RTL simulation, no FPGA experiment.',
                     'UART mailbox is modeled logically without baudrate or bus stalls.',
                     'This checks byte-exact protocol decisions from an actual RV32 ELF/BIN.']
    }
    (output/'isa_gate.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--binary',type=Path,required=True)
    p.add_argument('--emulator',type=Path,required=True)
    p.add_argument('--out-dir',type=Path,required=True)
    a=p.parse_args()
    try:
        j=run(a.binary,a.emulator,a.out_dir)
    except Exception as e:
        p.exit(2,'RV32_ISA_GATE_FAIL: '+str(e)+'\n')
    print(json.dumps(j,indent=2))
if __name__=='__main__':main()
