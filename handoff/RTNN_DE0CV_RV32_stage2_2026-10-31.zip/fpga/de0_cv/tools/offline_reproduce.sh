#!/usr/bin/env bash
set -euo pipefail
here=$(cd "$(dirname "$0")/.." && pwd)
cd "$here"
mkdir -p evidence
# Exact pinned source C/H is included under upstream/source_repo/experiments/.
bash tools/build_q15_oracle.sh upstream/source_repo | tee evidence/q15_oracle_build_run.log
python3 -m pytest -q tests | tee evidence/pytest_full.log
bash tools/preflight.sh | tee evidence/preflight_final.log
python3 tools/offline_q15_firmware_gate.py --root . --out evidence/native_q15_firmware |
  tee evidence/native_q15_gate_console.log
python3 tools/offline_q15_protocol_fixture.py --root . --out evidence/q15_protocol_smoke |
  tee evidence/q15_wire_smoke.log
python3 tools/offline_manifest.py --root . --out evidence/OFFLINE_PROVENANCE.json > /dev/null
# Absence of EDA tools is a documented barrier, not a failed host test.
if bash tools/toolchain_gate.sh > evidence/toolchain_gate.log 2>&1; then
  echo 'EDA_TOOLS_PRESENT=YES; SYNTHESIS_NOT_AUTOMATICALLY_VALIDATED'
else
  echo 'EDA_TOOLS_PRESENT=NO; RTL_SIMULATION_AND_QUARTUS_NOT_EXECUTED'
fi
echo 'OFFLINE_Q15_CONTROL_AND_DATA_GATES=PASS; FPGA_STATUS=UNVERIFIED'
