#!/usr/bin/env python3
"""Audit physical provenance, retain unfavorable results, export paper tables.

No empirical maximum becomes WCET. No synthetic data enters the paper export.
Physical origin remains an operator-reviewed assertion, not cryptographic
attestation by the FPGA. Inputs previously inspected: this is a case study.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,math,statistics
from collections import defaultdict
from pathlib import Path
from random import Random
from paper_campaign import digest,MEASUREMENT_SCOPE,MODEL_ID,BUILD_ID,DATASET_SHA
from offline_q15_protocol_fixture import EXPECTED_ORACLE_DIGEST
from experiment_audit import audit_trace,load_expected
from experiment_wire import decode_request,decode_response,Mode,Status

class PaperError(ValueError):pass

def read_json(p:Path):return json.loads(p.read_text())
def need(c:bool,message:str):
    if not c:raise PaperError(message)

def verified_file(root:Path,spec:dict)->Path:
    need(isinstance(spec,dict) and isinstance(spec.get('path'),str) and bool(spec['path']),
         'missing evidence file path')
    p=(root/spec['path']).resolve();need(p.is_relative_to(root.resolve()),'evidence path escapes campaign')
    need(p.is_file() and p.stat().st_size>0,f'missing/empty evidence: {spec["path"]}')
    need(hashlib.sha256(p.read_bytes()).hexdigest()==spec.get('sha256'),f'evidence hash mismatch: {spec["path"]}')
    return p

def load_campaign(root:Path)->dict:
    c=read_json(root/'campaign.json');d=dict(c);expected=d.pop('campaign_sha256',None)
    need(digest(d)==expected,'campaign modified after freeze')
    need(c.get('scope')=='EXISTING_METHOD_ONLY' and c.get('primary_sessions')==10,
         'not the frozen existing-method protocol')
    need(c.get('dataset_sha256')==DATASET_SHA and c.get('q15_predictions_sha256')==EXPECTED_ORACLE_DIGEST,
         'wrong dataset/oracle identity')
    need(c.get('model_id')==MODEL_ID and c.get('expected_build_id')==BUILD_ID and c.get('binding_id')==0,
         'wrong prototype model/build/binding marker')
    need(c.get('measurement_scope')==MEASUREMENT_SCOPE and c.get('batch_size')==1,
         'measurement scope/batch differs')
    return c

def load_hardware(root:Path)->dict:
    h=read_json(root/'hardware_review.json')
    need(h.get('schema')=='rtnn-existing-hardware-review-v1' and
         h.get('status')=='OPERATOR_REVIEWED_FOR_EMPIRICAL_RUN', 'hardware review is pending')
    for k in ('board_identifier','pcb_revision','reviewer','reviewed_at_utc','clock_source_and_tolerance'):
        need(isinstance(h.get(k),str) and bool(h[k].strip()),f'hardware review missing {k}')
    need(h.get('board_model')=='DE0-CV' and h.get('fpga_part')=='5CEBA4F23C7N','wrong hardware target')
    need(h.get('model_id')==MODEL_ID and h.get('build_id')==BUILD_ID and h.get('binding_id')==0,
         'wrong hardware model/build/binding')
    need(h.get('measurement_scope')==MEASUREMENT_SCOPE,'hardware measurement scope mismatch')
    need(type(h.get('clock_hz')) is int and 0<h['clock_hz']<=100000000,'invalid declared clock')
    gates=['rtl_units','soc_original_42','sv2v_regression','rv32_b_model_equivalence',
           'fitter_fit','ram_placement_latency','setup_hold_recovery_removal',
           'no_unreviewed_unconstrained_paths','no_interrupt_dma_debug_contention',
           'b_bitstream_programming_verified']
    need(all(h.get('gates',{}).get(g) is True for g in gates),'hardware evidence gates incomplete')
    need(all(isinstance(h.get('tools',{}).get(t),str) and h['tools'][t].strip()
             for t in ('quartus','verilator','sv2v','riscv_gcc')),'missing tool versions')
    for key in ['sof','firmware_elf','firmware_bin','ram_hex','converted_rtl','rtl_sources_lock',
                'qsf','sdc','fitter_report','sta_report','programming_log','rtl_unit_log','soc42_log',
                'sv2v_comparison','rv32_b_equivalence_log']:
        verified_file(root,h.get('files',{}).get(key))
    need(h.get('uart_logic_voltage_v')==3.3 and h.get('uart_baud')==115200,'unreviewed UART setting')
    return h

def require_physical_trace(t:dict)->None:
    need(t.get('origin')=='fpga_de0cv','physical trace required; synthetic/RTL/host data prohibited')
    need(t.get('status')=='CAPTURE_COMPLETE_UNAUDITED','capture incomplete; preserve as failure evidence')

def primary_metrics(rows:list[dict],bootstrap_samples:int=5000,seed:int=63)->dict:
    need(bool(rows),'no paired observations')
    need(type(bootstrap_samples) is int and bootstrap_samples>=100,'invalid bootstrap count')
    by_session=defaultdict(dict)
    for r in rows:
        sid=r.get('session_id');iid=r.get('input_id')
        need(isinstance(sid,str) and bool(sid) and type(iid) is int and iid>=0,'invalid pair identity')
        need(iid not in by_session[sid],'duplicate session/input pair')
        for k in ('fixed2_cycles','adaptive_cycles'):
            need(type(r.get(k)) is int and 0<r[k]<2**32,'invalid cycle count')
        for k in ('fixed2_correct','adaptive_correct'):
            need(type(r.get(k)) is int and r[k] in (0,1),'invalid correctness')
        by_session[sid][iid]=r
    sessions=sorted(by_session);ids=sorted(by_session[sessions[0]])
    need(all(set(by_session[s])==set(ids) for s in sessions),'missing paired input in session')
    fixed=[];adaptive=[];delta=[];fc=[];ac=[];boot_stats=[]
    for iid in ids:
        rs=[by_session[s][iid] for s in sessions]
        need(len({(r['fixed2_correct'],r['adaptive_correct']) for r in rs})==1,
             'prediction/correctness instability across repeated same input')
        fixed.append(statistics.mean(r['fixed2_cycles'] for r in rs))
        adaptive.append(statistics.mean(r['adaptive_cycles'] for r in rs))
        fc.append(rs[0]['fixed2_correct']);ac.append(rs[0]['adaptive_correct']);delta.append(ac[-1]-fc[-1])
    for s in sessions:
        r=list(by_session[s].values())
        boot_stats.append({'session_id':s,'mean_cycle_saving':statistics.mean(x['fixed2_cycles']-x['adaptive_cycles'] for x in r),
                           'mean_fixed2_cycles':statistics.mean(x['fixed2_cycles'] for x in r),
                           'mean_adaptive_cycles':statistics.mean(x['adaptive_cycles'] for x in r)})
    savings=[f-a for f,a in zip(fixed,adaptive)]
    rng=Random(seed);bs=[];ba=[];n=len(ids)
    for _ in range(bootstrap_samples):
        idx=[rng.randrange(n) for _ in ids]
        bs.append(sum(savings[i] for i in idx)/n);ba.append(100*sum(delta[i] for i in idx)/n)
    def interval(v):
        v.sort();return [v[int(.025*len(v))],v[min(len(v)-1,int(.975*len(v)))]]
    ci=interval(bs);ai=interval(ba);sf=1-statistics.mean(adaptive)/statistics.mean(fixed)
    if statistics.mean(savings)<=0:decision='NO_SPEEDUP_OBSERVED'
    elif ci[0]<=0:decision='TIMING_UNCERTAIN'
    elif sf<.05:decision='POSITIVE_BUT_BELOW_5_PERCENT_PRACTICAL_THRESHOLD'
    else:decision='CYCLE_REDUCTION_SUPPORTED_ON_THIS_CASE_STUDY'
    return {'unique_inputs':n,'accuracy_denominator':n,'sessions':len(sessions),'timing_pairs':len(rows),
      'mean_fixed2_cycles':statistics.mean(fixed),'mean_adaptive_cycles':statistics.mean(adaptive),
      'median_fixed2_cycles':statistics.median(fixed),'median_adaptive_cycles':statistics.median(adaptive),
      'mean_cycle_saving':statistics.mean(savings),'cycle_saving_fraction':sf,
      'cycle_speedup_ratio':statistics.mean(fixed)/statistics.mean(adaptive),
      'fixed2_accuracy':sum(fc)/n,'adaptive_accuracy':sum(ac)/n,'accuracy_delta_pp':100*sum(delta)/n,
      'adaptive_only_correct':sum(a and not f for a,f in zip(ac,fc)),
      'fixed2_only_correct':sum(f and not a for a,f in zip(ac,fc)),
      'mean_cycle_saving_ci95':ci,'accuracy_delta_pp_ci95':ai,
      'accuracy_noninferiority_1pp':'SUPPORTED_CONDITIONALLY' if ai[0]>=-1 else 'INCONCLUSIVE',
      'bootstrap_seed':seed,'bootstrap_samples':bootstrap_samples,
      'interval_scope':'paired input-level percentile interval, session means; no new independent samples from repeats',
      'performance_decision':decision,'boot_session_summaries':boot_stats,
      'session_mean_saving_range':[min(x['mean_cycle_saving'] for x in boot_stats),max(x['mean_cycle_saving'] for x in boot_stats)],
      'observed_max_fixed2_cycles':max(r['fixed2_cycles'] for r in rows),
      'observed_max_adaptive_cycles':max(r['adaptive_cycles'] for r in rows),
      'new_generalization_proven':False,'hard_wcet_proven':False}

def load_session(root:Path,sid:str,hardware:dict)->dict:
    s=read_json(root/f'sessions/{sid}.json')
    need(s.get('session_id')==sid and s.get('status')=='READY_FOR_ACQUISITION','session review incomplete')
    need(s.get('cold_boot_confirmed') is True,'cold boot not confirmed')
    for k in ['boot_id','operator','started_at_utc']:
        need(isinstance(s.get(k),str) and bool(s[k].strip()),f'session missing {k}')
    need(s.get('board_identifier')==hardware['board_identifier'],'session board identity mismatch')
    verified_file(root,s.get('programming_log'))
    return s

def export_results(code_root:Path,campaign_root:Path,out:Path)->dict:
    need(not out.exists(),'report destination exists; refusing overwrite')
    c=load_campaign(campaign_root);h=load_hardware(campaign_root)
    ds=read_json(code_root/'generated/heldout360.json');oracle=read_json(code_root/'generated/frozen_q15_oracle.json')
    need(hashlib.sha256((code_root/'generated/heldout360.json').read_bytes()).hexdigest()==c['dataset_file_sha256'],
         'dataset file changed')
    all_rows=[];pairs=[];audits=[];boot_ids=set();records=[]
    for entry in c['schedules']:
        sid=entry['session_id'];s=load_session(campaign_root,sid,h)
        m=read_json(campaign_root/entry['matrix']);load_expected(m,ds)
        need(m['schedule_sha256']==entry['schedule_sha256'] and len(m['rows'])==entry['record_count'],
             'schedule changed')
        tpath=campaign_root/f'captures/{sid}.json';t=read_json(tpath);require_physical_trace(t)
        need(t.get('campaign_sha256')==c['campaign_sha256'] and t.get('session_id')==sid,
             'capture campaign/session identity differs')
        need(t.get('hardware_review_sha256')==hashlib.sha256((campaign_root/'hardware_review.json').read_bytes()).hexdigest(),
             'hardware review changed since acquisition')
        need(t.get('session_review_sha256')==hashlib.sha256((campaign_root/f'sessions/{sid}.json').read_bytes()).hexdigest(),
             'session review changed since acquisition')
        rawfile=verified_file(campaign_root,t.get('wire_journal'))
        events=[json.loads(line) for line in rawfile.read_text().splitlines() if line]
        need(len(events)==len(t['rows']) and all(e.get('status')=='DECODED_IDENTITY_MATCHED' for e in events),
             'failed/truncated/missing raw transactions; do not silently remove')
        need(all(e['request_hex']==r['request_hex'] and e['response_hex']==r['response_hex'] for e,r in zip(events,t['rows'])),
             'raw UART journal differs from parsed capture')
        need([decode_request(bytes.fromhex(r['request_hex'])).seq for r in t['rows']]==
             [r['seq'] for r in m['rows']], 'actual acquisition order differs from frozen schedule order')
        a=audit_trace(t,m,ds,expected_sof_sha256=h['files']['sof']['sha256'],expected_build_id=h['build_id'],
                     expected_binding_id=0,q15_oracle=oracle,expected_q15_predictions_sha256=EXPECTED_ORACLE_DIGEST)
        audits.append({'session_id':sid,'audit':a});records.append({'session_id':sid,'trace_sha256':hashlib.sha256(tpath.read_bytes()).hexdigest()})
        grouped=defaultdict(dict)
        for raw in t['rows']:
            q=decode_request(bytes.fromhex(raw['request_hex']));r=decode_response(bytes.fromhex(raw['response_hex']))
            need(q.model_id==MODEL_ID and r.model_id==MODEL_ID,'wrong model ID')
            need(r.status==Status.OK and q.mode in (Mode.FIXED,Mode.CAPPED_NO_STOP,Mode.ADAPTIVE),
                 'unsupported mode/status in existing-method campaign')
            label=ds['records'][q.input_id]['label']
            row={'session_id':sid,'input_id':q.input_id,'mode':q.mode.name,'fixed_exit':q.fixed_exit,
                 'budget_q16':q.budget_q16,'admitted_exit':r.admitted_exit,'executed_exit':r.executed_exit,
                 'prediction':r.prediction,'label':label,'correct':int(r.prediction==label),
                 'cycles':r.cycles,'stop_reason':r.stop_reason,'sequence':q.seq}
            all_rows.append(row)
            if entry['purpose']=='PRIMARY_PAIRED':
                key='fixed2' if q.mode==Mode.FIXED and q.fixed_exit==2 else 'adaptive'
                need(key not in grouped[q.input_id],'duplicate primary pair mode')
                grouped[q.input_id][key]=row
        if entry['purpose']=='PRIMARY_PAIRED':
            need(s['boot_id'] not in boot_ids,'primary sessions must have distinct boot IDs');boot_ids.add(s['boot_id'])
            need(len(grouped)==360,'primary must include all 360 inputs')
            for iid,parts in sorted(grouped.items()):
                need(set(parts)=={'fixed2','adaptive'},'primary pair missing mode')
                pairs.append(dict(session_id=sid,input_id=iid,fixed2_cycles=parts['fixed2']['cycles'],
                    adaptive_cycles=parts['adaptive']['cycles'],fixed2_correct=parts['fixed2']['correct'],
                    adaptive_correct=parts['adaptive']['correct']))
    need(len(boot_ids)==10,'ten primary boots required')
    metrics=primary_metrics(pairs,c['bootstrap']['samples'],c['bootstrap']['seed'])
    groups=defaultdict(list)
    for r in all_rows:
        if r['session_id'].startswith('diagnostic_'):
            groups[(r['mode'],r['fixed_exit'] if r['mode']=='FIXED' else r['budget_q16'])].append(r)
    summary=[]
    for (mode,control),rs in sorted(groups.items()):
        summary.append({'mode':mode,'control':control,'n_inputs':len(rs),
           'accuracy':statistics.mean(r['correct'] for r in rs),
           'mean_executed_blocks':statistics.mean(r['executed_exit'] for r in rs),
           'mean_cycles':statistics.mean(r['cycles'] for r in rs),'median_cycles':statistics.median(r['cycles'] for r in rs),
           'min_cycles':min(r['cycles'] for r in rs),'max_observed_cycles':max(r['cycles'] for r in rs)})
    report={'schema':'rtnn-existing-method-paper-results-v1','status':'PHYSICAL_RECORDS_AUDITED_OPERATOR_REVIEWED',
      'campaign_sha256':c['campaign_sha256'],'hardware_review_sha256':hashlib.sha256((campaign_root/'hardware_review.json').read_bytes()).hexdigest(),
      'measurement_scope':MEASUREMENT_SCOPE,'clock_hz_declared':h['clock_hz'],'board_identifier':h['board_identifier'],
      'physical_attestation':'NOT_CRYPTOGRAPHIC;operator/programming evidence required',
      'primary':metrics,'secondary':summary,'source_traces':records,'audits':audits,
      'limitations':['One frozen model, one board and previously inspected 360-input benchmark.',
       'Repeated boot sessions do not increase accuracy sample size.',
       'UART/queueing excluded; no end-to-end communication deadline claim.',
       'No enforced deadline trial in this B build.','Observed cycle maxima are not WCET bounds.']}
    out.mkdir(parents=True)
    def csv_write(name,rows):
        with (out/name).open('x',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    csv_write('per_request.csv',all_rows);csv_write('paired_by_input_session.csv',pairs);csv_write('fixed_and_budget_frontiers.csv',summary)
    report['derived_file_sha256']={name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in
      ('per_request.csv','paired_by_input_session.csv','fixed_and_budget_frontiers.csv')}
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
    (out/'RESULTS.md').write_text('# 実機測定結果 — 既存方式\n\n'
      f"- データ判定: {report['status']}\n- unique入力: {metrics['unique_inputs']}、起動セッション: {metrics['sessions']}\n"
      f"- 固定2/適応 mean cycles: {metrics['mean_fixed2_cycles']} / {metrics['mean_adaptive_cycles']}\n"
      f"- 平均cycle削減: {metrics['mean_cycle_saving']}、95%区間: {metrics['mean_cycle_saving_ci95']}\n"
      f"- 正答率差(pp): {metrics['accuracy_delta_pp']}、95%区間: {metrics['accuracy_delta_pp_ci95']}\n"
      f"- 性能の判定: {metrics['performance_decision']}\n- 1pp非劣性: {metrics['accuracy_noninferiority_1pp']}\n\n"
      '速度優位がない結果も有効な研究結果です。最大観測値はWCETではありません。\n')
    return report

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--campaign',type=Path,required=True);p.add_argument('--out',type=Path);p.add_argument('--check-only',action='store_true');a=p.parse_args()
    try:
        if a.check_only:
            load_campaign(a.campaign);load_hardware(a.campaign);print('OPERATOR_REVIEW_AND_FILES_COMPLETE_NOT_WCET')
        else:
            if a.out is None:raise PaperError('--out required')
            r=export_results(a.root,a.campaign,a.out);print(r['status'],r['primary']['performance_decision'])
    except (ValueError,KeyError,OSError) as e:p.exit(2,f'PAPER_DATA_BLOCKED: {e}\n')
if __name__=='__main__':main()
