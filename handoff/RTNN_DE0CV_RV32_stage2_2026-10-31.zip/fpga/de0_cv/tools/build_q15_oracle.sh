#!/usr/bin/env bash
# Build native, complete seed-63 Q15 prediction oracle from the pinned source.
set -euo pipefail
if (($# != 1)); then echo 'usage: build_q15_oracle.sh /path/to/resource-conditioned-neural-computation' >&2; exit 2; fi
here=$(cd "$(dirname "$0")/.." && pwd)
repo=$(cd "$1" && pwd)
command -v gcc >/dev/null || { echo 'native GCC missing' >&2; exit 2; }
command -v git >/dev/null || exit 2
command -v unzip >/dev/null || exit 2
base="$repo/experiments/realtime_nn_real_sequence_fixed_core"
[[ -f "$base.c" && -f "$base.h" ]] || { echo 'missing original fixed Q15 C source' >&2; exit 2; }
[[ "$(git hash-object "$base.c")" == '3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a' ]] || { echo 'core C blob differs from reviewed main' >&2; exit 2; }
[[ "$(git hash-object "$base.h")" == 'ac185458e21b956db01cb18504bdb507c0c69618' ]] || { echo 'core H blob differs from reviewed main' >&2; exit 2; }
mkdir -p "$here/build/q15" "$here/generated"
unzip -p "$here/artifacts/rtnn_ibex_rtl_exact.zip" \
  rtnn/realtime_nn_real_sequence_fixed_weights_generated.h \
  > "$here/build/q15/realtime_nn_real_sequence_fixed_weights_generated.h"
[[ "$(sha256sum "$here/build/q15/realtime_nn_real_sequence_fixed_weights_generated.h" | cut -d' ' -f1)" == '961a76b7e220bf2f665e7c04ab62063600aa2e7eccf3403d80ea730bc993ad9f' ]] || { echo 'wrong frozen header' >&2; exit 2; }
python3 "$here/tools/experiment_dataset.py" \
 --preflight "$here/quartus/preflight_reference.json" \
 --out "$here/generated/heldout360.json" \
 --c-header "$here/generated/heldout360.h"
gcc -O2 -std=c11 -Wall -Wextra -I"$repo/experiments" -I"$here/generated" -I"$here/build/q15" \
    "$base.c" "$here/firmware/rtnn_host_model_reference.c" \
    -o "$here/build/q15/host_q15_reference"
"$here/build/q15/host_q15_reference" > "$here/build/q15/full_q15_reference.csv"
python3 "$here/tools/verify_q15_oracle.py" \
 --csv "$here/build/q15/full_q15_reference.csv" \
 --dataset "$here/generated/heldout360.json" \
 --preflight "$here/quartus/preflight_reference.json" \
 --out "$here/generated/frozen_q15_oracle.json"
printf 'NATIVE_Q15_ORACLE_VERIFIED (not FPGA measurements)\n'
