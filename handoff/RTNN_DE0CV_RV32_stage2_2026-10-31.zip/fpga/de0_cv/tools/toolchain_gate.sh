#!/usr/bin/env bash
set -u
status=0
for cmd in sv2v verilator quartus_sh quartus_sta quartus_cpf git sha256sum python3; do
  if command -v "$cmd" >/dev/null; then
    echo "PRESENT $cmd $(command -v "$cmd")"
  else
    echo "MISSING $cmd"
    status=1
  fi
done
if [ "$status" -ne 0 ]; then
  echo "TOOLCHAIN_GATE=BLOCKED (no synthesized/RTL-cycle equivalence evidence)"
else
  echo "TOOLCHAIN_GATE=AVAILABLE (not proof of build success)"
fi
exit "$status"
