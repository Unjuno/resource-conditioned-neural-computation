#!/usr/bin/env bash
# Host-only gate: cross compile actual B firmware, then validate all 720
# fixed2/adaptive requests in an ISA interpreter. NO RTL/FPGA timing evidence.
set -euo pipefail
if (($# != 1)); then
  echo 'usage: run_rv32_gate.sh NEW_OUTPUT_DIRECTORY' >&2; exit 2
fi
here=$(cd "$(dirname "$0")/.." && pwd)
out="$1"
[[ ! -e "$out" ]] || { echo "Refusing to overwrite: $out" >&2; exit 2; }
for tool in clang ld.lld llvm-objcopy readelf g++ python3; do
  command -v "$tool" >/dev/null || { echo "Missing $tool" >&2; exit 2; }
done
mkdir -p "$out"
bash "$here/tools/build_b_firmware_clang.sh" "$out/fpga_b" \
     "$here/upstream/source_repo" | tee "$out/compile_result.log"
g++ -O3 -std=c++17 -Wall -Wextra "$here/tools/rtnn_rv32_isa_smoke.cpp" \
     -o "$out/simulator"
python3 "$here/tools/rv32_isa_full_gate.py" \
    --binary "$out/fpga_b/rtnn_experiment.bin" \
    --emulator "$out/simulator" --out-dir "$out/isa_720" | tee "$out/isa_720_result.log"
cat > "$out/README.status" <<'STATUS'
PASS_ISA_LEVEL_ONLY
NO_IBEX_CYCLES_NO_FPGA_PROOF
Generated RV32 program and 720 byte-exact Q15 decisions were checked with
an unverified software ISA interpreter and ideal MMIO model. This is not
Verilator RTL, Quartus, FPGA timing, WCET or a silicon guarantee.
STATUS
