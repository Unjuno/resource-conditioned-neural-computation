#!/usr/bin/env python3
"""Fail-closed preparation of the exact August-2026 Ibex RTNN machine image.

No retraining or rebuilding of the software is necessary for the first FPGA
bring-up. A 32-KiB alias maps the frozen ELF's original 1-MiB RAM top stack
into the physical top of a 256-KiB on-chip RAM. This is a *new target*.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import struct
import zipfile
from pathlib import Path

ZIP_SHA = '9150b0763e5d7b7c305441befdb4161ccf95612edd924b525f8388e06d9a86b0'
ELF_SHA = '234a7f46cf227a11f5d97f3c778cbb0c4ed4f7067f8994bcca86c4b08ff4e742'
BIN_SHA = '266ecb70c723b2164f6fe9039f27d4cb49c4d7271d4aca0cf69f2692cdfdf7a1'
IBEX_SHA = '7b5df75a041affe56e8c235260f98a09b3319008'
RAM_BASE = 0x00100000
RAM_BYTES = 256 * 1024
ALIAS_START = 0x001f8000
ALIAS_BYTES = 32 * 1024
STACK_TOP = 0x001ffff0
ENTRY = 0x00100080
ROM_SAFE_LIMIT = RAM_BASE + RAM_BYTES - ALIAS_BYTES


class InvalidArtifact(ValueError):
    pass


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise InvalidArtifact(message)


def map_address(addr: int) -> int:
    """Map a byte address to an offset in physically implemented RAM."""
    if RAM_BASE <= addr < RAM_BASE + RAM_BYTES:
        return addr - RAM_BASE
    if ALIAS_START <= addr < ALIAS_START + ALIAS_BYTES:
        return RAM_BYTES - ALIAS_BYTES + addr - ALIAS_START
    raise InvalidArtifact(f'address not in certified RAM/stack alias: 0x{addr:08x}')


def elf_details(elf: bytes, binary: bytes) -> dict:
    require(len(elf) >= 52 and elf[:4] == b'\x7fELF', 'not ELF')
    require(elf[4] == 1 and elf[5] == 1, 'only little-endian ELF32 supported')
    (ident, typ, machine, version, entry, phoff, shoff, flags,
     ehsize, phentsize, phnum, shentsize, shnum, shstrndx) = struct.unpack_from('<16sHHIIIIIHHHHHH', elf)
    require(typ == 2 and machine == 243 and version == 1, 'not RV32 executable')
    require(entry == ENTRY, 'unexpected entry point')
    require(phentsize >= 32 and phnum >= 1, 'invalid program header table')
    require(phoff + phnum * phentsize <= len(elf), 'program header out of bounds')
    loads = []
    for i in range(phnum):
        ph = struct.unpack_from('<IIIIIIII', elf, phoff + i*phentsize)
        p_type, p_offset, p_va, p_pa, p_fs, p_ms, p_flags, p_align = ph
        if p_type == 1:
            loads.append((p_offset, p_va, p_pa, p_fs, p_ms))
    require(len(loads) == 1, 'expected exactly one PT_LOAD segment')
    p_offset, p_va, p_pa, p_fs, p_ms = loads[0]
    require(p_va == RAM_BASE and p_pa == RAM_BASE, 'unexpected ELF load base')
    require(p_offset + p_fs <= len(elf), 'PT_LOAD exceeds ELF data')
    require(p_ms >= p_fs > 0, 'invalid filesz/memsz')
    require(p_fs == len(binary) and elf[p_offset:p_offset+p_fs] == binary,
            'BIN does not exactly match ELF PT_LOAD')
    require(p_pa + p_ms <= ROM_SAFE_LIMIT,
            'image/bss overlaps reserved physical stack region')
    # Validate __stack_top as a *linker symbol*; not merely an assumption.
    require(shentsize >= 40 and shoff + shnum*shentsize <= len(elf), 'bad section header table')
    secs = [struct.unpack_from('<IIIIIIIIII', elf, shoff + i*shentsize) for i in range(shnum)]
    symbols = {}
    for sec in secs:
        name, shtype, sflags, saddr, offset, size, link, info, align, entsize = sec
        if shtype != 2:  # SYMTAB
            continue
        require(link < len(secs), 'invalid section string table index')
        strsec = secs[link]
        stroff, strlen = strsec[4], strsec[5]
        require(stroff + strlen <= len(elf), 'string table out of bounds')
        strings = elf[stroff:stroff+strlen]
        require(entsize >= 16 and offset + size <= len(elf), 'symbol table out of bounds')
        for so in range(offset, offset + size, entsize):
            n, val, sym_size, info, other, shndx = struct.unpack_from('<IIIBBH', elf, so)
            if n < len(strings):
                end = strings.find(b'\x00', n)
                if end < 0:
                    continue
                sy = strings[n:end].decode('utf-8', errors='replace')
                symbols[sy] = val
    require(symbols.get('__stack_top') == STACK_TOP, 'expected frozen stack-top symbol missing')
    require(symbols.get('__image_end') == (p_pa + p_ms + 15) & ~15,
            '__image_end differs from aligned end of PT_LOAD memsz')
    # Map stack top and base explicitly and assert no overlap with data.
    require(map_address(STACK_TOP) == RAM_BYTES - 16, 'stack alias top does not match')
    require(map_address(ALIAS_START) == RAM_BYTES - ALIAS_BYTES, 'stack alias start does not match')
    return {
        'entry': entry, 'load_vaddr': p_va, 'load_paddr': p_pa,
        'load_file_bytes': p_fs, 'load_mem_bytes': p_ms,
        'image_end': p_pa+p_ms, 'stack_top': symbols['__stack_top'],
        'physical_ram_bytes': RAM_BYTES, 'stack_alias_start': ALIAS_START,
        'stack_alias_bytes': ALIAS_BYTES, 'physical_stack_offset': RAM_BYTES-ALIAS_BYTES,
    }


def parse_int_list(raw: str) -> list[int]:
    return [int(x.strip()) for x in raw.split(',') if x.strip()]


def derive_reference(header: str, validation: dict) -> dict:
    idx = re.search(r'RTNN_RTL_TEST_INDEX\[[^]]+\]=\{([^}]*)\}', header)
    lab = re.search(r'RTNN_RTL_LABEL\[[^]]+\]=\{([^}]*)\}', header)
    body = re.search(r'RTNN_RTL_X\[[^]]+\]\[64\]=\{(.*)\};', header, re.S)
    require(idx is not None and lab is not None and body is not None, 'header vector layout changed')
    indices = parse_int_list(idx.group(1))
    labels = parse_int_list(lab.group(1))
    inputs = [parse_int_list(s) for s in re.findall(r'\{([^{}]+)\}', body.group(1))]
    require(len(indices) == len(labels) == len(inputs) == 3, 'not three frozen vectors')
    require(all(len(x) == 64 and all(type(z) is int and 0 <= z <= 255 for z in x) for x in inputs),
            'invalid image vectors')
    preds = {i: {} for i in range(3)}
    rows = validation['certification_rows']
    require(len(rows) == 21, 'certification rows must be exactly 21')
    for row in rows:
        s = int(row['slot']); c = int(row['class'])
        require(s in preds and c in range(7) and c not in preds[s], 'bad/duplicate certified row')
        preds[s][c] = int(row['pred'])
    pref = validation['host_preferred_by_slot']
    vectors = []
    for s in range(3):
        require(set(preds[s]) == set(range(7)), 'missing certified class')
        preferred = int(pref[str(s)])
        require(preferred in range(6), 'unsupported preferred exit')
        vectors.append({'slot': s, 'test_index': indices[s], 'label': labels[s],
                        'preferred_exit': preferred, 'input_u8_64': inputs[s],
                        'expected_fixed_class_prediction': [preds[s][c] for c in range(7)]})
    return {'schema': 'rtnn-de0-cv-preflight-v1',
            'status': 'BOARD_FREE_REFERENCE_ONLY',
            'source_artifact': {'frozen_zip_sha256': ZIP_SHA, 'elf_sha256': ELF_SHA, 'bin_sha256': BIN_SHA},
            'finite_classes': list(range(7)),
            'normalized_classes': [0., 1/6, 2/6, 3/6, 4/6, 5/6, 1.],
            'vectors': vectors,
            'nonclaims': ['No DE0-CV measurement has been performed.',
                          'Simple-System cycle counts are intentionally omitted; the FPGA must derive a new target-specific timing table.',
                          'These vectors validate prediction/class behavior, not physical WCET by themselves.']}


def build(archive: Path, out_dir: Path) -> dict:
    raw = archive.read_bytes()
    require(digest(raw) == ZIP_SHA, 'frozen archive SHA-256 mismatch')
    with zipfile.ZipFile(archive) as z:
        binary = z.read('rtnn_ibex_rtl.bin')
        elf = z.read('rtnn_ibex_rtl.elf')
        head = z.read('rtnn/realtime_nn_ibex_rtl_vectors_generated.h').decode('utf-8')
        valid = json.loads(z.read('realtime_nn_ibex_rtl_validation_results.json'))
    require(digest(binary) == BIN_SHA, 'frozen BIN SHA-256 mismatch')
    require(digest(elf) == ELF_SHA, 'frozen ELF SHA-256 mismatch')
    info = elf_details(elf, binary)
    ref = derive_reference(head, valid)
    out_dir.mkdir(parents=True, exist_ok=True)
    # $readmemh produces exact machine little-endian 32-bit words for Ibex.
    image = bytearray(RAM_BYTES)
    image[:len(binary)] = binary
    hexdata = ''.join(f'{int.from_bytes(image[i:i+4], "little"):08x}\n' for i in range(0, RAM_BYTES, 4))
    hexpath = out_dir/'rtnn_ram_words.hex'
    hexpath.write_text(hexdata, encoding='ascii')
    # MIF for optional audited altsyncram primitive integration.
    mif = ['WIDTH=32;', 'DEPTH=65536;', 'ADDRESS_RADIX=HEX;', 'DATA_RADIX=HEX;',
           'CONTENT BEGIN', '  [0000..FFFF] : 00000000;']
    # Non-overlapping assignments: some Quartus MIF parsers reject overlap.
    loaded_words = (len(binary)+3)//4
    mif.pop()  # replace full-depth range with exact populated prefix + zero suffix
    for index in range(loaded_words):
        v = int.from_bytes(image[4*index:4*index+4], 'little')
        mif.append(f'  {index:04X} : {v:08X};')
    if loaded_words < 65536:
        mif.append(f'  [{loaded_words:04X}..FFFF] : 00000000;')
    mif.append('END;')
    (out_dir/'rtnn_ram_words.mif').write_text('\n'.join(mif)+'\n', encoding='ascii')
    (out_dir/'preflight_reference.json').write_text(json.dumps(ref, indent=2)+'\n')
    build_manifest = {
        'schema': 'rtnn-de0-cv-frozen-image-v1', 'status': 'PREPARED_NOT_SYNTHESIZED',
        'ibex_commit': IBEX_SHA,
        'artifact_sha256': ZIP_SHA, 'elf_sha256': ELF_SHA, 'bin_sha256': BIN_SHA,
        'ram_hex_sha256': digest(hexdata.encode('ascii')),
        'address_map': {'ram_start':f'0x{RAM_BASE:08x}', 'ram_bytes': RAM_BYTES,
                        'stack_virtual_start':f'0x{ALIAS_START:08x}', 'stack_bytes':ALIAS_BYTES,
                        'stack_physical_start':f'0x{RAM_BASE+RAM_BYTES-ALIAS_BYTES:08x}',
                        'mmio_uart': '0x00020000', 'mmio_halt': '0x00020008'},
        'elf': info,
        'nonclaim': 'This is the original verified binary with a NEW FPGA RAM alias; RTL/Quartus/board behavior must be revalidated.'}
    (out_dir/'frozen_image_manifest.json').write_text(json.dumps(build_manifest, indent=2)+'\n')
    return build_manifest


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--artifact', required=True, type=Path)
    p.add_argument('--out-dir', required=True, type=Path)
    a = p.parse_args()
    try:
        out = build(a.artifact, a.out_dir)
    except (InvalidArtifact, ValueError, KeyError, zipfile.BadZipFile) as e:
        p.error(str(e))
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main()
