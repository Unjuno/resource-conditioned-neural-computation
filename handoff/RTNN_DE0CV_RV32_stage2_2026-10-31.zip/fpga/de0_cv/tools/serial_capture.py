#!/usr/bin/env python3
"""Capture unmodified 8N1 UART bytes until DONE; no implicit PASS claims.

Requires pyserial and an external 3.3-V TTL serial adapter at the GPIO pin.
Start the capture before releasing KEY[0] reset. This only binds the capture
bytes to host metadata, not cryptographically to the deployed FPGA bitstream.
"""
import argparse
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--port',required=True)
    ap.add_argument('--baud',type=int,default=115200)
    ap.add_argument('--timeout-s',type=float,default=120.0)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--expected-sof',type=Path,help='optional host-side SOF hash (NOT board attestation)')
    args=ap.parse_args()
    if args.baud <= 0 or args.timeout_s<=0: ap.error('invalid baud/timeout')
    try:
        import serial
    except ImportError:
        ap.error('pyserial missing; install pyserial for board capture')
    began=datetime.now(timezone.utc).isoformat()
    started=time.monotonic()
    lines=[]; buffer=bytearray(); ended=False
    with serial.Serial(args.port,baudrate=args.baud,timeout=0.5,bytesize=8,
                       parity='N',stopbits=1) as port:
        while time.monotonic()-started < args.timeout_s and not ended:
            chunk=port.read(512)
            buffer.extend(chunk)
            if len(buffer)>256*1024:
                ap.error('capture exceeded 256 KiB; refusing unbounded capture')
            while b'\n' in buffer:
                head,_,tail=buffer.partition(b'\n')
                buffer=bytearray(tail)
                line=head.rstrip(b'\r')+b'\n'
                lines.append(line)
                if line==b'DONE\n': ended=True; break
    if not ended:
        ap.error('no complete DONE terminal marker received; not writing success capture')
    raw=b''.join(lines)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_bytes(raw)
    evidence={
        'schema':'rtnn-de0-cv-host-capture-v1','status':'CAPTURED_NOT_VERIFIED',
        'start_utc':began,'end_utc':datetime.now(timezone.utc).isoformat(),
        'serial_port_reported':args.port,'baud':args.baud,
        'raw_capture_bytes':len(raw),'uart_log_sha256':hashlib.sha256(raw).hexdigest(),
        'host_supplied_sof_sha256': (
            hashlib.sha256(args.expected_sof.read_bytes()).hexdigest() if args.expected_sof else None),
        'hardware_bitstream_attestation':None,
        'nonclaim':'Host-provided SOF hash cannot prove which bitstream was on the board.'}
    (args.out.with_suffix(args.out.suffix+'.host.json')).write_text(json.dumps(evidence,indent=2)+'\n')
    print(json.dumps(evidence,indent=2))
if __name__=='__main__': main()
