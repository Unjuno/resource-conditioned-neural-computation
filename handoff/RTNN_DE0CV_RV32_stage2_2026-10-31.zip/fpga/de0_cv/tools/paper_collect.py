#!/usr/bin/env python3
"""One reviewed session per call; no overwrites, no hidden replay, durable UART journal."""
from __future__ import annotations
import argparse,hashlib,json,os
from pathlib import Path
from paper_results import load_campaign,load_hardware,load_session,verified_file,need
from paper_campaign import MODEL_ID,BUILD_ID
from experiment_driver import Session
from experiment_audit import load_expected
from experiment_wire import Request,Mode,Status

def collect(code_root:Path,campaign_root:Path,session_id:str,port:str)->dict:
    c=load_campaign(campaign_root);h=load_hardware(campaign_root)
    entries={x['session_id']:x for x in c['schedules']};need(session_id in entries,'unknown planned session')
    e=entries[session_id];s=load_session(campaign_root,session_id,h)
    m=json.loads((campaign_root/e['matrix']).read_text());ds=json.loads((code_root/'generated/heldout360.json').read_text())
    load_expected(m,ds);need(m['schedule_sha256']==e['schedule_sha256'],'planned schedule changed')
    out=campaign_root/f'captures/{session_id}.json';journal=out.with_suffix('.wire.jsonl')
    need(not out.exists() and not journal.exists(),'capture exists; no overwrite/retry of a measured session')
    try:import serial
    except ImportError as exc:raise ValueError('pyserial missing on acquisition host') from exc
    trace={'schema':'rtnn-de0cv-experiment-trace-v1','origin':'fpga_de0cv','status':'INCOMPLETE',
      'capture_transport':'uart_rx_3v3','sof_sha256':h['files']['sof']['sha256'],
      'dataset_sha256':ds['dataset_sha256'],'schedule_sha256':m['schedule_sha256'],
      'campaign_sha256':c['campaign_sha256'],'session_id':session_id,'boot_id':s['boot_id'],
      'hardware_review_sha256':hashlib.sha256((campaign_root/'hardware_review.json').read_bytes()).hexdigest(),
      'session_review_sha256':hashlib.sha256((campaign_root/f'sessions/{session_id}.json').read_bytes()).hexdigest(),
      'rows':[],'claim_scope':'PHYSICAL_OBSERVATIONS_NOT_WCET'}
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('x') as f:json.dump(trace,f,indent=2)
    session=None
    with journal.open('x') as jf:
        def append_event(event):
            jf.write(json.dumps(event,separators=(',',':'))+'\n');jf.flush();os.fsync(jf.fileno())
        try:
            with serial.Serial(port,baudrate=115200,timeout=5.,write_timeout=5.) as con:
                if con.in_waiting:raise ValueError('stale UART bytes before session; reset/review, do not silently discard')
                session=Session(con,journal=append_event)
                for row in m['rows']:
                    q=Request(seq=row['seq'],input_id=row['input_id'],mode=Mode(row['mode']),fixed_exit=row['fixed_exit'],
                       budget_q16=row['budget_q16'],deadline_cycles=0,model_id=MODEL_ID,build_id=BUILD_ID)
                    result=session.exchange(q)['response']
                    if result.status!=Status.OK:raise ValueError(f'board returned status {result.status}; raw reply preserved')
                trace['rows']=session.trace;trace['status']='CAPTURE_COMPLETE_UNAUDITED'
        except BaseException as exc:
            trace['failure']=str(exc);raise
        finally:
            if session is not None:trace['rows']=session.trace
            jf.flush();os.fsync(jf.fileno())
            trace['wire_journal']={'path':journal.relative_to(campaign_root).as_posix(),
                                   'sha256':hashlib.sha256(journal.read_bytes()).hexdigest()}
            # Atomic checkpoint. Journal remains useful even after power loss.
            tmp=out.with_suffix('.tmp');tmp.write_text(json.dumps(trace,indent=2)+'\n');tmp.replace(out)
    return trace

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--campaign',type=Path,required=True);p.add_argument('--session',required=True);p.add_argument('--port',required=True);a=p.parse_args()
    try:r=collect(a.root,a.campaign,a.session,a.port);print(r['status'],len(r['rows']))
    except (ValueError,RuntimeError,OSError) as e:p.exit(2,f'ACQUISITION_BLOCKED_OR_FAILED: {e}\n')
if __name__=='__main__':main()
