#!/usr/bin/env python3
"""Freeze an EXISTING-METHOD, same-model physical campaign before acquisition.

No learned time-feedback, no GPU, no imported Simple-System timing bounds.
The already-inspected digits test set is a replication benchmark, not a new
unseen population. A manifest/checksum protects integrity, not device identity.
"""
from __future__ import annotations
import argparse,hashlib,json,random
from pathlib import Path
from experiment_matrix import make_matrix
from experiment_wire import Mode
from experiment_audit import verified_oracle
from offline_q15_protocol_fixture import EXPECTED_ORACLE_DIGEST

MODEL_ID=0x52544e4e
BUILD_ID=0x44563032
DATASET_SHA='e0d056846c19174ad5dbd5c88603b7877334e9d03d2be7c85d5b438a5193322f'
MEASUREMENT_SCOPE='device_cycle_counter:admission_or_cap+NN+exit_heads+entropy+argmax;excludes_UART'

def digest(x)->str:
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def write_json(path:Path,x)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')

def finish_matrix(m:dict)->dict:
    for i,r in enumerate(m['rows'],1):r['seq']=i
    m['record_count']=len(m['rows']);m['schedule_sha256']=digest(m['rows']);return m

def paired_matrix(seed:int)->dict:
    """Randomized input order, adjacent pairs, exactly 180 AB and 180 BA."""
    m=make_matrix(seed,360,'paired')
    rng=random.Random(seed);ids=list(range(360));rng.shuffle(ids)
    orders=[0]*180+[1]*180;rng.shuffle(orders);rows=[]
    for iid,reverse in zip(ids,orders):
        a={'input_id':iid,'mode':int(Mode.FIXED),'fixed_exit':2,'budget_q16':65535,'deadline_cycles':0}
        b={**a,'mode':int(Mode.ADAPTIVE),'fixed_exit':0}
        rows.extend([b,a] if reverse else [a,b])
    m['rows']=rows;return finish_matrix(m)

def prepare(root:Path,out:Path)->dict:
    root=root.resolve()
    if out.exists():raise ValueError('campaign destination exists; no overwrite')
    ds=json.loads((root/'generated/heldout360.json').read_text())
    oracle=json.loads((root/'generated/frozen_q15_oracle.json').read_text())
    if ds['dataset_sha256']!=DATASET_SHA:raise ValueError('frozen dataset differs')
    verified_oracle(oracle,ds,EXPECTED_ORACLE_DIGEST)
    schedules=[];matrices={}
    for label in ('fixed','adaptive','capped'):
        m=make_matrix(10000+len(matrices),360,'adaptive' if label=='capped' else label)
        if label=='capped':
            m['experiment']='capped'
            for r in m['rows']:r['mode']=int(Mode.CAPPED_NO_STOP)
            finish_matrix(m)
        sid='diagnostic_'+label;matrices[sid]=m
    for n in range(1,11):matrices[f'primary_{n:02d}']=paired_matrix(31000+n)
    for sid,m in matrices.items():
        schedules.append({'session_id':sid,'matrix':f'schedules/{sid}.json',
                          'schedule_sha256':m['schedule_sha256'],'record_count':len(m['rows']),
                          'purpose':'PRIMARY_PAIRED' if sid.startswith('primary_') else 'SECONDARY_DIAGNOSTIC'})
    campaign={'schema':'rtnn-existing-method-campaign-v1','scope':'EXISTING_METHOD_ONLY',
      'study_type':'FROZEN_MODEL_HARDWARE_REPLICATION_CASE_STUDY',
      'model_seed':63,'model_id':MODEL_ID,'expected_build_id':BUILD_ID,'binding_id':0,
      'dataset_sha256':DATASET_SHA,'q15_predictions_sha256':EXPECTED_ORACLE_DIGEST,
      'dataset_file_sha256':hashlib.sha256((root/'generated/heldout360.json').read_bytes()).hexdigest(),
      'primary_sessions':10,'unique_accuracy_inputs':360,
      'prior_test_results_known':True,'independent_new_generalization_claim':False,
      'measurement_scope':MEASUREMENT_SCOPE,'batch_size':1,
      'fixed_baselines':list(range(7)),
      'primary_comparator':'fixed_exit_2_previously_observed_comparator_not_test_blind_selection',
      'practical_mean_cycle_saving_fraction':0.05,'accuracy_noninferiority_margin_pp':1.0,
      'bootstrap':{'seed':63,'samples':5000,'unit':'input_id; within-input mean over sessions',
                   'interval':'percentile_95; conditional_case_study_not_WCET'},
      'stopping_rule':'complete_all_planned_sessions;abort_on_integrity_or_functional_fault;no_early_positive_stop',
      'schedules':schedules,
      'prohibited_claims':['hard_WCET','GPU_results','time_feedback_learning','fresh_test_set','zero_misses_implies_guarantee']}
    campaign['campaign_sha256']=digest(campaign)
    out.mkdir(parents=True)
    for sid,m in matrices.items():write_json(out/f'schedules/{sid}.json',m)
    write_json(out/'campaign.json',campaign)
    hardware={
      'schema':'rtnn-existing-hardware-review-v1','status':'PENDING_NOT_BOARD_READY',
      'board_model':'DE0-CV','fpga_part':'5CEBA4F23C7N','pcb_revision':None,
      'board_identifier':None,'clock_hz':None,'clock_source_and_tolerance':None,
      'reviewer':None,'reviewed_at_utc':None,'measurement_scope':MEASUREMENT_SCOPE,
      'model_id':MODEL_ID,'build_id':BUILD_ID,'binding_id':0,
      'uart_baud':115200,'uart_logic_voltage_v':3.3,
      'tools':{'quartus':None,'verilator':None,'sv2v':None,'riscv_gcc':None},
      'gates':{k:False for k in ['rtl_units','soc_original_42','sv2v_regression',
              'rv32_b_model_equivalence','fitter_fit','ram_placement_latency',
              'setup_hold_recovery_removal','no_unreviewed_unconstrained_paths',
              'no_interrupt_dma_debug_contention','b_bitstream_programming_verified']},
      'files':{k:{'path':None,'sha256':None} for k in [
          'sof','firmware_elf','firmware_bin','ram_hex','converted_rtl','rtl_sources_lock',
          'qsf','sdc','fitter_report','sta_report','programming_log',
          'rtl_unit_log','soc42_log','sv2v_comparison','rv32_b_equivalence_log']},
      'warning':'Operator review required; hashes do not constitute physical device attestation or a timing theorem.'}
    write_json(out/'hardware_review.json',hardware)
    (out/'captures').mkdir();(out/'evidence').mkdir();(out/'sessions').mkdir()
    for e in schedules:
        write_json(out/f"sessions/{e['session_id']}.json",{
          'session_id':e['session_id'],'status':'PENDING','boot_id':None,
          'cold_boot_confirmed':False,'operator':None,'started_at_utc':None,
          'board_identifier':None,'ambient_temperature_c':None,'supply_observation':None,
          'warmup_protocol':'NO_HIDDEN_WARMUP; cold-boot start, UART outside timing; record input order',
          'programming_log':{'path':None,'sha256':None},'notes':None})
    return campaign

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    try:c=prepare(a.root,a.out)
    except (ValueError,KeyError,OSError) as e:ap.exit(2,f'CAMPAIGN_BLOCKED: {e}\n')
    print('PLANNED_NOT_MEASURED',sum(x['record_count'] for x in c['schedules']),c['campaign_sha256'])
if __name__=='__main__':main()
