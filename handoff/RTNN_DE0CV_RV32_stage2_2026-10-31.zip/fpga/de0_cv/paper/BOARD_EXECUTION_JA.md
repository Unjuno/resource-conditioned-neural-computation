# 実機当日：既存方式の取得と論文出力

## A. データ取得前の技術ゲート

1. このpackageのoffline再現を測定PCで再実行する。
2. pinned Ibex依存グラフと新SoCのテストベンチを完成させ、RAM/UART/bus/reset単体とwhole-SoCを実行する。
3. 旧ELFの42件を新SoCで再現する。これは機能移植テストであり、旧cycle数一致やdeadline保証を要求しない。
4. sv2v変換前後を同じ新SoCで比較する。UART信号・メモリアクセス・cycleも監査する。
5. 最終B ELF/BINについて凍結Q15モデル参照と一致を確認する。source host試験だけで代用しない。
6. Quartus合成・Fitter・M10K/ポート/初期化/RAM応答・全clock/reset制約・STAをレビューする。
7. 実ボードのrevision/part/電源/ケーブルを確認し、公式board資料とQSFのピンを照合する。UARTは3.3V logic対応の相手と共通GND。5V/RS-232をつながない。
8. 診断LED/UART/RAMでbring-upしてからBをprogram/verifyする。AのRAMイメージのままBを測らない。

この一覧の未完了をstatus文言だけで埋めない。失敗ログを保存する。

## B. 証拠ファイルの配置

`runs/campaign01/evidence/`に最終SOF、ELF、BIN、RAM hex、変換RTL、ソースlock、QSF/SDC、Fitter/STA、RTL回帰、RV32機能、programming/verifyログを置く。

`hardware_review.json`の各`files`にcampaign内相対pathと実ファイルのSHA-256を設定する。statusはレビュー完了時のみ`OPERATOR_REVIEWED_FOR_EMPIRICAL_RUN`にする。reviewer、board_identifier、clock source/tolerance、tool版、gateの判断根拠を記録する。

```bash
sha256sum runs/campaign01/evidence/*
python3 tools/paper_results.py --campaign runs/campaign01 --check-only
```

このコマンドはhash/必須項目とoperatorの判定を照合するだけで、レポートの技術内容を自動で証明しない。

## C. セッションを開始する

`campaign.json`の順にdiagnostic3種とprimary10回を実行する。各回の` sessions/<id>.json`には実際のcold boot ID、開始時刻、operator、board ID、その回に対応するprogram/verify記録を設定する。statusは`READY_FOR_ACQUISITION`。

```bash
python3 tools/paper_collect.py --campaign runs/campaign01 \
 --session diagnostic_fixed --port /dev/ttyUSB0
python3 tools/paper_collect.py --campaign runs/campaign01 \
 --session diagnostic_adaptive --port /dev/ttyUSB0
python3 tools/paper_collect.py --campaign runs/campaign01 \
 --session diagnostic_capped --port /dev/ttyUSB0
```

primaryは**自動for loopで10回にせず、その都度cold bootして記録**する。

```bash
python3 tools/paper_collect.py --campaign runs/campaign01 \
 --session primary_01 --port /dev/ttyUSB0
```

`primary_02`〜`primary_10`も同様。取得済みファイルは上書きしない。実測後のreview JSON編集もhash不一致になる。追加の観察は別ファイルに残す。

## D. 途中失敗

通信timeout、CRC、identity、trap、cap違反等は収集を中止する。raw `.wire.jsonl`はtransactionごとにflush/fsyncされ、invalid replyやpartial replyも保存される。`.json`はINCOMPLETEのまま保存される。速度が遅いこと自体は中止理由ではない。

修正が必要なら別build/campaignにして再取得する。古い失敗を残し、「成功した回だけ」を未記載で選ばない。偶発的な接続不具合もfailure logへ記載する。

## E. データが揃った後

```bash
python3 tools/paper_results.py --campaign runs/campaign01 --out paper_results/campaign01
python3 tools/paper_plots.py --report paper_results/campaign01/results.json \
 --out paper_results/campaign01_figures
```

表/図はsource hashと紐付く。固定2比で遅い結果も表へ出す。出力を`paper/MANUSCRIPT_SKELETON_JA.md`の該当欄へ転記し、主張は`CLAIM_EVIDENCE_MAP.json`の範囲を超えない。

保存物：13 raw journal、13 parsed trace、campaign/review/session JSON、実機/EDA/firmware証跡、全解析CSV/JSON、図、バージョン情報。この一式を読者に再現可能な形で公開するかを別途判断する。
