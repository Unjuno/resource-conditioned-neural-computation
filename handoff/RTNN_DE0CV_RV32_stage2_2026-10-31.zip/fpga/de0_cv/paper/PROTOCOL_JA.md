# RTNN / DE0-CV 既存方式：実機データ取得プロトコル

版：existing-method-v1、2026-10-31。状態：**PLANNED / NOT MEASURED**。

## 1. 研究の範囲と固定対象

対象は、先頭から順にブロックを実行し、外部budgetによる上限とentropy閾値によって早期終了する既存方式。同じseed-63 Q15重み、同じ7出口、同じ入力前処理を全比較で使用する。6ブロック能力と、適応方策の最大5ブロックを区別する。

残り時間の逐次入力、別の停止NN、GPU学習は含めない。時計は測定区間の開始・終了で読む。実験Bでは時間表を持たず、deadline modeを拒否する。開始前deadline admissionのソフトウェア契約と、FPGA上の実時間保証は別の証拠として扱う。

モデル再学習、テスト結果を見たentropy閾値変更、都合のよい入力の選別は禁止。同じ360件を既に調べているため、これは**既知の固定benchmarkによるハードウェア再現・比較case study**であり、新しい未見データでの汎化試験ではない。

基準core Git blob：`3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a`。
重みheader SHA-256：`961a76b7e220bf2f665e7c04ab62063600aa2e7eccf3403d80ea730bc993ad9f`。
入力canonical SHA-256：`e0d056846c19174ad5dbd5c88603b7877334e9d03d2be7c85d5b438a5193322f`。
Q15予測canonical SHA-256：`03eb958cfa8b4fd2f71a95fb47dbca512820c237c281473817bba685b92c743e`。

## 2. H：答える仮説

H1（機能）：FPGAの全比較モードが、凍結Q15参照と同じ予測・実行深さを返す。
H2（実行）：外部budgetが物理的実行ブロックの上限を守り、早期終了が実行量をさらに下げる。
H3（性能）：固定2ブロックと比較し、適応方式が停止判定・途中headのコストを含めた平均processor cycleを減らす。
H4（精度の扱い）：同じ360入力の精度差とpairedな不確かさを報告する。「同じ339正答だった」ことを、未見母集団における完全同等と読み替えない。

H3が否定されても、H1/H2の再現やoverheadのnegative resultは報告する。速いという結論を先に書かない。

## 3. 実験行列とデータ数

| session | 方式・範囲 | 要求数 | 用途 |
|---|---|---:|---|
| diagnostic_fixed | 360入力 × 固定出口0〜6 | 2,520 | 全固定深さのaccuracy/cycle frontier |
| diagnostic_capped | 360入力 × 21予算、早期停止なし | 7,560 | budget上限とentropy停止の切分け |
| diagnostic_adaptive | 360入力 × 21予算、entropy停止あり | 7,560 | budget/精度/実行量の関係 |
| primary_01〜10 | 各360入力 × 固定2/適応 | 720 × 10 | 主たるpaired timing比較 |
| 合計 | 13セッション | 24,840 | 全要求を保存 |

21予算は0〜65535のQ0.16コード上でgeneratorが確定した値。丸めや境界を後から変更しない。全要求はprotocol version 1、32-byte request / 48-byte response、little-endian、CRC32。

固定方式とcap-only方式は最後のheadのみを実行する。適応方式の途中headとentropyは測定に含める。この違いを取り除いて有利な比較を作らない。

## 4. 公平な取得条件

全比較を同じB ELF、同じSOF、同じメモリ、同じクロック、batch=1で実行する。設定が変われば別campaignとして扱う。

primaryの各セッションは独立したcold bootから開始する。360入力の順序を固定seedでシャッフルし、同じ入力の2方式を隣接して測定する。各セッションで固定→適応が180入力、適応→固定が180入力。隠れたwarmup、結果を見た再試行、低速測定の除外は禁止。

入力/要求のUART受信とCRC検証は計測外。計測は既存runnerのcycle counterから、budget/admission・NN・head・entropy・argmaxまで。応答のCRC整形、UART送信、PC側待ち、キュー待ちは計測外。これはend-to-end通信deadlineではない。

主指標はclock-independentなprocessor cycles。クロックは宣言値・制約・物理源の許容差を記録する。時間への換算を追加する場合は、oscillatorの保証下限、計測区間、clock停止/遅延の有無を明示する。速度・電力を同一視しない。

## 5. D：データ合格と科学的結論を分離する

### データ受理ゲート

予定件数・順序・CRC・request/response ID・bitstream/ELF/参照の照合が成立し、予測/実行上限の不一致がないこと。失敗した場合、raw bytesと失敗状態を保存し、原因を特定するまで本測定を進めない。欠損行を除いた平均を主結果にしない。

人工データ、旧RTLログ、native fake-clock値は、physical結果exportの入力にできない。ファイルhashは整合性検証であってFPGAの暗号学的attestationではない。実機確認と書込みログをoperator reviewで補う。

### 科学的な判定

- 平均cycle差が0以下：`NO_SPEEDUP_OBSERVED`。有効なnegative result。
- 平均差は正だが95%paired区間が0を含む：`TIMING_UNCERTAIN`。
- 区間下限は正だが平均削減が5%未満：小さな差として報告。
- 下限正かつ平均削減5%以上：このcase studyでcycle削減を支持。

5%は追加制御の価値を判断するためにこのcampaignで先に置く実用目安で、理論定数ではない。精度差の下限が-1 percentage point以上かも別途報告する。この1pp幅も設計上の目安。満たさなくてもデータを捨てない。

**「測定完了」と「優位性を示した」は別。** 360件では精度非劣性の区間が広く、同正答数でも判定不確定になり得る。測定後にmarginを緩めない。

## 6. 統計と変数表

各入力のcycleは10セッションで平均し、同じ入力同士で固定2と適応を比較する。精度の分母は360であって3,600でも7,200でもない。paired bootstrapは入力ID単位、seed=63、5,000回。session別の平均差と範囲も併記する。これは当該benchmark/モデル/boardに条件付けた区間であり、processor状態全体の上界ではない。

| 記号 | 意味 | SI単位 | 定義 | 範囲・前提 | 型 |
|---|---|---|---|---|---|
| i | 評価入力番号 | 1 | 凍結360入力のID | 0〜359 | 整数スカラー |
| r | 起動セッション | 1 | 独立cold bootの番号 | 1〜10 | 整数スカラー |
| C_F(i,r) | 固定2のcycle数 | 1（cycle計数） | 同じ計測境界のcounter差 | 正整数、32-bit frame内 | 整数スカラー |
| C_A(i,r) | 適応方式のcycle数 | 1（cycle計数） | 同上 | 同じbuild/clock/入力 | 整数スカラー |
| ΔC | 平均cycle削減 | 1（cycle計数） | 入力・sessionで平均した C_F−C_A | 正で削減 | 実数スカラー |
| A_F, A_A | 正答率 | 1 | unique360入力での正答割合 | 0〜1 | 実数スカラー |
| f | clock周波数 | Hz = s^-1 | レビュー済み動作クロック | 正、許容差を別記 | 実数スカラー |
| T | 実時間 | s | C/f | 同期cycleが実時間に対応する場合 | 実数スカラー |
| u_c | 合成標準不確かさ | s | clock/計測境界等のモデルから評価 | 未測定なので数値を置かない | 非負スカラー |
| k | 拡張不確かさの包含係数 | 1 | uncertainty modelに従い選択 | 未評価 | 正スカラー |

単位チェック：cycleを計数として C/f の単位は1/(s^-1)=s。cycle差と正答率差は異なる量であり、32%block削減を32%時間削減とは呼ばない。bootstrap区間とclockの計測不確かさは別の概念で、混ぜてu_cと呼ばない。

## 7. C：失敗解釈

機能不一致は移植/制御の問題。予測が正しくてもcycle削減がなければ、entropy/head overheadが節約を上回る可能性がある。全固定深さのfrontierで固定1や固定3が有利なら、それも示す。入力順序やcold bootで差が変わるならmachine-state依存として記録する。

入力依存の早期停止と、固定実行経路の定時性は別。全入力へ一般化するWCET、割込み/DMA/外部SDRAMへの耐性、GPU上の利得、電力削減をこの実験から結論しない。

## 8. U：既知の制約

一つのモデル・一つのボード・既知の小規模入力集合。10bootはhardware反復で、10個の学習seedではない。ソースの機能試験は最終RV32 binaryの意味保存証明ではない。STAはcycle期間の条件を扱い、NNの実行cycle上限を自動的には与えない。

## 9. Deadline結果を本当に論文へ入れる場合

現Bはdeadline非対応状態として拒否する。後続の別Cビルドで、FPGA固有の時間表、identity、拒否条件、0/境界−1/同値/＋1/不足deadlineを検証する。固定深さ用の時間表を、entropy/head/admissionを含む適応経路へ流用しない。コンパイラが使われない診断演算を消していないか、最終機械語でも確認する。

観測最大値から作る表なら`EMPIRICAL_ONLY`で校正データと評価データを分離し、deadline missを失敗データとして保存する。hard保証には正当な上界の根拠が別途必要。既存52,920件のhost契約試験をFPGA deadline実測件数として転記しない。
