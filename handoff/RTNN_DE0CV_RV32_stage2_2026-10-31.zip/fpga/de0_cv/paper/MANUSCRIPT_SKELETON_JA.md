# 原稿骨子：実機測定後に結果欄を埋める

**未完成原稿。FPGA数値は未取得。以下の`[実測後]`を架空の値で埋めない。**

## 仮題

単一の固定Q15モデルに対する計算予算制限と適応的深さ実行：Ibex / DE0-CV上の再現可能なcase study

## 要旨の骨子

計算予算で実行上限を制限する単一の多出口ニューラルネットワークを、固定Q15実装と対象を特定したFPGA構成で評価する。時間を入力する追加学習は使わない。固定深さ、cap-only、entropy早期終了を同じモデル・binary・clockで比較する。主比較の観測cycle差は[実測後]、同じ360入力での正答率差は[実測後]。結果は[改善／不確定／不利]であり、停止処理のoverheadを含めて解釈する。対象範囲は[board/toolchain/build]。観測最大cycleをWCET証明とは扱わない。

## 1. 問題と狙い

単に層数を減らすことと、実装上の時間を減らすことは同じではない。途中のheadとentropy評価がoverheadになる。本研究の問いは、このoverheadを含む同一モデル比較で、入力依存の早期終了がどの程度の観測時間・精度trade-offを持つかである。

アーキテクチャ自体の新規性を主張しない。early-exit、anytime inference、deadline-aware inferenceの先行研究整理と適切な一次文献引用は、投稿前の独立した必須作業。現資料だけで「最初」「新しい一般手法」とは書かない。

## 2. 実装

6個のoptional attention/MLP block、7出口、8-row tokens、10クラス。代表modelはseed63、適応方策の最大出口5。固定方式は必要な最後のheadのみ、適応方式は途中headとentropyを実行する。

開始前にbudgetを有限classに下げる。今回の物理B実験にはdeadline bindingを設定しない。既存の開始前admissionソフトウェア契約、過去Simple-System RTL結果、今後の物理deadline実験は混同しない。

対象CPU/数値/メモリ/buildの条件は`hardware_review.json`から転記する。ELF/SOF/重みのhashは付録へ置く。

## 3. 評価設計

`PROTOCOL_JA.md`の全行列を実行。primaryは360入力×2方式×10 cold boots。各入力の2方式を隣接させ、各sessionでAB/BAを180ずつ割り当てる。batch1。UART、入力受信、応答送信はNN計測区間外。

既知の360入力によるcase studyである。過去の結果を確認した上で固定2を主要比較にしたことを開示する。全固定深さの結果も併記する。新しい未見テストセットを獲得したとは書かない。

accuracyはunique360入力、time反復はhardware反復。入力単位paired bootstrapとsession別範囲を示す。新しい学習seedの効果やboard間分散は評価していない。

## 4. 結果欄

| 図表 | 生成ファイル | 主張できる内容 |
|---|---|---|
| 構成・資源・clock・tool版表 | hardware_review + Fitter/STA | 対象実装条件のみ |
| 全固定深さ/予算frontier表 | fixed_and_budget_frontiers.csv | 当該benchmarkのaccuracy/cycle |
| 主paired比較表 | results.json / primary | 同じ入力でのcycle差とaccuracy差 |
| 精度とcycle図 | figure1_accuracy_cycles | observed trade-off |
| budgetと物理block数図 | figure2_budget_work | capと停止の効果 |
| inputごとのpaired cycle図 | figure3_paired_cycles | 改善/悪化する入力の分布 |
| cold boot差図 | figure4_boot_sensitivity | session変動 |

ここに[実測後]の数値を入れる。改善しない場合の文章：「適応方式は実行block数を削減したが、当該実装では途中head/entropy等の追加処理を含む総cycleの優位性は示されなかった」。これは結果であって、データをやり直す理由ではない。

## 5. 限界

一つのモデル、既知の小規模dataset、一台のboard。複数bootは追加の独立画像でも学習seedでもない。検証器のhash確認はhardware attestationではない。測定区間はUART通信・キュー・割込みを含まない。FPGAへの単純移植は専用NNアクセラレータによる高速化ではない。観測最大値とゼロ観測違反はhard-WCET証明ではない。

## 6. 結論

[実測結果に合わせて記述。先に肯定結論を書かない。]

## 再現付録

`campaign.json`、review/session JSON、source/toolchain、ELF/BIN/RAM/SOF、raw UART、監査結果、解析CSV/JSON、図生成コマンドを添付する。機能検証・人工データ・旧RTL・実機結果を明確に分ける。
