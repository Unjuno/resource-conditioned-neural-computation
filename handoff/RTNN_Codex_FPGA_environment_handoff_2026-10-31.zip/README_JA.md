# Codex / Desktop CommanderへのRTNN FPGA環境構築引継ぎ

## 使い方

1. この一式を開発PCに置いて展開する。
2. そのフォルダをCodexのローカル作業フォルダとして開くか、接続済みDesktop Commanderで参照できる場所を指定する。
3. `CODEX_FPGA_SETUP_PROMPT_JA.md` の内容をCodexに渡す。
4. Stage 2 ZIPは元のまま保存し、別の空フォルダへ展開して作業する。

**ChatGPT内の `/mnt/data` と、あなたのPCのローカルファイルは別です。**
Codexがこの一式を読める状態にしてから開始してください。

## 同梱物

| ファイル | 用途 |
|---|---|
| `CODEX_FPGA_SETUP_PROMPT_JA.md` | 詳細な実行依頼。基本方針・順序・安全範囲・判定条件 |
| `RTNN_DE0CV_RV32_stage2_2026-10-31.zip` | 変更していない既存コード正本 |
| `RTNN_DE0CV_RV32_stage2_status_JA.md` | 元Stage 2の報告。今回の再実行とは区別 |
| `PRECHECK_HERE_JA.md` | 今回ChatGPT側で実際に行った確認 |
| `evidence/` | 今回のテスト・tool不足・hash確認の記録 |
| `STAGE2_INVENTORY.json` | 元ZIPの212エントリのSHA-256一覧 |
| `HANDOFF_MANIFEST.json` | 引継ぎ元と版・範囲 |
| `SOURCES.md` | 使用した公式資料 |
| `SHA256SUMS` | 一式のファイルhash（自己ファイルを除く） |

## 元ZIPの照合

Linux/macOS:

```bash
sha256sum RTNN_DE0CV_RV32_stage2_2026-10-31.zip
```

Windows PowerShell:

```powershell
Get-FileHash -Algorithm SHA256 .\RTNN_DE0CV_RV32_stage2_2026-10-31.zip
```

期待値:
`7f5c666514729b0d5f776904ec5662187271beb90f30d4c33231b7b92b4c5507`

hash一致は版・転送整合性の確認であり、コードの正しさの証明ではありません。
Linuxでは `sha256sum -c SHA256SUMS` で同梱物も照合できます。

## 工程の分担

- ChatGPT側：元コードの整合性、既存host/ISA回帰、引継ぎ資料・危険箇所の整理。
- 開発PC側Codex：OS/tool調査、対応版導入、実Verilator、固定Ibex source closure、sv2v、Quartus。
- 実機接続後：対象ボードと書込みimageの確認、配線、書込み、実測。別途承認する。

本パッケージは新しいRTL検証済みリリースではありません。
時間フィードバック/GPU拡張、mainへの変更、実機書込みは今回行っていません。
