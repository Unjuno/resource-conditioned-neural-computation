# 参照資料

確認日：2026-10-31。版・対応OSは導入時にも確認する。

- OpenAI Codex MCP: https://developers.openai.com/codex/mcp
  - CodexのCLI/IDEからMCPを使うための公式資料。現在はChatGPT Learnの公式ドキュメントへredirectする。
- OpenAI Docs MCP: https://developers.openai.com/resources/docs-mcp
- Desktop Commander公式: https://desktopcommander.app/
- Ibex system/tool requirements: https://ibex-core.readthedocs.io/en/latest/02_user/system_requirements.html
  - Quartus Lite/Standardの直接SystemVerilog処理に制限、sv2vをworkaroundとして説明。
  - このパッケージの `--binary --timing` の可否は導入後に実コマンドで別途検査する。
- Altera device support: https://www.altera.com/developers/software/device-support
- Altera edition comparison: https://www.altera.com/products/development-tools/quartus/compare
- Altera OS support: https://www.altera.com/developers/software/os-support
- Altera Quartus Lite 25.1 Windows配布例: https://www.altera.com/downloads/fpga-development-tools/quartus-prime-lite-edition-design-software-version-25-1-windows
  - 例示であり採用版の指定ではない。PC OS、Cyclone V support、既存環境との整合性で選ぶ。

元実装の内容は同梱Stage 2 ZIPを基準とする。GitHub mainの最新性確認とは別。
