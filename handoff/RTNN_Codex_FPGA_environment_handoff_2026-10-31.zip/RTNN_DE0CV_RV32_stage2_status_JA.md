# RTNN / DE0-CV: Stage 2 engineering report (2026-10-31)

## Scope and current verdict

**Stage 2: PASS for offline RV32 ELF generation and ISA-level Q15 functional regression.**
**Board / Ibex RTL / Quartus timing: NOT VERIFIED.**

Target: existing seed-63 Q15 RTNN, not the exploratory time-feedback model. Repo
`Unjuno/resource-conditioned-neural-computation`, frozen core Git blob
`3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a`, header blob
`ac185458e21b956db01cb18504bdb507c0c69618`, weights SHA-256
`961a76b7e220bf2f665e7c04ab62063600aa2e7eccf3403d80ea730bc993ad9f`.

### Changes made

1. Reproduced a real B firmware toolchain failure: absent RISC-V GCC. Used
   Clang 17 + LLD + LLVM-objcopy for **RV32IM_Zicsr / ILP32**.
2. Diagnosed real link error: compiler emitted `memset` without libc. Provided
   minimal `firmware/rtnn_freestanding_mem.c`, part of the NEW B firmware.
3. Diagnosed `ld.lld` creating **three PT_LOAD segments**, rejected by the
   existing FPGA RAM image validator. Added an explicit single `PHDRS` RAM
   segment in `firmware/rtnn_experiment.ld`; both ELF/BIN and 65,536 hex words
   then pass the existing strict load-image builder.
4. Added SHA-pinned `tools/build_b_firmware_clang.sh` and recorded compiler,
   source file digests, output hashes, ISA and build configuration.
5. Added a fail-closed **host-only C++ RV32IM/Zicsr instruction interpreter**,
   plus `tools/rv32_isa_full_gate.py` and `tools/run_rv32_gate.sh`. It executes
   the **actual compiled machine code** and exchanges byte-exact request and
   response frames, not the native x86 Q15 function.
6. Added unit and regression tests for the positive and rejection paths.

### Evidence (new work in this package)

- `python3 -m pytest -q`: **83/83 PASS** (final complete host test suite).
- `tools/preflight.sh`: **30/30 PASS**, already included in overall host suite.
- Actual compiled RV32 B firmware: ELF entry `0x00100080`, one PT_LOAD,
  load bytes ~150 KiB and RAM image exactly **256 KiB**.
- **360 held-out inputs × 2 modes = 720** actual RV32 ISA request/response pairs:
  predictions and executed exits **match the frozen Q15 reference in all 720**;
  fixed exit 2 correct **339/360**, adaptive correct **339/360**;
  adaptive exit histogram `[0,263,81,7,2,7,0]`.
- Actual RV32 firmware rejects **bad CRC**, **wrong build ID** and **deadline
  requests with no accepted FPGA timing binding**, in instruction-level tests.
- Two independent Clang builds produced identical ELF and BIN SHA-256 locally.

**Caution: ISA interpreter `mcycle` increments once per instruction; it is an
instruction-path proxy, not an Ibex cycle measurement.** In this idealized
simulation, mean counted instructions for fixed exit 2 were ~747,962 and for
adaptive ~599,676 (360 inputs). **Never use the ~19.8% difference as physical
speedup, WCET or FPGA performance data.** It omits pipeline stalls, RAM
latency, UART transmission time, physical clock and timing closure.

### Run it again from the package

Requires `python3`, `pytest`, `gcc`, `g++`, `git`, `clang`, `ld.lld`,
`llvm-objcopy`, `readelf`, `unzip` and `sha256sum`.

```bash
cd fpga/de0_cv
python3 -m pytest -q
bash tools/preflight.sh
bash tools/run_rv32_gate.sh build/rv32_gate_new # output MUST NOT already exist
cat build/rv32_gate_new/isa_720/isa_gate.json
```

The new gate emits `fpga_b/rtnn_experiment.elf`, `.bin`,
`rtnn_ram_words.hex`, compiler/source hash manifest, 720 raw request/response
frames, and the ISA-only verdict. `fpga_b/rtnn_ram_words.hex` is for the NEW
B firmware, and **must not be confused with the old A RAM image**.

### Physical / RTL blockers (NOT PASSED)

| Gate | Exact remaining action | Success evidence |
|---|---|---|
| Ibex source | Fetch/lock upstream `7b5df75a041affe56e8c235260f98a09b3319008` and its ordered FuseSoC/EDAM dependency graph | Source versions/hashes, dependency list |
| RTL unit tests | Install/run Verilator; `bash tools/run_rtl_unit_tests.sh` | RAM alias and UART RX/TX test logs (not yet run) |
| Whole SoC | Add a real testbench, boot old A frozen BIN and then new B BIN, emulate UART wires and CPU bus responses, verify predictions/stopping | Waveforms and actual Ibex RTL-cycle logs |
| RTL translation | Run pinned `sv2v` on ordered sources; compare native SV and translated Verilog behavior | Matching snapshots and assertion logs |
| Quartus | Quartus Cyclone V synthesis/Fitter/STA for the B image; inspect M10K and byte-enables | SOF SHA, FIT/STA, RAM placement/initialization |
| Physical board | Program and verify actual DE0-CV and collect pre-registered campaigns | 13 physical session journals, boot identity, error records |
| Hard-real-time | Re-establish target-specific, *defensible* per-class total cycle bounds | Independent timing/processor/memory argument + admission test |

The available container lacks Verilator, sv2v, Quartus, RISC-V GCC, and a
connected authorized machine with these tools. Do not mark the RTL simulation,
Fitter/STA, board timing or hard deadline as PASS until fresh logs exist.

### Audit caveat

`tools/offline_reproduce.sh` exceeded this container's total execution timeout
while running its longer native C Q15 workload. Its **complete run is not
claimed PASS** in this work session. The independently executed 83-test suite,
30-case preflight, actual B RV32 machine-code build and 720-case ISA gate
provide narrower positive evidence. No git push or mainline change was made.
