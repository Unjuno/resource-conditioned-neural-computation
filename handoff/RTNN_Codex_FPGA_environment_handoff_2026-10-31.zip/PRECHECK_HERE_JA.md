# 今回こちらで行った準備・検証（2026-10-31）

## 新しく確認した結果

| 検査 | 実行結果 |
|---|---|
| 元Stage 2 ZIPのCRC・安全な相対パス・symlink検査 | 異常なし、212 entries |
| ZIP SHA-256 | `7f5c666514729b0d5f776904ec5662187271beb90f30d4c33231b7b92b4c5507` |
| 新規フォルダへの独立展開後 `python3 -m pytest -q -ra` | 83 passed、失敗・skipなし、exit 0 |
| `bash tools/preflight.sh` | 30 passed＋HOST_PREFLIGHT=PASS、exit 0 |
| `bash -n` | tools配下9 shell scriptsの構文エラー0 |
| 凍結ZIP/ELF/BIN hash | 記録された3 SHA-256と一致 |
| 開発toolの所在 | Clang 17.0.0、LLD、llvm-objcopy、GCC等あり |
| Verilator / sv2v / Quartus | このcontainerにはなし。toolchain gateはBLOCKED（exit 1） |
| この会話側Desktop Commander | 接続端末0。Codex側の接続状態とは別 |

preflightの30件は83件に含まれます。合計113件とは数えません。
83件の中に実B firmwareをビルドして自作ISA interpreterで720要求を確認するテストがあります。
そのカウンタは命令数proxyです。Ibex RTL cycle、FPGA性能、WCETの新証拠ではありません。
今回 `run_rv32_gate.sh` を独立にもう一度実行したとは主張していません。

## 引継ぎで明示した注意点

1. `preflight.sh` は旧A用の `quartus/rtnn_ram_words.hex` を生成する。
   新Bをcompileする際は `prepare_b_quartus.py` で別フォルダへ配置し、混同を防ぐ。
2. `make_quartus_flat.sh` は実在する固定Ibexと順序付きsource listを必要とする。
   ツールをインストールしただけでは依存関係も全SoC検証も完成しない。
3. RTL単体テストの `-Wno-fatal` はwarning未解決でもcompileを通し得る。
   warningの内容を審査し、exit 0だけでRTL品質PASSとしない。
4. 現行SDCは最小clock制約である。reset/UART/CDCを含む完結したSTA signoffではない。
5. 凍結Aの時間表を新B／FPGAへ流用しない。Bは有効なFPGA時間表がなければdeadline要求を拒否する。

## 変更していないもの

元ZIP、モデル、RTL、firmware、GitHub main、ユーザーPC、実験結果は変更していません。
追加したのは引継ぎプロンプト・manifest・inventory・今回の検査ログです。
新しいRTLシミュレーション、sv2v変換、Quartus、実機試験は今回未実施です。

## 再現ログ

`evidence/pytest_fresh.log`、`evidence/preflight_fresh.log`、`evidence/shell_syntax.json`、
`evidence/toolchain_gate.log`、`evidence/environment_here.json` を参照してください。
