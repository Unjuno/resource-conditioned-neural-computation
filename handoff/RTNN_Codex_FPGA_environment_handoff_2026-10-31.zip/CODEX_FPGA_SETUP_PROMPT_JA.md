# Codexへの依頼：RTNN / DE0-CVの開発環境構築と実RTL検証

この依頼は「環境構築の説明」ではなく、指定した開発PCでの実行依頼です。
既存RTNNの方式を変えず、再現可能な環境を用意し、実際のテストとビルドで確認してください。
ただし、未実行の工程を成功扱いにしたり、合格のために検証条件を弱めたりしてはいけません。

## 0. 目的・作業範囲

所有ボードはTerasic DE0-CV、対象はCyclone V `5CEBA4F23C7N`です。
QSFではdevice名が `5CEBA4F23C7` です。実際のdevice databaseとボード資料で照合してください。

方式は、推論開始前のbudget/deadline admission＋各Exitでのentropy早期終了に限定します。
seed-63の凍結Q15モデルをIbex softcore上で動かします。
時間フィードバック、新しい停止ヘッド、GPU、モデル再学習、NN専用acceleratorへの書換えは対象外です。

優先順位は次の通りです。
1. 操作対象PC・作業場所・既存状態の確認。
2. 工具の導入と実行確認、既存ホスト回帰。
3. RAM・UARTの実RTL単体試験。
4. 固定Ibexを含む新SoC全体の実RTLシミュレーション。
5. sv2v変換前後の回帰。
6. Quartus合成・Fitter・STA・SOF生成。
7. 実機接続後の手順と採取物を整理。

実機がなくても1〜6を進めてください。6が環境・権限等で止まっても、可能な1〜5は進めます。
説明やファイル作成だけで完了にせず、実行結果を確認してください。

## 1. 入力資料と正本

受け渡し一式に含まれる `RTNN_DE0CV_RV32_stage2_2026-10-31.zip` が今回の実装正本です。
そのSHA-256は次の値です。

`7f5c666514729b0d5f776904ec5662187271beb90f30d4c33231b7b92b4c5507`

これは転送・版の一致を検査するためのhashであり、コードの正しさや安全性を保証する署名ではありません。
展開前にhash、ZIP内パス、symlink、異常な展開サイズを点検してください。
別の空の作業ディレクトリへ展開し、元ZIP・旧成果物・生ログを保存してください。

このChatGPTのsandboxや `/mnt/data/...` が、開発PC上にあると仮定しないでください。
Codexに渡されたフォルダか指定されたローカルZIPを使ってください。
見つからない場合だけファイルの場所を確認し、全ディスクや無関係な私物フォルダを探索しないでください。

読む順序：
- 受け渡し一式の `README_JA.md` と `PRECHECK_HERE_JA.md`
- Stage 2 ZIP内の `README.md`
- `fpga/de0_cv/START_HERE_JA.md`
- 同梱の `RTNN_DE0CV_RV32_stage2_status_JA.md`
- `fpga/de0_cv/tests/rtl/README.md`
- `fpga/de0_cv/tools/toolchain_gate.sh`
- `fpga/de0_cv/tools/run_rtl_unit_tests.sh`
- `fpga/de0_cv/tools/make_quartus_flat.sh`
- `fpga/de0_cv/tools/prepare_b_quartus.py`

参照リポジトリ：
`https://github.com/Unjuno/resource-conditioned-neural-computation`
参照revision：`ea903d3b76c4cb50732c3f9c72c8ed2084c2cb23`

このFPGA準備一式はmainへ反映していない別配布物です。
リポジトリをcloneしただけで最新FPGAコードが揃ったと扱わないでください。
リポジトリを使う場合はAGENTS.mdなどを読み、現在のbranch・status・差分を保存します。
実装は隔離した作業場所で行い、mainの変更、commit、push、PR、merge、履歴削除は別途許可なしに行わないでください。

## 2. PCアクセス：ローカルとDCを取り違えない

DCはDesktop Commanderです。
- Codexが対象PC上でローカルに動くなら、そのターミナルで操作してよいです。DCは必須ではありません。
- 別PCをDC経由で扱うなら、実際に利用可能なMCPツールを調べ、接続端末を列挙します。
- 複数端末があり対象が判断できない場合だけ、対象を確認します。
- 端末がない場合は接続不能と報告します。接続したふりをせず、ローカルで可能な作業と分離します。
- ツール呼出しがpendingの場合、同じinstall/buildを重複起動せず、元の実行結果を追跡します。

最初はread-onlyでOS、CPUアーキテクチャ、RAM、空き容量、shell、作業場所、既存toolの実行ファイルと版を調査します。
無関係なファイル、秘密鍵、token、ブラウザ保存情報、環境変数の全量を収集しないでください。

## 3. 導入方針・権限

既存の正常な環境は壊さず、Pythonは専用venv、依存ソース・ビルド結果はプロジェクト専用の場所に置きます。
まず導入元・版・容量・配置先・必要権限をまとめ、その後に許可範囲内を実行してください。

- 管理者権限、system-wide変更、USBドライバ、udev、WSLの新規有効化、再起動、ライセンス同意、有償購入は必要箇所だけ確認する。
- 未署名・出所不明のinstallerや `curl | sh` は使わない。公式配布元を確認する。
- 許可されていないsandbox脱出や、承認設定の緩和はしない。
- ボード書込み、JTAG reset、恒久flash書換えは今回の自動実行に含めない。接続後に対象・配線・書込み画像を確認して別途承認を得る。
- 予定時間や成功を断言せず、現在の実行状態と失敗原因を報告する。

OSの扱い：
- Linuxは、選んだQuartus版の公式サポートOSと依存libraryを照合する。
- Windowsは、既存のWindows QuartusとWSL/Linux側のVerilator/sv2vを併用してよい。パス変換、改行、実行権、成果物受渡しを明示する。
- WSL内からUSB/JTAGが自動で使えると仮定しない。ボード未接続はRTL・合成の停止理由にしない。
- macOS/ARMではQuartusをnative対応と仮定せず、既存の対応x86-64 Windows/Linux環境の有無を確認する。別CPU/別FPGAへ黙って変更しない。

## 4. 必要toolと固定するもの

必要な実行系：
- Python 3、venv、pytest、既存コードが要求する依存（実ファイルから確認）
- git、bash、make、gcc/g++、unzip、sha256sum、readelf
- Clang/LLD/llvm-objcopy（既存基準はClang 17.0.0＋ILP32/RV32IM_Zicsr）
- Verilator（このパッケージが使う `--binary --timing` を実際に実行できる版）
- sv2v
- FuseSoC/Edalizeと、固定Ibexの依存graphに必要なtool
- Cyclone V対応のQuartus Prime Liteまたは既存の対応Standard、およびCyclone V device support
- 実機の段階でUSB-Blasterと3.3-VロジックのUART接続

Quartus Proがこの古いdeviceに適切と決めつけず、公式device support表を確認してください。
Ibex公式資料はQuartus Lite/Standardの直接SystemVerilog処理に制限を記載しています。
sv2v経路を使い、変換が通ったことと変換後の回帰一致を別々に検証します。
Icarusだけで固定Ibex全体を検証できたと扱わないでください。

インストール後は `--version` だけでなく、小さなコンパイル／RTL実行を試します。
採用toolの版、配布元、依存lock、source revision、主要バイナリのhashを記録してください。
compilerが異なる場合は新しいELF identityとして扱い、旧cycle表を流用しません。

固定Ibex commit：
`7b5df75a041affe56e8c235260f98a09b3319008`

Q15 source Git blob：
- core: `3f52ac6dd50f0cbaa2ff8ce9553020ebdb45718a`
- header: `ac185458e21b956db01cb18504bdb507c0c69618`

凍結weights SHA-256：
`961a76b7e220bf2f665e7c04ab62063600aa2e7eccf3403d80ea730bc993ad9f`

旧A artifact SHA-256：
- ZIP: `9150b0763e5d7b7c305441befdb4161ccf95612edd924b525f8388e06d9a86b0`
- ELF: `234a7f46cf227a11f5d97f3c778cbb0c4ed4f7067f8994bcca86c4b08ff4e742`
- BIN: `266ecb70c723b2164f6fe9039f27d4cb49c4d7271d4aca0cf69f2692cdfdf7a1`

## 5. 既存ゲートを再実行する

以降の作業ディレクトリは、Stage 2を展開したルートの `fpga/de0_cv` です。
出力先は未使用名を使い、途中失敗のログも残します。

```bash
python3 -m pytest -q -ra
bash tools/preflight.sh
bash tools/toolchain_gate.sh
bash tools/run_rv32_gate.sh build/rv32_gate_codex_001
```

既存のホスト側基準は83件成功、preflightはその内の30件です。合算して113件とは数えません。
追加修正で件数が変わるなら、追加・削除・skip・失敗を明記します。
skipを成功件数に加えないでください。

RV32 gateの720件一致は、未検証の自作ISA interpreterを使う機能検証です。
その `mcycle` は命令数proxyであり、Ibex RTL cycle・FPGA時間・WCET・実測speedupではありません。
このゲートの成功を、新SoCのRTL成功の代わりにしないでください。

### A/B RAMイメージの重大な注意

`preflight.sh` は旧AのRAMイメージを `quartus/rtnn_ram_words.hex` に生成します。
この後、そのままquartusフォルダでcompileするとA画像が使われるおそれがあります。
A（凍結旧ハーネスの移植確認）とB（新実験firmware）は作業場所、image hash、SOFを分離します。
Bは `tools/prepare_b_quartus.py` を使って新しいQuartus作業領域へ配置してください。
既存B RAMをpreflight出力で上書きしないでください。

## 6. Verilatorで実RTL単体試験を行う

```bash
bash tools/run_rtl_unit_tests.sh
```

対象はRAM、UART TX、UART RXの3testbenchです。
ログのPASS文字列だけでなく、終了コード、assertion、timeout、warningを確認します。
`-Wno-fatal` が既存スクリプトにあるため、compileの終了コード0だけで全warning解消とは扱わないでください。
警告は内容・理由を記録し、latch、width、未接続、未初期化などの重大なものを放置しないでください。

失敗時は再現ログを残し、原因を特定し、最小修正＋回帰テストで確認します。
期待値の改変、assertionの削除、タイムアウト延長だけでの隠蔽、全warning一括抑制は不可です。
古いテストは網羅的ではありません。必要に応じRAMのbyte enable・不正アドレス・同時アクセス、UARTのbusy/連続frame/error、reset条件の試験を追加します。

## 7. 固定Ibexのsource closureと新SoC全体のRTL検証

Ibexの同じcommit、vendor依存、生成primitive、package順序、include、define、parameterを固定します。
`.sv`を再帰globして並べただけのファイルリストを正規依存graphとして扱わないでください。
固定IbexのFuseSoC/EDAM等から、実際のtopに必要な依存graphを取得し、生成物も保存します。
RTL source list・include list・define・parameters・各file hashを機械可読形式で出力してください。

新SoC全体のtestbenchは未完です。既存ファイルの有無を調べ、必要なら作成してください。
CPUやRAMの応答をmockして「Ibexを動かした」と主張してはいけません。
本物の固定Ibex＋RAM＋bus＋UARTを接続し、testbenchの最外部でUART線を駆動/decodeします。

順序：
- A：凍結ELF/BINを読み込ませ、旧42ケース（CERT 21＋E2E 21）の予測・出口を再現。
- B：実験firmwareを読み込ませ、まず少数通信・機能ケース、次に360入力×2方式の720件へ拡張。
- CRC異常、build不一致、時間表なしdeadline要求の拒否を確認。
- bus fault、trap、CPU alert、reset、UART取りこぼしの有無を記録。
- 比較すべき信号・raw UART・対象区間cycle・必要な波形を保存。

旧Simple-Systemと新SoCは周辺回路が異なるため、旧cycle数との一致は要求しません。
SecureIbex、メモリlatency、cache、clock、割込み条件を、成功のために黙って変えてはいけません。
変更が必要なら原因・新target identity・再検証の範囲を記録します。

## 8. sv2v変換と回帰

順序付きsource listを用意した後に実行します。

```bash
IBEX_ROOT=/absolute/path/to/pinned_ibex \
IBEX_SOURCE_LIST=/absolute/path/to/ordered_sources.txt \
bash tools/make_quartus_flat.sh
```

パスは実在するものに置換します。未生成の `ibex_flat.v` を手書きdummyで代替しません。
生成RTLをVerilatorで実行し、同じ新SoCの変換前後で機能・UART・測定cycle・メモリ応答を比較します。
これは有限テストの回帰であり、形式等価性証明とは呼ばないでください。

## 9. Quartusを実行する

変換RTLとB画像が揃い、必要回帰を通ったら、B専用作業領域を生成します。

```bash
python3 tools/prepare_b_quartus.py \
  --b-build build/rv32_gate_codex_001/fpga_b \
  --flat quartus/ibex_flat.v \
  --out-dir build/quartus_b_codex_001
cd build/quartus_b_codex_001
quartus_sh --flow compile rtnn_de0_cv
```

特に確認する項目：
- Cyclone V `5CEBA4F23C7` が本当にinstalled device databaseで解決する。
- RAMが意図したM10K/port/byte-enable/初期化として実装される。
- 資源数、コード・重み・LUT・stackの配置、aliasの非重複。
- reset/clock/非同期UARTのCDCと必要なtiming例外。
- 現行SDCはclock中心の最小構成であり、完成したtiming signoffとは仮定しない。
- setup/hold、必要なrecovery/removal、未制約pathの説明、重大warningの処置。
- source/imageとSOFの対応をhashで記録する。

50 MHzは初期目標です。STA失敗をサンプル時間の安全倍率で埋め合わせないでください。
周波数や制約を変える場合は新targetとして扱い、UART・source・metadata・回帰を揃えます。
論理的根拠のないfalse path追加や制約削除で合格させてはいけません。

## 10. 出力・完了条件

証拠は `evidence/codex_setup/<run-id>/` の新規ディレクトリに集めてください。
次は今回作成する資料名であり、既存実装済みのファイル名ではありません。

- `environment_before.json` / `environment_after.json`
- `toolchain.lock.json`：版・実体path・配布元・hash・依存revision
- `commands.jsonl`：コマンド・cwd・開始終了時刻・終了コード・log path
- `rtl_sources.lock.json`：順序・include・define・parameters・file hash
- `rtl_unit.log`、`soc_sv.log`、`soc_converted.log`、`regression_summary.json`
- `quartus/`：Fitter/STA/警告・採用制約とSOF hash
- `ISSUES_AND_FIXES_JA.md`：再現→根本原因→最小修正→検証の対応
- `READINESS_JA.md`：工程別PASS/FAIL/BLOCKED/NOT_RUN、残作業、次のコマンド
- 手元PCから再実行できる環境有効化手順・build/sim手順
- コードを直した場合、変更差分と追加テスト。既存証拠は消さない。

合格を分けてください：
E0 入力整合性 / E1 tool実行確認 / E2 host+ISA / E3 RTL部品 /
E4 新SoCのnative SV実行 / E5 sv2v回帰 / E6 Quartus/Fitter/STA / E7 物理ボード。
E7は実機を測るまでNOT_RUNです。E1成功だけで「FPGA環境完成」と言わないでください。

定期的に短く、発見した不具合・直した内容・今のゲートを日本語で報告してください。
承認が不要なread-only検査と専用作業領域内の検証は途中で逐一確認せず進めます。
停止理由が発生したら、理由、必要なユーザー操作、まだ進められる作業を明記します。

実験成功の意味は、期待したspeedupを作ることではありません。
再現可能な手順で正しく検証し、性能が改善しない結果も保存できる状態にすることです。
