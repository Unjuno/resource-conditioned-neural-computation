# RTNN FPGA研究：並行論文評価トラック（2026-11-02）

**目的**：Codex側のEDA構築とは別に、凍結Q15の実績、実機データ採否、boot-aware統計を強化する変更差分。実機は未測定。

ベースZIP SHA-256: `7f5c666514729b0d5f776904ec5662187271beb90f30d4c33231b7b92b4c5507`

新しいcampaign SHA-256: `d6c98f59c0c0afe32d0877c01c8411fba8bf3e2a5c8058c5a85371f7f648a8dc`

## 同梱物

- `changes/fpga/de0_cv/`: 変更・新規ファイルのみ。
- `OVERLAY_MANIFEST.json`: オリジナルと変更後の各SHA-256。既存Codeを無条件に上書きしないための検査基準。
- `CHANGES.diff`: 変更の確認用。
- `apply_overlay.py`: 旧Stage2専用のSHA照合付きapply機能。**ユーザーが判断した場合にだけ**実行する。
- `q15_accuracy_only/`: 既知360入力の凍結Q15正誤表。**FPGA測定値・cycleは含まない。**
- `verification/`: TDD失敗・成功と統合テストのログ。

## 合流前に必ず確認

Codex側がEDA作業中なら、こちらを適用する前にファイルの競合を確認する。`apply_overlay.py --check-only --target <展開元>`でSHA整合性だけ確認できる。変わったファイルがあれば勝手に上書きしない。

実機UART captureが始まった後は旧campaignと新campaignを混合しない。詳細は`changes/fpga/de0_cv/docs/PARALLEL_PAPER_TRACK_2026-11-02_JA.md`を読むこと。
