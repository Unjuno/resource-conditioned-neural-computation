#!/usr/bin/env python3
"""Export a REAL pinned Q15 correctness-only paired baseline for the paper.

Never assigns processor cycles, FPGA timing, or deadline status. Output must
not be used in lieu of the separately audited real-board UART captures.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from random import Random
from experiment_audit import verified_oracle
from experiment_dataset import canonical_bytes
from offline_q15_protocol_fixture import EXPECTED_ORACLE_DIGEST
from paper_campaign import DATASET_SHA


def export_q15_only(root:Path, out:Path) -> dict:
    if out.exists():
        raise FileExistsError('refusing to overwrite a previously exported baseline')
    ds_path=root/'generated/heldout360.json'
    oracle_path=root/'generated/frozen_q15_oracle.json'
    ds=json.loads(ds_path.read_text())
    oracle=json.loads(oracle_path.read_text())
    if ds.get('dataset_sha256')!=DATASET_SHA or \
       hashlib.sha256(canonical_bytes(ds['records'])).hexdigest()!=DATASET_SHA:
        raise ValueError('dataset differs from the frozen 360-input split')
    verified_oracle(oracle,ds,EXPECTED_ORACLE_DIGEST)
    preds=oracle['predictions']
    rows=[]
    both=neither=adapt_only=fixed_only=blocks=0
    hist=[0]*7
    for datum in ds['records']:
        iid=datum['input_id'];label=datum['label']; p=preds[str(iid)]
        fixed_pred=p['predictions'][2];e=p['preferred_exit'];adapt_pred=p['predictions'][e]
        f=int(fixed_pred==label);a=int(adapt_pred==label)
        both+=f*a;neither+=(1-f)*(1-a)
        adapt_only+=a*(1-f);fixed_only+=f*(1-a)
        blocks+=e;hist[e]+=1
        rows.append({'input_id':iid,'label':label,'fixed2_prediction':fixed_pred,
                     'adaptive_prediction':adapt_pred,'adaptive_exit':e,
                     'fixed2_correct':f,'adaptive_correct':a,'accuracy_delta':a-f})
    n=adapt_only+fixed_only
    pvalue=min(1.0,2*sum(math.comb(n,k) for k in range(min(adapt_only,fixed_only)+1))/2**n) if n else 1.0
    rng=Random(63)
    accuracy_bs=[]
    for _ in range(5000):
        accuracy_bs.append(100*sum(rows[rng.randrange(len(rows))]['accuracy_delta']
                                   for _ in rows)/len(rows))
    accuracy_bs.sort()
    accuracy_ci=[accuracy_bs[int(.025*len(accuracy_bs))],
                 accuracy_bs[min(len(accuracy_bs)-1,int(.975*len(accuracy_bs)))]]
    result={
        'status':'FROZEN_Q15_ONLY_NOT_BOARD_TIMING',
        'data_provenance':'fixed held-out digits split, previously inspected; not new unseen generalization',
        'model':'seed63 Q15 deployed max_exit5',
        'unique_inputs':len(rows),
        'fixed2_correct':both+fixed_only,'adaptive_correct':both+adapt_only,
        'both_correct':both,'both_wrong':neither,'adaptive_only_correct':adapt_only,
        'fixed2_only_correct':fixed_only,'mcnemar_exact_two_sided_p':pvalue,
        'accuracy_delta_pp':100*(adapt_only-fixed_only)/len(rows),
        'accuracy_delta_pp_bootstrap_ci95':accuracy_ci,
        'accuracy_noninferiority_margin_pp':1.0,
        'accuracy_noninferiority_1pp':('SUPPORTED_CONDITIONALLY' if accuracy_ci[0]>=-1 else 'INCONCLUSIVE'),
        'accuracy_bootstrap':{'seed':63,'samples':5000,'unit':'input_id',
                              'note':'percentile interval on previously inspected 360-input benchmark'},
        'preferred_histogram':hist,'total_adaptive_blocks':blocks,
        'average_adaptive_blocks':blocks/len(rows),
        'canonical_dataset_sha256':DATASET_SHA,
        'oracle_predictions_sha256':EXPECTED_ORACLE_DIGEST,
        'input_file_sha256':hashlib.sha256(ds_path.read_bytes()).hexdigest(),
        'oracle_file_sha256':hashlib.sha256(oracle_path.read_bytes()).hexdigest(),
        'fpga_cycles_measured':False,
        'nonclaims':['No FPGA clock or latency measured','McNemar high p is not equivalence',
                     'This is accuracy-only evidence, not novel held-out generalization',
                     'Same frozen input sample of 360 across all boots'],
    }
    if len(rows)!=360 or both+neither+adapt_only+fixed_only!=360:
        raise ValueError('incorrect frozen baseline coverage')
    out.mkdir(parents=True)
    with (out/'accuracy_pairs.csv').open('x',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    result['accuracy_pairs_csv_sha256']=hashlib.sha256((out/'accuracy_pairs.csv').read_bytes()).hexdigest()
    (out/'accuracy_only.json').write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return result


def main() -> None:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    print(json.dumps(export_q15_only(args.root,args.out),indent=2,ensure_ascii=False))

if __name__=='__main__':main()
