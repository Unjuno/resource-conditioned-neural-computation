# RTNN並列作業トラック：論文データ・検証・統計（2026-11-02）

## 担当の切り分け

- **Codex側**：EDA環境、Ibex RTL依存関係、Verilator、sv2v、Quartus Fitter/STA、ボード実機。
- **こちら側**：既存seed63 Q15の正誤参照、実験ログ採否、cold-bootを含む統計、論文用CSVとJSON。
- どちらも元の凍結Q15重み、実行停止の既存方式を変えない。GPU・時間フィードバックは対象外。

## 今回追加した内容

1. `tools/paper_q15_baseline.py`：凍結Q15 oracleとdatasetのSHAを検証し、実測cycle列を含まない正誤の対応表を出力。
2. `tools/paper_results.py`：入力単位のbootstrapに加え、入力×独立cold-bootの二方向bootstrapを追加。起動間で差が逆転する場合、論文で速度優位の判定を保留する。対応正誤McNemar exact pを報告（同等性の証明とは扱わない）。
3. `tools/paper_campaign.py`・`paper/campaign/campaign.json`：実測開始前の統計追補を明記し、キャンペーンIDを更新。**予定行24,840件、13 schedulesとそのSHAは変えない**。
4. `paper/campaign/hardware_review.json`：実際のStage2ビルドに対応したClang/LLD/LLVM objcopy欄を追加。GCC版数を強制しない。
5. `tests/test_parallel_paper_stats.py`, `tests/test_parallel_q15_baseline.py`：不利な起動条件を含む負のテスト、SHA改変拒否、正答数・入力数チェック。

## 得られたQ15参照データ（FPGA実測ではない）

- 固定2：339/360正解。
- 適応：339/360正解。平均実行ブロック489/360 = 1.35833333。
- 正誤：両方正解336、両方誤り18、固定2のみ正解3、適応のみ正解3。
- McNemar exact two-sided p = 1.0（性能・精度同等性の証明ではない）。
- 出力`evidence_q15_baseline/accuracy_only.json`、`accuracy_pairs.csv`は凍結参照Q15のみ。**人工cycleやFPGA cycleは含まない。**

## 合流時の注意

- この成果物はStage 2の**別コピー**に対する変更である。Codex側の作業ディレクトリへ自動同期していない。
- ボードで取得を開始する**前**に、どちらの`campaign_sha256`を使うか統一する。旧`dce387...`と新`d6c98f...`のcaptureを混在させない。
- 先にCodexが同じファイルを変更していた場合は機械的に上書きせず差分をレビューする。
- 先に実機収集が始まっていた場合は本追補を**別campaign**として扱い、既存データを事後的に再解釈しない。
- `load_hardware()`は外部から提出された証拠ファイルのSHAとレビュー状態を確認するが、物理的なdevice attestationではない。

## 未完了

Verilatorによる新SoC RTL、Quartus/Fitter/STA、USB-JTAG/DE0-CV実機、FPGAのcycle測定、電力、実機hard deadline保証は**未実施**。これらはCodexと実機側の証拠がなければPASSにしない。

## 使い方（本トラックのコードを合流した後）

```bash
cd fpga/de0_cv
python3 -m pytest -q tests/test_parallel_paper_stats.py tests/test_parallel_q15_baseline.py tests/test_paper_release.py
python3 tools/paper_q15_baseline.py --out /tmp/rtnn_q15_accuracy_only
```

ここで生成する正誤データのみを実機性能の図表へコピーしてはいけない。実機のcycle用図表は物理データの収集・監査ゲート成功後に限る。

## 凍結Q15正答率差の統計的制約

`paper_q15_baseline.py`の入力ID単位5,000反復bootstrap（seed=63）では、適応−固定2の正答率差は **0.00 pp**、95%パーセンタイル区間は **−1.3889〜＋1.3889 pp**。したがって事前目安である**1 pp非劣性は`INCONCLUSIVE`**。同じ正解数から統計学的同等性を導いてはならない。McNemarのp=1.0も等価性の証拠ではない。

なお、これらの区間は既に研究者が調べた360件のbenchmarksに条件付けた近似であり、学習時のモデル選択や新しい母集団への一般化不確かさを完全には表さない。実機でこのaccuracyを「新しい汎化結果」として繰り返し主張しない。
