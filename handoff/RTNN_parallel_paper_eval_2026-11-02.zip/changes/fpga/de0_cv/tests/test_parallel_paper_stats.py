"""Pre-board evidence tests: boot-aware inference and declared toolchain identity.

A deliberately constant per-input effect with mixed boot signs must *not*
be mistaken for a robust latency improvement just because input bootstrap
has zero estimated variance.
"""
import hashlib
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from paper_campaign import prepare
from paper_results import primary_metrics, load_hardware


def make_rows(session_savings):
    return [
        dict(session_id=f'boot{boot:02d}', input_id=input_id,
             fixed2_cycles=1000, adaptive_cycles=1000-saving,
             fixed2_correct=int(input_id!=0), adaptive_correct=int(input_id!=0))
        for boot,saving in enumerate(session_savings)
        for input_id in range(30)
    ]


def test_boot_variation_blocks_false_speedup_promotion():
    # All 30 inputs show the same mean saving: input-only resampling
    # cannot detect the half-negative, half-positive boot regime.
    rows=make_rows([50]*5 + [-40]*5)
    r=primary_metrics(rows, bootstrap_samples=1500, seed=63)
    assert r['mean_cycle_saving']==5
    assert r['mean_cycle_saving_ci95']==[5.0, 5.0]
    assert r['mean_cycle_saving_ci95_two_way'][0]<0
    assert r['mean_cycle_saving_ci95_two_way'][1]>0
    assert r['performance_decision']=='TIMING_UNCERTAIN_BOOT_VARIABILITY'
    assert r['boot_negative_or_zero_saving_sessions']==5


def test_boot_robust_speedup_still_possible_and_deterministic():
    rows=make_rows([100]*10)
    r=primary_metrics(rows, bootstrap_samples=500, seed=63)
    r2=primary_metrics(rows, bootstrap_samples=500, seed=63)
    assert r['mean_cycle_saving_ci95_two_way']==[100.0,100.0]
    assert r['performance_decision']=='CYCLE_REDUCTION_SUPPORTED_ON_THIS_CASE_STUDY'
    assert r['bootstrap_samples_two_way']==500
    assert r['mean_cycle_saving_ci95_two_way']==r2['mean_cycle_saving_ci95_two_way']


def test_single_boot_does_not_establish_repeatability():
    r=primary_metrics(make_rows([50]), bootstrap_samples=500)
    assert r['performance_decision']=='INSUFFICIENT_BOOT_REPLICATION'


def test_exact_paired_mcnemar_is_reported_not_equivalence_claim():
    rows=[]
    # 6 discordant inputs: 3 wins and 3 losses, same overall accuracy.
    for i in range(12):
        rows.append(dict(session_id='b1',input_id=i,fixed2_cycles=100,adaptive_cycles=80,
                         fixed2_correct=int(i<3 or i>=6),
                         adaptive_correct=int(3<=i<6 or i>=6)))
    r=primary_metrics(rows,bootstrap_samples=500)
    assert r['adaptive_only_correct']==3
    assert r['fixed2_only_correct']==3
    assert r['mcnemar_exact_two_sided_p']==1.0
    assert r['accuracy_noninferiority_1pp']!='EQUIVALENT'


def _make_test_hardware(tmp_path, compiler='clang_lld'):
    camp=tmp_path/'campaign';prepare(ROOT,camp)
    file_path=camp/'hardware_review.json';h=json.loads(file_path.read_text())
    h.update(status='OPERATOR_REVIEWED_FOR_EMPIRICAL_RUN',pcb_revision='TEST_ONLY',
             board_identifier='SYNTHETIC_UNIT_TEST_NOT_A_BOARD',clock_hz=50_000_000,
             clock_source_and_tolerance='SYNTHETIC',reviewer='TEST',
             reviewed_at_utc='TEST',firmware_toolchain=compiler)
    h['gates']={k:True for k in h['gates']}
    h['tools'].update({'quartus':'TEST', 'verilator':'TEST','sv2v':'TEST',
        'riscv_gcc':None, 'clang':'clang 17','lld':'lld 17','llvm_objcopy':'LLVM objcopy'})
    for name in h['files']:
        f=camp/'evidence'/name;f.write_bytes(('SYNTHETIC TEST '+name).encode())
        h['files'][name]={'path':str(f.relative_to(camp)),
                          'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
    file_path.write_text(json.dumps(h))
    return camp,h


def test_clang_lld_compiler_is_valid_when_actually_used(tmp_path):
    camp,_=_make_test_hardware(tmp_path)
    h=load_hardware(camp)
    assert h['firmware_toolchain']=='clang_lld'
    assert h['tools']['riscv_gcc'] is None


def test_missing_clang_linker_is_rejected(tmp_path):
    camp,h=_make_test_hardware(tmp_path)
    h['tools']['lld']=None
    (camp/'hardware_review.json').write_text(json.dumps(h))
    with pytest.raises(ValueError,match='tool|linker|lld'):
        load_hardware(camp)


def test_boot_aware_statistical_revision_is_frozen_before_capture(tmp_path):
    from paper_campaign import digest
    from paper_results import load_campaign
    camp=tmp_path/'campaign';new=prepare(ROOT,camp)
    assert new['statistical_amendment']=='2026-11-02_preboard_boot_aware'
    assert new['bootstrap']['two_way']['unit']=='input_id_x_cold_boot_session'
    assert new['bootstrap']['two_way']['seed_offset']==104729
    assert new['bootstrap']['two_way']['required_for_speedup_claim'] is True
    assert load_campaign(camp)['campaign_sha256']==new['campaign_sha256']
    # Even recomputing the embedded SHA must not silently change analysis gates.
    j=json.loads((camp/'campaign.json').read_text())
    j['bootstrap']['two_way']['seed_offset']=111
    j.pop('campaign_sha256');j['campaign_sha256']=digest(j)
    (camp/'campaign.json').write_text(json.dumps(j))
    with pytest.raises(ValueError,match='bootstrap|statistical|analysis'):
        load_campaign(camp)


def test_packaged_frozen_campaign_matches_new_generator(tmp_path):
    fresh=prepare(ROOT,tmp_path/'campaign')
    frozen=json.loads((ROOT/'paper/campaign/campaign.json').read_text())
    assert fresh==frozen
