"""Accuracy-only oracle table. No fabricated FPGA/ISA/clock measurements."""
import json
import sys
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))


def test_real_q15_paired_baseline_is_exact_and_non_temporal(tmp_path):
    from paper_q15_baseline import export_q15_only
    j=export_q15_only(ROOT,tmp_path/'q15')
    assert j['status']=='FROZEN_Q15_ONLY_NOT_BOARD_TIMING'
    assert j['unique_inputs']==360
    assert j['fixed2_correct']==339
    assert j['adaptive_correct']==339
    assert j['both_correct']==336
    assert j['both_wrong']==18
    assert j['adaptive_only_correct']==3
    assert j['fixed2_only_correct']==3
    assert j['mcnemar_exact_two_sided_p']==1.0
    assert j['accuracy_delta_pp_bootstrap_ci95'][0] < -1
    assert j['accuracy_delta_pp_bootstrap_ci95'][1] > 1
    assert j['accuracy_noninferiority_1pp']=='INCONCLUSIVE'
    assert j['preferred_histogram']==[0,263,81,7,2,7,0]
    assert j['total_adaptive_blocks']==489
    assert j['fpga_cycles_measured'] is False
    assert not any('cycles' in key and key!='fpga_cycles_measured' for key in j)
    assert (tmp_path/'q15/accuracy_pairs.csv').read_text().count('\n')==361
    assert json.loads((tmp_path/'q15/accuracy_only.json').read_text())==j
    with pytest.raises(FileExistsError):export_q15_only(ROOT,tmp_path/'q15')


def test_oracle_tamper_fails_with_pinned_external_digest(tmp_path):
    from paper_q15_baseline import export_q15_only
    tampered=tmp_path/'src';(tampered/'generated').mkdir(parents=True)
    for name in ('heldout360.json','frozen_q15_oracle.json'):
        (tampered/'generated'/name).write_bytes((ROOT/'generated'/name).read_bytes())
    bad=tampered/'generated/frozen_q15_oracle.json'
    data=json.loads(bad.read_text());data['predictions']['0']['predictions'][2]=4
    bad.write_text(json.dumps(data))
    with pytest.raises(ValueError):export_q15_only(tampered,tmp_path/'invalid')
    assert not (tmp_path/'invalid').exists()


def test_packaged_hardware_review_marks_actual_compiler_family():
    j=json.loads((ROOT/'paper/campaign/hardware_review.json').read_text())
    assert j['firmware_toolchain']=='clang_lld'
    assert {'clang','lld','llvm_objcopy'}<=set(j['tools'])
    assert j['status']=='PENDING_NOT_BOARD_READY'
