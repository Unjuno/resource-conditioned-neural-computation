#!/usr/bin/env python3
"""Fail-closed overlay application: never silently overwrite Codex edits."""
import argparse,hashlib,json,os,sys
from pathlib import Path
from shutil import copy2

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--target',type=Path,required=True,help='original Stage2 extraction root or fpga/de0_cv directory')
parser.add_argument('--check-only',action='store_true')
a=parser.parse_args()
overlay=Path(__file__).resolve().parent
m=json.loads((overlay/'OVERLAY_MANIFEST.json').read_text())
target=a.target.resolve()
if (target/'fpga/de0_cv/tools/paper_results.py').is_file():target=target/'fpga/de0_cv'
if not (target/'tools/paper_results.py').is_file():parser.error('target lacks fpga/de0_cv tools')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changes=[]
for item in m['files']:
    rel=Path(item['path'])
    if rel.is_absolute() or '..' in rel.parts:parser.error('unsafe relative path')
    src=overlay/'changes/fpga/de0_cv'/rel
    dst=target/rel
    if not src.is_file() or sha(src)!=item['new_sha256']:parser.error('overlay file integrity failure: '+str(rel))
    old=item['original_sha256']
    if dst.exists():
        got=sha(dst)
        if got==item['new_sha256']:mode='already-applied'
        elif old is not None and got==old:mode='update'
        else:parser.error('CONFLICT: base SHA mismatch (Codex may have edited): '+str(rel))
    else:
        if old is not None:parser.error('missing original file: '+str(rel))
        mode='create'
    changes.append((src,dst,mode))
print('VERIFIED',len(changes),'files',sum(mode=='update' for _,_,mode in changes),'updates',
      sum(mode=='create' for _,_,mode in changes),'new',sum(mode=='already-applied' for _,_,mode in changes),'existing')
if a.check_only:sys.exit(0)
for src,dst,mode in changes:
    if mode=='already-applied':continue
    dst.parent.mkdir(parents=True,exist_ok=True)
    tmp=dst.with_name(dst.name+'.rtnn_overlay_tmp')
    if tmp.exists():parser.error('temporary path exists: '+str(tmp))
    copy2(src,tmp)
    os.replace(tmp,dst)
print('APPLIED',len([1 for _,_,mode in changes if mode!='already-applied']),'files; re-run tests before any hardware capture')
